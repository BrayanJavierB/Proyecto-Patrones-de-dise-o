"""
visitantes.py
-------------
Implementación del patrón de diseño VISITOR (comportamiento): agregar
OPERACIONES NUEVAS a una estructura de objetos sin modificar las clases de
sus elementos.

¿Por qué Visitor aquí?
----------------------
El árbol del Composite (estructura_clinica.py) tiene solo dos tipos de nodo,
y no van a cambiar: la historia suelta (HistoriaClinicaHoja) y la carpeta
(GrupoClinico). En cambio, las PREGUNTAS que el equipo clínico quiere hacerle
al árbol no paran de crecer:

  - "¿Cuántas historias hay por tipo de atención, por estado y por médico?"
  - "¿Qué historias tienen datos clínicos sin completar?"
  - "¿Qué controles ya vencieron o vencen esta semana?"

Sin Visitor, cada pregunta sería un método más en ComponenteClinico, y por lo
tanto uno en la hoja y otro en el grupo (como ya pasó con contar_historias,
exportar, notificar...). El Composite acabaría mezclando la ESTRUCTURA del
árbol con cada reporte que a alguien se le ocurra, y cada reporte nuevo
obligaría a editar clases que no tienen nada que ver con él.

Con Visitor, cada pregunta es una CLASE que sabe qué hacer con una historia y
qué hacer al entrar y salir de una carpeta. Los nodos solo aprenden UNA vez a
"aceptar" visitantes:

    resultado = raiz.aceptar(VisitanteEstadisticas()).resultado()

DOBLE DESPACHO: el nodo no sabe qué visitante recibe, y el visitante no sabe
qué tipo de nodo le toca. Se resuelve en dos saltos:

    nodo.aceptar(visitante)          # 1) se elige según el tipo del NODO
      -> visitante.visitar_historia(hoja)    # 2) se elige según el tipo de VISITANTE
      -> visitante.entrar_grupo(grupo) ... salir_grupo(grupo)

Estructura del patrón en este archivo:
  Visitor (interfaz)       -> Visitante
  ConcreteVisitor          -> VisitanteEstadisticas, VisitanteCompletitud,
                              VisitanteControles (los dos últimos comparten la
                              base VisitanteConRuta, que lleva la cuenta de en
                              qué carpeta se está)
  Element (interfaz)       -> ElementoVisitable (define `aceptar`)
  ConcreteElement          -> HistoriaClinicaHoja y GrupoClinico (estructura_clinica.py)
  ObjectStructure          -> el árbol del Composite (la raíz o cualquier carpeta)
  Cliente                  -> la fachada (fachada.py), método `generar_reporte`

Decisiones de diseño:
  - EL RECORRIDO LO HACE LA ESTRUCTURA, no el visitante: `GrupoClinico.aceptar`
    llama a `entrar_grupo`, acepta a cada hijo y llama a `salir_grupo`. Así los
    visitantes no repiten la lógica de recorrer. No se usó el Iterator porque
    este necesita el gancho de SALIDA de cada carpeta (para sacarla de la ruta),
    cosa que un recorrido lineal de (nivel, nodo) no entrega. A cambio, el
    recorrido es recursivo; la profundidad del árbol la fija _NIVELES (hoy, 3).
  - GANCHOS OPCIONALES: `entrar_grupo` y `salir_grupo` no hacen nada por
    defecto. Un visitante que solo mira historias (VisitanteEstadisticas) no
    los escribe; uno que necesita saber en qué carpeta está (los otros dos) sí.
  - UN VISITANTE POR RECORRIDO: guarda estado (contadores, hallazgos, la ruta
    actual). Por eso NO se comparte como un peso ligero: se crea uno nuevo en
    cada reporte y se descarta. Dos recorridos simultáneos nunca se mezclan.
  - SOLO LECTURA: ningún visitante modifica el árbol ni la base de datos.
    Visitor permitiría operaciones que cambian cosas, pero estas tres son
    reportes y es más seguro que no puedan alterar historias clínicas.
  - SIN DEPENDENCIA CIRCULAR: este módulo NO importa estructura_clinica. Los
    visitantes solo usan lo que ofrece cualquier nodo: `hoja.paciente`,
    `hoja.nombre` y `grupo.nombre`. Es estructura_clinica quien importa este módulo.

El costo conocido del patrón: agregar un NUEVO TIPO DE NODO obliga a tocar todos
los visitantes (cada uno necesita su método `visitar_<tipo>`). Visitor conviene
cuando los tipos de nodo son estables y las operaciones cambian, que es
justo lo contrario del problema que resuelve el polimorfismo normal. Aquí lo
estable son hojas y carpetas; lo que crece son los reportes.
"""

from abc import ABC, abstractmethod
from collections import Counter
from datetime import date

from fabricas import TIPOS_ATENCION     # Abstract Factory: nombres legibles de los tipos
from estados import ESTADOS, ESTADO_INICIAL   # State: nombres legibles de los estados

#: Orden en que se listan las prioridades de urgencias (las desconocidas van después).
_ORDEN_PRIORIDADES = ("alta", "media", "baja")


# =====================================================================
# INTERFACES DEL PATRÓN
# =====================================================================
class ElementoVisitable(ABC):
    """
    Interfaz que cumple todo nodo que acepta visitantes. Es el primer salto
    del doble despacho: cada nodo concreto llama al método del visitante que
    corresponde a SU tipo.
    """

    @abstractmethod
    def aceptar(self, visitante: "Visitante") -> "Visitante":
        """
        Deja que `visitante` recorra este nodo (y todo lo que contiene).
        Devuelve el mismo visitante, para poder encadenar:
        `nodo.aceptar(VisitanteX()).resultado()`.
        """
        raise NotImplementedError


class Visitante(ABC):
    """
    Contrato común de todos los visitantes. Un método por tipo de nodo:

      visitar_historia(hoja)  -> obligatorio: qué hacer con UNA historia clínica.
      entrar_grupo(grupo)     -> opcional: se llama al llegar a una carpeta, antes de sus hijos.
      salir_grupo(grupo)      -> opcional: se llama al terminar con sus hijos.
      resultado()             -> lo que el visitante averiguó durante el recorrido.
    """

    @abstractmethod
    def visitar_historia(self, hoja) -> None:
        raise NotImplementedError

    def entrar_grupo(self, grupo) -> None:
        """Gancho opcional: por defecto no hace nada."""

    def salir_grupo(self, grupo) -> None:
        """Gancho opcional: por defecto no hace nada."""

    @abstractmethod
    def resultado(self):
        raise NotImplementedError


class VisitanteConRuta(Visitante):
    """
    Base para los visitantes que necesitan decir EN QUÉ CARPETA está cada
    historia. Usa los dos ganchos: al entrar apila el nombre de la carpeta y al
    salir lo saca. `ruta_actual()` devuelve, p. ej.,
    «Todas las historias clínicas › Registrado por admin › Control».
    """

    def __init__(self):
        self._ruta = []

    def entrar_grupo(self, grupo) -> None:
        self._ruta.append(grupo.nombre)

    def salir_grupo(self, grupo) -> None:
        self._ruta.pop()

    def ruta_actual(self) -> str:
        return " › ".join(self._ruta)


# =====================================================================
# UTILIDADES COMUNES (puras, sin estado)
# =====================================================================
def _tipo_de(paciente: dict) -> str:
    """Tipo de atención del paciente (vacío = consulta general, como en el resto del sistema)."""
    return paciente.get("tipo_atencion") or "consulta_general"


def _estado_de(paciente: dict) -> tuple:
    """(clave, etiqueta) del estado de ciclo de vida; un valor raro de la BD no rompe el reporte."""
    clave = paciente.get("estado_atencion") or ESTADO_INICIAL
    estado = ESTADOS.get(clave)
    return clave, (estado.etiqueta if estado else "Desconocido")


def _falta(valor) -> bool:
    """¿El campo está vacío o solo tiene espacios?"""
    return not str(valor or "").strip()


def _fecha_o_none(texto):
    """Convierte 'AAAA-MM-DD' en date; None si está vacío o no tiene ese formato."""
    try:
        return date.fromisoformat(str(texto or "").strip())
    except ValueError:
        return None


def _ordenar(contador: Counter, orden_conocido, etiquetas: dict) -> list:
    """
    Lista de (etiqueta, cantidad): primero las claves conocidas, en su orden
    natural y aunque valgan 0; después las inesperadas, ordenadas por nombre.
    """
    filas = [(etiquetas.get(clave, clave), contador.get(clave, 0)) for clave in orden_conocido]
    extras = sorted(clave for clave in contador if clave not in orden_conocido)
    filas.extend((etiquetas.get(clave, clave), contador[clave]) for clave in extras)
    return filas


# =====================================================================
# VISITANTE 1: estadísticas
# =====================================================================
class VisitanteEstadisticas(Visitante):
    """
    Cuenta las historias del nodo visitado por tipo de atención, por estado del
    ciclo de vida, por médico que las registró y (en urgencias) por prioridad.

    Solo necesita mirar historias, así que no escribe `entrar_grupo` ni
    `salir_grupo`: usa los ganchos vacíos de la base.
    """

    def __init__(self):
        self._total = 0
        self._por_tipo = Counter()
        self._por_estado = Counter()
        self._por_medico = Counter()
        self._por_prioridad = Counter()

    def visitar_historia(self, hoja) -> None:
        paciente = hoja.paciente
        tipo = _tipo_de(paciente)
        self._total += 1
        self._por_tipo[tipo] += 1
        self._por_estado[_estado_de(paciente)[0]] += 1
        self._por_medico[paciente.get("registrado_por") or "(sin registrar)"] += 1
        if tipo == "urgencias":
            self._por_prioridad[(paciente.get("prioridad") or "sin prioridad").lower()] += 1

    def resultado(self) -> dict:
        """
        {"total": int,
         "por_tipo": [(etiqueta, n)...], "por_estado": [(etiqueta, n)...],
         "por_medico": [(usuario, n)...], "urgencias_por_prioridad": [(etiqueta, n)...]}
        """
        etiquetas_tipo = dict(TIPOS_ATENCION)
        etiquetas_estado = {clave: estado.etiqueta for clave, estado in ESTADOS.items()}
        medicos = sorted(self._por_medico.items(), key=lambda fila: fila[0].lower())
        return {
            "total": self._total,
            "por_tipo": _ordenar(self._por_tipo, [clave for clave, _ in TIPOS_ATENCION], etiquetas_tipo),
            "por_estado": _ordenar(self._por_estado, list(ESTADOS), etiquetas_estado),
            "por_medico": medicos,
            "urgencias_por_prioridad": _ordenar(
                self._por_prioridad, _ORDEN_PRIORIDADES, {p: p.capitalize() for p in _ORDEN_PRIORIDADES}
            ) if self._por_prioridad else [],
        }


# =====================================================================
# VISITANTE 2: completitud de las historias
# =====================================================================
class VisitanteCompletitud(VisitanteConRuta):
    """
    Detecta las historias con huecos: motivo, diagnóstico o tratamiento vacíos,
    y los datos que su tipo de atención da por obligatorios (la prioridad en
    urgencias, una fecha válida de próximo control en controles).

    El formulario solo exige nombre y documento (más lo propio de cada tipo de
    atención, que valida el Abstract Factory): motivo, diagnóstico y tratamiento
    pueden quedar vacíos, y de eso trata sobre todo este reporte. Las reglas por
    tipo se vuelven a comprobar como red de seguridad, por si hay datos que no
    pasaron por el validador (p. ej. cargados directamente en la base de datos).
    No se reutiliza el validador porque sus mensajes están redactados para quien
    llena el formulario («debes indicar...»), no para quien lee un reporte.
    """

    _CAMPOS_CLINICOS = (
        ("motivo_consulta", "Falta el motivo de consulta"),
        ("diagnostico", "Falta el diagnóstico"),
        ("tratamiento", "Falta el tratamiento"),
    )

    def __init__(self):
        super().__init__()
        self._total = 0
        self._hallazgos = []

    def visitar_historia(self, hoja) -> None:
        paciente = hoja.paciente
        self._total += 1
        problemas = self._problemas_de(paciente)
        if problemas:
            self._hallazgos.append({
                "paciente_id": paciente.get("id"),
                "nombre": hoja.nombre,
                "documento": paciente.get("documento", ""),
                "carpeta": self.ruta_actual(),
                "problemas": problemas,
            })

    @classmethod
    def _problemas_de(cls, paciente: dict) -> list:
        problemas = [texto for campo, texto in cls._CAMPOS_CLINICOS if _falta(paciente.get(campo))]
        tipo = _tipo_de(paciente)
        if tipo == "urgencias" and _falta(paciente.get("prioridad")):
            problemas.append("Falta la prioridad de la urgencia")
        if tipo == "control":
            texto_fecha = paciente.get("fecha_proximo_control")
            if _falta(texto_fecha):
                problemas.append("Falta la fecha del próximo control")
            elif _fecha_o_none(texto_fecha) is None:
                problemas.append("La fecha del próximo control no es válida")
        return problemas

    def resultado(self) -> dict:
        """
        {"total", "completas", "incompletas", "porcentaje" (None si no hubo historias),
         "hallazgos": [{"paciente_id", "nombre", "documento", "carpeta", "problemas": [...]}...]}
        """
        incompletas = len(self._hallazgos)
        completas = self._total - incompletas
        return {
            "total": self._total,
            "completas": completas,
            "incompletas": incompletas,
            "porcentaje": round(100 * completas / self._total) if self._total else None,
            "hallazgos": list(self._hallazgos),
        }


# =====================================================================
# VISITANTE 3: agenda de controles
# =====================================================================
class VisitanteControles(VisitanteConRuta):
    """
    Clasifica los próximos controles programados en tres grupos según la fecha:
    vencidos (ya pasaron), próximos (dentro de `dias_aviso` días, contando hoy)
    y programados (más adelante).

    Decisiones:
      - Solo cuentan las historias de tipo Control con una fecha válida (las
        que no la tienen las señala VisitanteCompletitud).
      - Se ignoran las historias Cerradas: están archivadas y ya no hay nada
        pendiente. Una historia Atendida sí cuenta (el control futuro sigue en pie).
      - `hoy` es un parámetro para poder probar el reporte con una fecha fija
        sin depender del reloj del equipo.
    """

    def __init__(self, hoy: date = None, dias_aviso: int = 7):
        super().__init__()
        self._hoy = hoy or date.today()
        self._dias_aviso = dias_aviso
        self._vencidos, self._proximos, self._programados = [], [], []

    def visitar_historia(self, hoja) -> None:
        paciente = hoja.paciente
        if _tipo_de(paciente) != "control":
            return
        clave_estado, etiqueta_estado = _estado_de(paciente)
        if clave_estado == "cerrada":
            return
        fecha = _fecha_o_none(paciente.get("fecha_proximo_control"))
        if fecha is None:
            return

        dias = (fecha - self._hoy).days
        fila = {
            "paciente_id": paciente.get("id"),
            "nombre": hoja.nombre,
            "fecha": fecha.isoformat(),
            "dias": dias,
            "cuando": self._cuando(dias),
            "estado": etiqueta_estado,
            "carpeta": self.ruta_actual(),
        }
        if dias < 0:
            self._vencidos.append(fila)
        elif dias <= self._dias_aviso:
            self._proximos.append(fila)
        else:
            self._programados.append(fila)

    @staticmethod
    def _cuando(dias: int) -> str:
        """Texto corto de cuánto falta (o cuánto hace que pasó)."""
        if dias == 0:
            return "hoy"
        if dias == 1:
            return "mañana"
        if dias == -1:
            return "ayer"
        return f"en {dias} días" if dias > 0 else f"hace {-dias} días"

    def resultado(self) -> dict:
        """{"hoy": 'AAAA-MM-DD', "dias_aviso": int, "vencidos": [...], "proximos": [...], "programados": [...]}"""
        def por_fecha(filas):
            return sorted(filas, key=lambda fila: (fila["fecha"], fila["nombre"].lower()))

        return {
            "hoy": self._hoy.isoformat(),
            "dias_aviso": self._dias_aviso,
            "vencidos": por_fecha(self._vencidos),
            "proximos": por_fecha(self._proximos),
            "programados": por_fecha(self._programados),
        }


if __name__ == "__main__":
    # Demostración sin Flask ni base de datos. Se importa el Composite aquí
    # dentro (y no arriba) para que este módulo no dependa de él.
    from estructura_clinica import construir_arbol

    hoy = date(2026, 10, 10)
    pacientes_demo = [
        {"id": 1, "nombre_completo": "María López", "documento": "100", "tipo_atencion": "consulta_general",
         "registrado_por": "admin", "motivo_consulta": "Dolor abdominal", "diagnostico": "Gastritis",
         "tratamiento": "Omeprazol"},
        {"id": 2, "nombre_completo": "Carlos Pérez", "documento": "200", "tipo_atencion": "control",
         "registrado_por": "brayan", "motivo_consulta": "Control post-quirúrgico", "diagnostico": "Favorable",
         "tratamiento": "Analgésico", "fecha_proximo_control": "2026-10-05"},                  # vencido
        {"id": 3, "nombre_completo": "Sofía Ramírez", "documento": "300", "tipo_atencion": "urgencias",
         "prioridad": "alta", "registrado_por": "brayan", "motivo_consulta": "Disnea",
         "estado_atencion": "en_atencion"},                                                     # sin diagnóstico ni tratamiento
        {"id": 4, "nombre_completo": "Luis Gómez", "documento": "400", "tipo_atencion": "urgencias",
         "prioridad": "baja", "registrado_por": "admin", "motivo_consulta": "Esguince",
         "diagnostico": "Esguince grado I", "tratamiento": "Reposo"},
        {"id": 5, "nombre_completo": "Ana Ruiz", "documento": "500", "tipo_atencion": "control",
         "registrado_por": "admin", "motivo_consulta": "Hipertensión", "diagnostico": "Controlada",
         "tratamiento": "Losartán", "fecha_proximo_control": "2026-10-14"},                    # próximo (4 días)
        {"id": 6, "nombre_completo": "Pedro Díaz", "documento": "600", "tipo_atencion": "control",
         "registrado_por": "admin", "motivo_consulta": "Diabetes", "diagnostico": "Tipo 2",
         "tratamiento": "Metformina", "fecha_proximo_control": "2026-12-01"},                  # programado
        {"id": 7, "nombre_completo": "Rosa Mejía", "documento": "700", "tipo_atencion": "control",
         "registrado_por": "admin", "motivo_consulta": "Alergia", "diagnostico": "Rinitis",
         "tratamiento": "Antihistamínico", "fecha_proximo_control": "2026-09-01",
         "estado_atencion": "cerrada"},                                                         # vencido pero cerrada: se ignora
    ]
    raiz = construir_arbol(pacientes_demo, "tipo")

    print("1) Tres visitantes distintos recorren EL MISMO árbol (los nodos no cambian):")
    est = raiz.aceptar(VisitanteEstadisticas()).resultado()
    print(f"   Estadísticas -> {est['total']} historias | por tipo: {est['por_tipo']}")
    print(f"                   por estado: {est['por_estado']}")
    print(f"                   por médico: {est['por_medico']} | prioridades: {est['urgencias_por_prioridad']}")

    comp = raiz.aceptar(VisitanteCompletitud()).resultado()
    print(f"   Completitud  -> {comp['completas']}/{comp['total']} completas ({comp['porcentaje']} %)")
    for h in comp["hallazgos"]:
        print(f"                   · {h['nombre']} [{h['carpeta']}]: {', '.join(h['problemas'])}")

    ctl = raiz.aceptar(VisitanteControles(hoy=hoy)).resultado()
    print(f"   Controles (hoy = {ctl['hoy']}):")
    for grupo in ("vencidos", "proximos", "programados"):
        for f in ctl[grupo]:
            print(f"                   · {grupo:11} {f['nombre']} -> {f['fecha']} ({f['cuando']})")
    print("                   (Rosa Mejía vence antes de hoy pero está Cerrada: no aparece)")

    print("\n2) El mismo visitante sobre una carpeta y sobre una historia suelta:")
    urgencias = raiz.buscar("raiz/tipo=urgencias")
    sofia = raiz.buscar("paciente-3")
    for nodo in (raiz, urgencias, sofia):
        total = nodo.aceptar(VisitanteEstadisticas()).resultado()["total"]
        print(f"   {type(nodo).__name__:20} '{nodo.nombre}': {total} historia(s)")

    print("\n3) Un visitante NUEVO sin tocar ninguna clase del árbol:")

    class VisitanteEnAtencion(Visitante):
        """Ejemplo mínimo: lista quién está siendo atendido en este momento."""
        def __init__(self):
            self._nombres = []
        def visitar_historia(self, hoja):
            if hoja.paciente.get("estado_atencion") == "en_atencion":
                self._nombres.append(hoja.nombre)
        def resultado(self):
            return self._nombres

    print("   en atención ahora:", raiz.aceptar(VisitanteEnAtencion()).resultado())

    print("\n4) Cada recorrido tiene su propio visitante (no comparten estado):")
    a, b = VisitanteEstadisticas(), VisitanteEstadisticas()
    urgencias.aceptar(a)
    raiz.aceptar(b)
    print(f"   a vio {a.resultado()['total']} historias; b vio {b.resultado()['total']}")

    print("\n5) Ganchos de carpeta: la ruta se apila al entrar y se vacía al salir:")
    v = VisitanteCompletitud()
    raiz.aceptar(v)
    print(f"   ruta al terminar el recorrido: {v.ruta_actual()!r} (vacía)")

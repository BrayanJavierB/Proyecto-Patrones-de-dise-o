"""
seguridad.py
------------
Medidas básicas de protección de datos (Objetivo 4):

  1. CIFRADO EN REPOSO de los datos sensibles del paciente (nombre, fecha de
     nacimiento, motivo, diagnóstico, tratamiento y notas) con Fernet (AES-128-CBC
     + HMAC-SHA256, de la librería `cryptography`). En la base de datos solo queda
     texto cifrado con el prefijo `enc:v1:`; se descifra al leer (en singleton.py).
  2. GESTIÓN DE CLAVES: la clave de cifrado, la clave de firma de sesiones de Flask y
     la clave de la API de dispositivos salen de una variable de entorno o, si no
     existe, se GENERAN una vez y se guardan en un archivo `.key` (permisos 600) junto
     a la base de datos. Nunca están escritas en el código.

Límites conocidos (honestos):
  - El `documento` NO se cifra: la base de datos lo usa para garantizar que no se
    repita (restricción UNIQUE) y para buscar. Cifrarlo exigiría un índice ciego.
  - Quien tenga acceso al servidor Y al archivo de clave puede leer los datos. En
    producción la clave debe ir en un gestor de secretos (variable de entorno).
  - Si se pierde la clave, los datos cifrados NO se pueden recuperar.
  - El cifrado en tránsito (HTTPS) lo aporta el servidor web/proxy, no esta aplicación.
"""

import os
import secrets

from cryptography.fernet import Fernet, InvalidToken

PREFIJO = "enc:v1:"
TEXTO_ILEGIBLE = "[dato ilegible: clave de cifrado incorrecta]"


def _clave_persistente(directorio: str, variable_entorno: str, archivo: str, generar) -> str:
    """Devuelve la clave de la variable de entorno; si no hay, la lee (o genera y guarda) en `archivo`."""
    valor = os.environ.get(variable_entorno)
    if valor:
        return valor.strip()
    ruta = os.path.join(directorio, archivo)
    if os.path.exists(ruta):
        with open(ruta, "r", encoding="utf-8") as f:
            return f.read().strip()
    clave = generar()
    descriptor = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # solo el dueño puede leerla
    with os.fdopen(descriptor, "w", encoding="utf-8") as f:
        f.write(clave)
    return clave


def clave_secreta_flask(directorio: str) -> str:
    """Clave que firma la cookie de sesión (SHCE_SECRET_KEY o secret_key.key)."""
    return _clave_persistente(directorio, "SHCE_SECRET_KEY", "secret_key.key", lambda: secrets.token_hex(32))


def clave_api_dispositivos(directorio: str) -> str:
    """Clave que deben presentar los dispositivos IoT (SHCE_API_KEY o api_key.key)."""
    return _clave_persistente(directorio, "SHCE_API_KEY", "api_key.key", lambda: secrets.token_urlsafe(32))


class CifradorCampos:
    """Cifra y descifra campos de texto. Un valor ya cifrado no se vuelve a cifrar (idempotente)."""

    def __init__(self, clave: str):
        self._fernet = Fernet(clave.encode())

    @classmethod
    def para_directorio(cls, directorio: str) -> "CifradorCampos":
        return cls(_clave_persistente(directorio, "SHCE_CLAVE_CIFRADO", "clave_cifrado.key",
                                      lambda: Fernet.generate_key().decode()))

    def cifrar(self, valor):
        if not isinstance(valor, str) or valor == "" or valor.startswith(PREFIJO):
            return valor
        return PREFIJO + self._fernet.encrypt(valor.encode("utf-8")).decode("ascii")

    def descifrar(self, valor):
        """Los valores sin prefijo (datos antiguos, aún sin migrar) se devuelven tal cual."""
        if not isinstance(valor, str) or not valor.startswith(PREFIJO):
            return valor
        try:
            return self._fernet.decrypt(valor[len(PREFIJO):].encode("ascii")).decode("utf-8")
        except InvalidToken:
            return TEXTO_ILEGIBLE

"""
comandos.py
-----------
Implementación del patrón de diseño COMMAND (comportamiento): convertir una
PETICIÓN en un OBJETO. Una acción deja de ser «una llamada que se ejecuta y
se olvida» y pasa a ser algo que se puede guardar, deshacer, rehacer, agrupar
y listar.

¿Por qué Command aquí?
----------------------
Cambiar el estado de una historia (iniciar atención, dar de alta, cerrar,
reabrir) era una llamada directa que no dejaba rastro: no se podía revertir un
«cerrar» equivocado ni aplicar la misma acción a toda una carpeta con garantías.
Con Command cada cambio es un objeto que sabe ejecutarse Y deshacerse, y un
historial por usuario permite deshacer/rehacer sus últimas acciones.

Estructura del patrón en este archivo:
  Command (interfaz)    -> Comando
  ConcreteCommand       -> ComandoCambiarEstado (una historia)
                           ComandoMacro (varios comandos como uno solo)
  Receiver              -> el estado de la historia: la base de datos (Singleton)
                           y el ciclo de vida (State) que decide la transición
  Invoker               -> HistorialComandos (ejecuta, deshace y rehace)
  Cliente               -> la fachada (`cambiar_estado`, `cambiar_estado_nodo`,
                           `deshacer_comando`, `rehacer_comando`)

Decisiones de diseño:
  - EL COMANDO GUARDA LO NECESARIO PARA DESHACERSE: el estado anterior y el
    nuevo. Antes de deshacer comprueba que la historia SIGA en el estado nuevo;
    si alguien la cambió después, se niega con un mensaje claro en vez de pisar
    ese cambio (lo mismo al rehacer).
  - EL MACRO ES ATÓMICO: si un comando hijo falla a mitad, los ya ejecutados se
    deshacen y el error se propaga. Para el usuario es «todo o nada».
    Composite y Command colaboran: la carpeta entrega sus historias y el macro
    las trata como una sola acción.
  - HISTORIAL POR USUARIO: cada uno deshace SUS acciones, no las de otros.
    Máximo 20 por usuario. Vive en MEMORIA (se reinicia con el servidor), igual
    que las versiones del Memento y los avisos del Observer.
  - UN COMANDO QUE YA NO SE PUEDE DESHACER SE DESCARTA del historial: si se
    dejara, bloquearía para siempre a los que están debajo.
  - Command no reemplaza a Memento: Memento restaura el CONTENIDO clínico de una
    historia (ediciones); Command revierte ACCIONES de ciclo de vida. Son
    historiales independientes.
  - Los comandos no publican avisos (Observer) ni conocen roles: exponen
    `cambios` (qué cambió en cada historia) y es la fachada quien avisa.
"""

import time
from abc import ABC, abstractmethod
from threading import Lock

from estados import CicloVidaHistoria, TransicionInvalida, ESTADO_INICIAL

MAXIMO_POR_USUARIO = 20


class ErrorComando(Exception):
    """Un comando no pudo ejecutarse, deshacerse o rehacerse. El mensaje ya es para el usuario."""


class ComandoPacienteNoEncontrado(ErrorComando):
    """La historia sobre la que actúa el comando ya no existe."""


# =====================================================================
# COMMAND (interfaz)
# =====================================================================
class Comando(ABC):
    """
    Contrato común. Tras cada operación, `cambios` describe lo ocurrido como
    lista de (paciente_id, nombre, detalle) para que quien invoca pueda avisar.
    """

    descripcion = ""

    def __init__(self):
        self.cambios = []

    @abstractmethod
    def ejecutar(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def deshacer(self) -> None:
        raise NotImplementedError

    def rehacer(self) -> None:
        """Volver a aplicar tras un deshacer. Por defecto, igual que ejecutar."""
        self.ejecutar()


# =====================================================================
# COMANDO CONCRETO: cambiar el estado de UNA historia
# =====================================================================
class ComandoCambiarEstado(Comando):
    """
    Aplica una acción del ciclo de vida a una historia. El receptor `db` solo
    necesita `obtener_paciente(id)` y `actualizar_estado_paciente(id, clave)`.
    Quién decide a qué estado se pasa es el patrón State, no este comando.
    """

    def __init__(self, db, paciente_id: int, accion: str):
        super().__init__()
        self._db, self._id, self._accion = db, paciente_id, accion
        self._anterior = self._nuevo = None
        self.nombre = ""
        self.estado_nuevo = ""      # etiqueta legible, para el mensaje de la ruta
        self.descripcion = f"{accion} (historia {paciente_id})"

    def _paciente(self) -> dict:
        paciente = self._db.obtener_paciente(self._id)
        if paciente is None:
            raise ComandoPacienteNoEncontrado("Paciente no encontrado.")
        return paciente

    def _escribir(self, estado, detalle: str) -> None:
        if not self._db.actualizar_estado_paciente(self._id, estado.clave):
            raise ComandoPacienteNoEncontrado("Paciente no encontrado.")
        self.cambios = [(self._id, self.nombre, detalle)]

    def _exigir_estado(self, esperado) -> None:
        actual = self._paciente().get("estado_atencion") or ESTADO_INICIAL
        if actual != esperado.clave:
            raise ErrorComando(
                f"No se puede aplicar a «{self.nombre}»: su estado cambió después y ahora es «{actual}»."
            )

    def ejecutar(self) -> None:
        paciente = self._paciente()
        ciclo = CicloVidaHistoria(paciente.get("estado_atencion"))
        self._anterior = ciclo.estado
        self.nombre = paciente["nombre_completo"]
        try:
            ciclo.ejecutar(self._accion)
        except TransicionInvalida as error:
            raise ErrorComando(str(error)) from None
        self._nuevo = ciclo.estado
        self.estado_nuevo = self._nuevo.etiqueta
        self.descripcion = f"{self.nombre}: {self._anterior.etiqueta} → {self._nuevo.etiqueta}"
        self._escribir(self._nuevo, f"{self._anterior.etiqueta} → {self._nuevo.etiqueta}")

    def deshacer(self) -> None:
        self._exigir_estado(self._nuevo)
        self._escribir(self._anterior, f"{self._nuevo.etiqueta} → {self._anterior.etiqueta} (deshecho)")

    def rehacer(self) -> None:
        self._exigir_estado(self._anterior)
        self._escribir(self._nuevo, f"{self._anterior.etiqueta} → {self._nuevo.etiqueta} (rehecho)")


# =====================================================================
# COMANDO COMPUESTO: varios comandos como uno solo (todo o nada)
# =====================================================================
class ComandoMacro(Comando):
    def __init__(self, comandos, descripcion: str):
        super().__init__()
        self._comandos = list(comandos)
        self.descripcion = descripcion

    def __len__(self):
        return len(self._comandos)

    def _aplicar(self, operacion: str, inversa: str, orden) -> None:
        """Aplica `operacion` a los hijos; si uno falla, aplica `inversa` a los ya hechos (atomicidad)."""
        hechos = []
        try:
            for comando in orden:
                getattr(comando, operacion)()
                hechos.append(comando)
        except ErrorComando:
            for comando in reversed(hechos):
                getattr(comando, inversa)()
            raise
        self.cambios = [cambio for comando in self._comandos for cambio in comando.cambios]

    def ejecutar(self) -> None:
        self._aplicar("ejecutar", "deshacer", self._comandos)

    def deshacer(self) -> None:
        self._aplicar("deshacer", "rehacer", reversed(self._comandos))

    def rehacer(self) -> None:
        self._aplicar("rehacer", "deshacer", self._comandos)


# =====================================================================
# INVOKER: el historial
# =====================================================================
class HistorialComandos:
    """Ejecuta comandos y guarda, por usuario, las pilas de deshacer y rehacer."""

    def __init__(self, maximo: int = MAXIMO_POR_USUARIO):
        self._maximo = maximo
        self._deshacer, self._rehacer = {}, {}
        self._candado = Lock()

    def _pilas(self, usuario):
        return self._deshacer.setdefault(usuario, []), self._rehacer.setdefault(usuario, [])

    def ejecutar(self, usuario: str, comando: Comando) -> Comando:
        comando.ejecutar()          # si falla, no entra al historial
        with self._candado:
            deshacer, rehacer = self._pilas(usuario)
            deshacer.append((comando, time.strftime("%Y-%m-%d %H:%M:%S")))
            del deshacer[:-self._maximo]
            rehacer.clear()         # una acción nueva descarta lo «rehacible», como en un editor
        return comando

    def deshacer(self, usuario: str) -> Comando:
        with self._candado:
            deshacer, rehacer = self._pilas(usuario)
            if not deshacer:
                raise ErrorComando("No hay nada que deshacer.")
            comando, momento = deshacer.pop()    # si falla, se descarta (ver docstring del módulo)
        comando.deshacer()
        with self._candado:
            self._pilas(usuario)[1].append((comando, momento))
        return comando

    def rehacer(self, usuario: str) -> Comando:
        with self._candado:
            deshacer, rehacer = self._pilas(usuario)
            if not rehacer:
                raise ErrorComando("No hay nada que rehacer.")
            comando, momento = rehacer.pop()
        comando.rehacer()
        with self._candado:
            self._pilas(usuario)[0].append((comando, momento))
        return comando

    def resumen(self, usuario: str, limite: int = 10) -> dict:
        """{"historial": [{"descripcion", "momento"}...] (más reciente primero), "puede_deshacer", "puede_rehacer"}"""
        with self._candado:
            deshacer, rehacer = self._pilas(usuario)
            historial = [{"descripcion": c.descripcion, "momento": m} for c, m in reversed(deshacer[-limite:])]
            return {"historial": historial, "puede_deshacer": bool(deshacer), "puede_rehacer": bool(rehacer)}


if __name__ == "__main__":
    class _BDFalsa:
        """Receptor mínimo en memoria (sin SQLite)."""
        def __init__(self):
            self.pacientes = {i: {"id": i, "nombre_completo": n, "estado_atencion": e}
                              for i, n, e in ((1, "Ana", None), (2, "Luis", "en_atencion"), (3, "Rosa", "cerrada"))}
        def obtener_paciente(self, i): return dict(self.pacientes[i]) if i in self.pacientes else None
        def actualizar_estado_paciente(self, i, e):
            self.pacientes[i]["estado_atencion"] = e; return True
        def estados(self): return {p["nombre_completo"]: p["estado_atencion"] for p in self.pacientes.values()}

    db, historial = _BDFalsa(), HistorialComandos()
    print("0) Inicio:", db.estados())

    c = historial.ejecutar("dra", ComandoCambiarEstado(db, 1, "iniciar_atencion"))
    print("1) Ejecutar:", c.descripcion, "|", db.estados()["Ana"])
    historial.deshacer("dra");  print("2) Deshacer ->", db.estados()["Ana"])
    historial.rehacer("dra");   print("3) Rehacer  ->", db.estados()["Ana"])

    try: historial.ejecutar("dra", ComandoCambiarEstado(db, 3, "dar_alta"))
    except ErrorComando as e: print("4) Acción no permitida por State:", e)

    db.pacientes[1]["estado_atencion"] = "atendida"     # alguien más cambia la historia
    try: historial.deshacer("dra")
    except ErrorComando as e: print("5) Conflicto al deshacer:", e)

    macro = ComandoMacro([ComandoCambiarEstado(db, 2, "dar_alta"), ComandoCambiarEstado(db, 1, "cerrar")], "Lote")
    historial.ejecutar("dra", macro)
    print("6) Macro sobre 2 historias:", db.estados())
    historial.deshacer("dra"); print("   Deshacer macro:", db.estados())

    roto = ComandoMacro([ComandoCambiarEstado(db, 2, "dar_alta"), ComandoCambiarEstado(db, 3, "dar_alta")], "Falla a mitad")
    antes = db.estados()
    try: historial.ejecutar("dra", roto)
    except ErrorComando: print("7) Macro atómico: falló el 2.º y el 1.º se revirtió ->", db.estados() == antes)

    print("8) Historial de otro usuario vacío:", historial.resumen("otro")["puede_deshacer"] is False)

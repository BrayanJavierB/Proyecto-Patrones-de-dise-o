"""
proxies.py
----------
Implementación del patrón de diseño PROXY (estructural): un objeto que
tiene LA MISMA interfaz que otro (el "sujeto real"), se interpone delante
de él y decide si, cuándo y cómo se le pasa cada llamada.

A diferencia de Decorator (que AGREGA responsabilidades al objeto que
envuelve) y de Facade (que SIMPLIFICA el acceso a varios subsistemas), el
Proxy CONTROLA EL ACCESO a un único objeto sin cambiar lo que ofrece.

Este módulo contiene dos proxies, porque el proyecto tenía dos puntos donde
"controlar el acceso" tenía sentido real:

  1) ProxySistemaExterno (proxy de CACHÉ, con papel de proxy remoto)
     Sujeto real: SistemaExternoHistorias, software de OTRA institución.
     Cada consulta a un sistema de terceros es costosa (red, límites de
     uso, latencia), y SHCE la repetía sin necesidad: listar las historias
     externas pedía cada registro de nuevo en cada visita, y la vista previa
     de una importación consultaba el mismo registro dos veces (una cruda,
     otra a través del Adapter). El proxy recuerda las respuestas durante un
     tiempo y solo llama al sistema real cuando no tiene el dato o está vencido.

  2) ProxyProteccionFachada (proxy de PROTECCIÓN)
     Sujeto real: FachadaSHCE, la puerta de entrada a todo el SHCE.
     El sistema ya tenía roles (médico, enfermería, administrador) pero
     ninguna regla los usaba. Este proxy se coloca delante de la fachada,
     con el usuario y el rol de quien hace la petición, y comprueba el
     permiso ANTES de dejar pasar cada operación. Si se niega, deja el
     intento en la bitácora de denegaciones.

Estructura del patrón en este archivo:
  Sujeto (interfaz común)  -> RegistrosExternos (adaptadores.py) / la interfaz pública de FachadaSHCE
  Sujeto real              -> SistemaExternoHistorias / FachadaSHCE
  Proxy                    -> ProxySistemaExterno / ProxyProteccionFachada
  Cliente                  -> el Adapter y la fachada / las rutas de app.py (no notan la diferencia)

Decisiones de diseño:
  - Este módulo NO importa fachada.py (la fachada es quien importa este
    módulo): el proxy de protección funciona con cualquier objeto que tenga
    los métodos de la fachada, y la auditoría le llega como un callback.
  - El proxy de protección falla CERRADO: una operación pública de la
    fachada que no figure en la tabla PERMISOS se niega, en lugar de dejarse
    pasar. Así, agregar un método nuevo a la fachada sin decidir quién puede
    usarlo no abre un hueco de seguridad por descuido.
  - La política es una sola tabla (PERMISOS) al comienzo del archivo; cambiar
    quién puede qué no obliga a tocar el código del proxy ni el de las rutas.
"""

import copy
import inspect
import time
from collections import namedtuple
from threading import Lock

from adaptadores import RegistrosExternos


# =====================================================================
# 1) PROXY DE CACHÉ: delante del sistema externo de historias
# =====================================================================
class ProxySistemaExterno(RegistrosExternos):
    """
    Se hace pasar por el sistema externo (misma interfaz: RegistrosExternos)
    pero recuerda sus respuestas `ttl_segundos` segundos.

    Detalles que importan:
      - Devuelve COPIAS: si un cliente modifica el diccionario que recibe,
        la copia guardada en la caché no cambia (el sistema real ya hacía lo
        mismo con `dict(registro)`).
      - Los errores NO se guardan: si el sistema real no tiene un código
        (ValueError), la excepción llega tal cual al cliente y no se crea
        ninguna entrada. Así la caché no puede crecer con códigos inventados
        que lleguen desde la URL; su tamaño máximo es el de los registros reales.
      - Es seguro entre hilos (Flask atiende peticiones simultáneas). La
        llamada al sistema real se hace FUERA del candado para no bloquear a
        todos los demás mientras uno espera a un tercero; el costo es que dos
        peticiones que fallen a la vez en el mismo código harán dos consultas
        reales, lo cual es inocuo (ambas guardan el mismo resultado).
      - `reloj` es inyectable para poder probar el vencimiento sin esperar.
    """

    def __init__(self, sistema_real: RegistrosExternos, ttl_segundos: float = 60.0, reloj=time.monotonic):
        self._real = sistema_real
        self._ttl = ttl_segundos
        self._reloj = reloj
        self._cache = {}          # clave -> (momento_guardado, valor)
        self._candado = Lock()
        self._consultas = 0       # cuántas veces se pidió algo
        self._aciertos = 0        # cuántas se respondieron desde la caché
        self._llamadas_reales = 0 # cuántas llegaron de verdad al sistema externo

    # --- interfaz del sujeto (la misma que la del sistema real) ---------
    def listar_codigos_disponibles(self) -> list:
        return self._obtener(("codigos",), self._real.listar_codigos_disponibles)

    def consultar_registro(self, codigo_externo: str) -> dict:
        return self._obtener(("registro", codigo_externo), lambda: self._real.consultar_registro(codigo_externo))

    # --- lo propio del proxy --------------------------------------------
    def invalidar(self, codigo_externo: str = None) -> None:
        """Olvida un registro (o todo, si no se indica código) para forzar una consulta nueva."""
        with self._candado:
            if codigo_externo is None:
                self._cache.clear()
            else:
                self._cache.pop(("registro", codigo_externo), None)
                self._cache.pop(("codigos",), None)

    def estadisticas(self) -> dict:
        """Cuántas consultas se hicieron y cuántas se ahorraron (para el panel)."""
        with self._candado:
            return {
                "consultas": self._consultas,
                "aciertos": self._aciertos,
                "llamadas_reales": self._llamadas_reales,
                "entradas": len(self._cache),
                "ttl_segundos": self._ttl,
            }

    def _obtener(self, clave, consulta_real):
        with self._candado:
            self._consultas += 1
            entrada = self._cache.get(clave)
            if entrada is not None and self._reloj() - entrada[0] < self._ttl:
                self._aciertos += 1
                return copy.deepcopy(entrada[1])

        with self._candado:
            self._llamadas_reales += 1   # se cuenta aunque falle: igual llegó al tercero
        valor = consulta_real()          # si lanza, no se guarda nada

        with self._candado:
            self._cache[clave] = (self._reloj(), copy.deepcopy(valor))
        return valor


# =====================================================================
# 2) PROXY DE PROTECCIÓN: delante de la fachada
# =====================================================================
ADMINISTRADOR = "administrador"
MEDICO = "medico"
ENFERMERIA = "enfermeria"

_TODOS = frozenset({ADMINISTRADOR, MEDICO, ENFERMERIA})
_CLINICOS = frozenset({ADMINISTRADOR, MEDICO})
_SOLO_ADMIN = frozenset({ADMINISTRADOR})

Regla = namedtuple("Regla", "roles descripcion")

#: LA POLÍTICA: operación de la fachada -> quién puede y cómo se le dice al usuario.
PERMISOS = {
    # Panel y consulta
    "resumen_panel":                 Regla(_TODOS, "ver el panel"),
    "listar_pacientes":              Regla(_TODOS, "consultar pacientes"),
    "listar_pacientes_enriquecidos": Regla(_TODOS, "consultar pacientes"),
    "consultar_estructura":          Regla(_TODOS, "ver la estructura de carpetas"),
    "normalizar_agrupacion":         Regla(_TODOS, "ver la estructura de carpetas"),
    "resumen_por_niveles":           Regla(_TODOS, "ver la estructura de carpetas"),
    # Citas, signos vitales, interacciones y eliminación (objetivos del proyecto)
    "medicos_disponibles":           Regla(_TODOS, "consultar los médicos disponibles"),
    "listar_citas":                  Regla(_TODOS, "consultar las citas"),
    "programar_cita":                Regla(_CLINICOS, "programar citas médicas"),
    "cambiar_estado_cita":           Regla(_CLINICOS, "cumplir o cancelar citas médicas"),
    "eliminar_paciente":             Regla(_SOLO_ADMIN, "eliminar historias clínicas"),
    "registrar_signos":              Regla(_TODOS, "registrar signos vitales"),
    "registrar_signos_dispositivo":  Regla(frozenset(), "registrar signos desde un dispositivo (solo por la API con clave)"),
    "signos_de":                     Regla(_TODOS, "consultar los signos vitales"),
    "interacciones_de":              Regla(_TODOS, "consultar las interacciones medicamentosas"),
    "detalle_paciente":              Regla(_TODOS, "ver el detalle de un paciente"),
    "cuenta_bloqueada":              Regla(_TODOS, "consultar el bloqueo de una cuenta"),
    "generar_reporte":               Regla(_TODOS, "ver los reportes de las historias clínicas"),
    "historial_notificaciones":      Regla(_TODOS, "ver el historial de notificaciones"),
    # Notificaciones: enfermería también avisa al equipo
    "notificar_paciente":            Regla(_TODOS, "enviar notificaciones"),
    "notificar_nodo":                Regla(_TODOS, "enviar notificaciones"),
    # Escritura clínica: solo médicos y administradores
    "registrar_paciente":            Regla(_CLINICOS, "registrar historias clínicas"),
    "plantilla_desde_paciente":      Regla(_CLINICOS, "usar una historia como plantilla"),
    "listar_registros_externos":     Regla(_CLINICOS, "consultar el sistema externo"),
    "previsualizar_importacion":     Regla(_CLINICOS, "consultar el sistema externo"),
    "importar_desde_externo":        Regla(_CLINICOS, "importar historias del sistema externo"),
    # Edición con historial de versiones (Memento): escribir es clínico; consultar versiones, de todos
    "datos_edicion":                 Regla(_CLINICOS, "editar historias clínicas"),
    "editar_paciente":               Regla(_CLINICOS, "editar historias clínicas"),
    "deshacer_edicion":              Regla(_CLINICOS, "deshacer ediciones de historias clínicas"),
    "rehacer_edicion":               Regla(_CLINICOS, "rehacer ediciones de historias clínicas"),
    "restaurar_version":             Regla(_CLINICOS, "restaurar versiones de historias clínicas"),
    "versiones_paciente":            Regla(_TODOS, "consultar el historial de versiones"),
    # Ciclo de vida (State): cambiar el estado es clínico. Seguimiento y avisos (Observer): de todos
    "cambiar_estado":                Regla(_CLINICOS, "cambiar el estado de las historias clínicas"),
    # Command: acciones de ciclo de vida (también por carpeta) con deshacer/rehacer; ver el historial propio, todos
    "cambiar_estado_nodo":           Regla(_CLINICOS, "cambiar el estado de las historias de una carpeta"),
    "deshacer_comando":              Regla(_CLINICOS, "deshacer cambios de estado"),
    "rehacer_comando":               Regla(_CLINICOS, "rehacer cambios de estado"),
    "comandos_recientes":            Regla(_TODOS, "consultar tu historial de acciones"),
    # Strategy: elegir el criterio de orden del listado
    "normalizar_orden":              Regla(_TODOS, "ordenar el listado de pacientes"),
    "seguir_paciente":               Regla(_TODOS, "seguir historias clínicas"),
    "dejar_de_seguir":               Regla(_TODOS, "dejar de seguir historias clínicas"),
    "pacientes_seguidos":            Regla(_TODOS, "consultar las historias que sigues"),
    "avisos_de":                     Regla(_TODOS, "consultar tus avisos"),
    "avisos_sin_leer":               Regla(_TODOS, "consultar tus avisos"),
    "marcar_avisos_leidos":          Regla(_TODOS, "gestionar tus avisos"),
    # Exportación: todos, pero enfermería solo anonimizada (ver SOLO_ANONIMIZADO)
    "exportar_paciente":             Regla(_TODOS, "exportar historias clínicas"),
    "exportar_nodo":                 Regla(_TODOS, "exportar historias clínicas"),
}

#: Operaciones que no exigen sesión: son justamente las que crean la sesión o la cuenta.
PUBLICAS = frozenset({"iniciar_sesion", "registrar_usuario"})

#: Operaciones de exportación y los roles que solo pueden exportar con "anonimizar" marcado.
EXPORTACIONES = frozenset({"exportar_paciente", "exportar_nodo"})
SOLO_ANONIMIZADO = frozenset({ENFERMERIA})


class AccesoDenegado(Exception):
    """
    El rol del usuario no permite la operación pedida. `str(error)` es un
    mensaje listo para mostrarle al usuario (igual que ErrorFachada).
    """


class ProxyProteccionFachada:
    """
    Se hace pasar por la fachada: expone sus mismos métodos y catálogos, y
    antes de ejecutar cualquier operación comprueba PERMISOS para el rol de
    quien llama. Si pasa la comprobación, delega en la fachada real con los
    mismos argumentos; si no, lanza AccesoDenegado y deja constancia.

    Se crea UNO POR PETICIÓN (el usuario y el rol son de esa petición); la
    fachada real, en cambio, es única y compartida.

      usuario, rol          -> quién hace la petición (None si no hay sesión).
      registrar_denegacion  -> callback que guarda el intento negado (opcional).
    """

    def __init__(self, fachada, usuario, rol, registrar_denegacion=None):
        self._fachada = fachada
        self._usuario = usuario
        self._rol = rol
        self._registrar_denegacion = registrar_denegacion

    def __getattr__(self, nombre):
        # Solo se llama para lo que NO es del proxy: es decir, todo lo que
        # el cliente pide como si esto fuera la fachada.
        if nombre.startswith("_"):
            raise AttributeError(nombre)

        atributo = getattr(self._fachada, nombre)

        # Catálogos (tipos_atencion, canales_envio...): datos, no operaciones.
        if not callable(atributo):
            return atributo

        def protegido(*args, **kwargs):
            self._exigir(nombre, atributo, args, kwargs)
            return atributo(*args, **kwargs)

        protegido.__name__ = nombre
        protegido.__doc__ = atributo.__doc__
        return protegido

    # --- la comprobación -------------------------------------------------
    def _exigir(self, operacion, metodo, args, kwargs) -> None:
        if operacion in PUBLICAS:
            return

        regla = PERMISOS.get(operacion)
        if regla is None:
            self._denegar(operacion, "operación sin política de permisos definida")
        if self._rol not in regla.roles:
            self._denegar(operacion, f"el rol '{self._rol}' no puede {regla.descripcion}", regla)

        if operacion in EXPORTACIONES and self._rol in SOLO_ANONIMIZADO:
            opciones = self._argumento(metodo, args, kwargs, "opciones") or ()
            if "anonimizar" not in opciones:
                self._denegar(
                    operacion,
                    f"el rol '{self._rol}' solo puede exportar con la opción 'Anonimizar' marcada",
                    regla,
                    mensaje_usuario="Con tu rol solo puedes exportar historias anonimizadas: marca «Anonimizar» e inténtalo de nuevo.",
                )

    @staticmethod
    def _argumento(metodo, args, kwargs, nombre):
        """Lee un argumento por nombre, lo hayan pasado posicional o con nombre."""
        try:
            return inspect.signature(metodo).bind(*args, **kwargs).arguments.get(nombre)
        except TypeError:
            return None   # firma inválida: que sea la fachada real quien lance el error

    def _denegar(self, operacion, motivo, regla=None, mensaje_usuario=None):
        evento = {"usuario": self._usuario, "rol": self._rol, "operacion": operacion, "motivo": motivo}
        if self._registrar_denegacion is not None:
            try:
                self._registrar_denegacion(evento)
            except Exception as error:   # un fallo al auditar nunca debe convertir un NO en un SÍ
                print(f"[ProxyProteccionFachada] No se pudo registrar la denegación: {error}")

        if mensaje_usuario is None:
            descripcion = regla.descripcion if regla else "realizar esa operación"
            mensaje_usuario = f"Tu rol ({self._rol or 'sin sesión'}) no tiene permiso para {descripcion}."
        raise AccesoDenegado(mensaje_usuario)


# =====================================================================
# Demostración sin Flask y sin tocar tu base de datos real
# =====================================================================
if __name__ == "__main__":
    import os
    import tempfile

    import proxies   # el propio módulo, para usar una única copia de sus clases

    # ---- 1) Proxy de caché --------------------------------------------
    class _ExternoContador(RegistrosExternos):
        """Sistema externo falso que cuenta cuántas veces lo llaman de verdad."""
        def __init__(self):
            self.llamadas = 0
        def listar_codigos_disponibles(self):
            self.llamadas += 1
            return ["EXT-001", "EXT-002"]
        def consultar_registro(self, codigo):
            self.llamadas += 1
            if codigo != "EXT-001":
                raise ValueError(codigo)
            return {"nombre": "Luisa"}

    ahora = [0.0]
    real = _ExternoContador()
    proxy = proxies.ProxySistemaExterno(real, ttl_segundos=60, reloj=lambda: ahora[0])

    print("1) PROXY DE CACHÉ")
    for _ in range(3):
        proxy.consultar_registro("EXT-001")
    print(f"   3 consultas al mismo código -> llamadas reales al externo: {real.llamadas}")

    dato = proxy.consultar_registro("EXT-001")
    dato["nombre"] = "ALTERADO"
    print("   La caché sigue intacta si el cliente modifica su copia:", proxy.consultar_registro("EXT-001")["nombre"])

    ahora[0] = 61
    proxy.consultar_registro("EXT-001")
    print(f"   Pasados 61 s la entrada venció -> llamadas reales: {real.llamadas}")

    for _ in range(100):
        try:
            proxy.consultar_registro("INVENTADO")
        except ValueError:
            pass
    print("   100 códigos inexistentes no crecen la caché -> entradas:", proxy.estadisticas()["entradas"],
          "(los errores sí cuentan como llamadas reales)")
    print("   Estadísticas:", proxy.estadisticas())

    # ---- 2) Proxy de protección ---------------------------------------
    from singleton import DatabaseManager
    from fachada import FachadaSHCE

    carpeta = tempfile.mkdtemp()
    db = DatabaseManager(db_path=os.path.join(carpeta, "demo_proxy.db"))
    fachada = FachadaSHCE()

    print("\n2) PROXY DE PROTECCIÓN")
    formulario = {"nombre_completo": "Ana Ruiz", "documento": "7770001", "fecha_nacimiento": "1990-01-01",
                  "motivo_consulta": "Chequeo", "tipo_atencion": "consulta_general"}

    def intentar(rol, descripcion, operacion):
        proxy_f = proxies.ProxyProteccionFachada(fachada, "demo", rol, db.registrar_denegacion)
        try:
            operacion(proxy_f)
            print(f"   [{str(rol):<13}] {descripcion:<38} -> permitido")
        except proxies.AccesoDenegado as error:
            print(f"   [{str(rol):<13}] {descripcion:<38} -> DENEGADO: {error}")

    intentar("medico", "registrar paciente", lambda f: f.registrar_paciente(formulario, "demo"))
    intentar("enfermeria", "registrar paciente", lambda f: f.registrar_paciente(formulario, "demo"))
    intentar("enfermeria", "listar pacientes", lambda f: f.listar_pacientes())
    intentar("enfermeria", "exportar sin anonimizar",
             lambda f: f.exportar_paciente(1, "txt", opciones=[], usuario="demo"))
    intentar("enfermeria", "exportar anonimizado",
             lambda f: f.exportar_paciente(1, "txt", opciones=["anonimizar"], usuario="demo"))
    intentar("enfermeria", "exportar anonimizado (argumento posicional)",
             lambda f: f.exportar_paciente(1, "txt", ["anonimizar"], "demo"))
    intentar(None, "ver el panel sin sesión", lambda f: f.resumen_panel())
    intentar("administrador", "importar del sistema externo", lambda f: f.importar_desde_externo("EXT-002", "demo"))

    print("   Catálogos pasan sin comprobación:", [c for c, _ in proxies.ProxyProteccionFachada(fachada, None, None).tipos_atencion][:3])

    class _FachadaConMetodoNuevo:
        def operacion_sin_politica(self):
            return "no debería ejecutarse"
    intentar("administrador", "método nuevo sin política (falla cerrado)",
             lambda _f: proxies.ProxyProteccionFachada(_FachadaConMetodoNuevo(), "demo", "administrador").operacion_sin_politica())

    print("   Bitácora de denegaciones:", [(d["rol"], d["operacion"]) for d in db.obtener_denegaciones(limite=10)])

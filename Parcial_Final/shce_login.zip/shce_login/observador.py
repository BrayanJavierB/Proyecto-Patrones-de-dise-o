"""
observador.py
-------------
Implementación del patrón de diseño OBSERVER (comportamiento): un objeto
("sujeto") mantiene una lista de interesados ("observadores") y les AVISA
automáticamente cada vez que ocurre un cambio, sin saber quiénes son ni qué
hacen con el aviso.

¿Por qué Observer aquí?
-----------------------
Una historia clínica la pueden tocar varias personas: un médico la edita,
otro deshace un cambio, enfermería la pasa a "Atendida". Quien la sigue de
cerca (el médico responsable, un jefe de servicio) necesita enterarse sin
tener que entrar a revisarla una y otra vez. Con Observer, cualquier usuario
puede SUSCRIBIRSE a una historia ("seguirla") y recibir un aviso en su bandeja
cada vez que cambie, y cancelar su suscripción cuando quiera.

Estructura del patrón en este archivo:
  Subject (base)          -> Sujeto: suscribir / cancelar / notificar_observadores
  ConcreteSubject         -> PacienteObservable: un sujeto POR paciente
  Observer (interfaz)     -> Observador: `actualizar(cambio)`
  ConcreteObserver        -> BandejaAvisos: la bandeja de avisos de UN usuario
  Evento que viaja        -> CambioHistoria (qué cambió, quién y cuándo)
  Administrador           -> ServicioSeguimiento: guarda los sujetos y las bandejas
  Cliente                 -> la fachada (fachada.py): publica un CambioHistoria
                             cuando una historia cambia

El recorrido de una edición, paso a paso:

    médico A sigue a Ana  ──▶  Ana(sujeto).suscribir(bandeja de A)
    médica B edita a Ana  ──▶  fachada.publicar(CambioHistoria "edición")
                                   │
                                   ▼
                          Ana(sujeto).notificar_observadores
                                   ├──▶ bandeja de A.actualizar  → aviso guardado 🔔
                                   └──▶ bandeja de B.actualizar  → ignora: B es la autora

Observer y Mediator, ¿no son lo mismo?
  Se parecen (ambos reparten avisos) pero responden a preguntas distintas:
  - MEDIATOR (mediador.py) coordina colaboradores INTERNOS y FIJOS del sistema
    (notificador, historial, auditoría), cableados una sola vez al arrancar. Los
    colegas se hablan A TRAVÉS del mediador.
  - OBSERVER (este archivo) maneja suscripciones DINÁMICAS elegidas en tiempo de
    ejecución por los USUARIOS: cada uno decide a qué historias suscribirse y cuándo
    dejar de hacerlo. Hay un sujeto por paciente y el sujeto no conoce a sus observadores.

Decisiones de diseño:
  - MODELO "PUSH": el sujeto le entrega al observador el CambioHistoria completo; el
    observador no tiene que preguntarle nada al sujeto.
  - UN OBSERVADOR ROTO NO ARRUINA A LOS DEMÁS: `notificar_observadores` aísla cada
    aviso. Si una bandeja falla, las otras igual reciben el suyo y la edición clínica
    (que ya se guardó) no se deshace. Los fallos se devuelven como lista para poder
    inspeccionarlos; no se ocultan.
  - EL AUTOR NO SE AVISA A SÍ MISMO: quien hizo el cambio ya sabe que lo hizo.
  - SUJETOS PEREZOSOS: un paciente solo tiene sujeto cuando alguien lo sigue por primera vez.
  - DEJAR DE SEGUIR NO BORRA LO YA RECIBIDO: cancelar la suscripción detiene los avisos
    futuros; los que ya estaban en la bandeja se conservan.
  - BANDEJA ACOTADA: cada bandeja guarda como máximo `limite` avisos (los más recientes).
  - EN MEMORIA: igual que el historial de notificaciones y el de versiones, las
    suscripciones y bandejas viven en la memoria del servidor y se reinician con él.
  - CONCURRENCIA: sujeto, bandeja y servicio usan cerrojos (Flask atiende peticiones en paralelo).
"""

import threading
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime


# =====================================================================
# EL EVENTO que viaja del sujeto a los observadores
# =====================================================================
@dataclass(frozen=True)
class CambioHistoria:
    """Qué le pasó a una historia: inmutable, para que ningún observador pueda alterarlo."""
    paciente_id: int
    paciente_nombre: str
    tipo: str        # "edicion" | "deshacer" | "rehacer" | "restauracion" | "estado"
    detalle: str     # texto legible: qué campos cambiaron, qué transición ocurrió...
    autor: str       # usuario que hizo el cambio
    momento: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


# =====================================================================
# INTERFAZ DEL OBSERVADOR
# =====================================================================
class Observador(ABC):
    """Contrato que cumple todo el que quiera enterarse de los cambios."""

    @abstractmethod
    def actualizar(self, cambio: CambioHistoria) -> None:
        """El sujeto llama a este método cada vez que hay un cambio."""
        raise NotImplementedError


# =====================================================================
# EL SUJETO
# =====================================================================
class Sujeto:
    """Base de todo objeto observable: gestiona la lista de observadores y los avisa."""

    def __init__(self):
        self._observadores = []
        self._cerrojo = threading.RLock()

    def suscribir(self, observador: Observador) -> bool:
        """Agrega un observador. Devuelve False si ya estaba suscrito."""
        with self._cerrojo:
            if observador in self._observadores:
                return False
            self._observadores.append(observador)
            return True

    def cancelar(self, observador: Observador) -> bool:
        """Quita un observador. Devuelve False si no estaba suscrito."""
        with self._cerrojo:
            if observador not in self._observadores:
                return False
            self._observadores.remove(observador)
            return True

    @property
    def observadores(self) -> tuple:
        with self._cerrojo:
            return tuple(self._observadores)

    def notificar_observadores(self, cambio: CambioHistoria) -> list:
        """
        Avisa a todos los observadores, en el orden en que se suscribieron. Aísla los
        fallos: devuelve la lista de (observador, excepción) de los que fallaron.
        """
        fallos = []
        for observador in self.observadores:     # copia: se puede suscribir/cancelar durante el aviso
            try:
                observador.actualizar(cambio)
            except Exception as error:           # un observador roto no debe tumbar a los demás
                fallos.append((observador, error))
        return fallos


class PacienteObservable(Sujeto):
    """El sujeto concreto: UNA historia clínica que otros pueden seguir."""

    def __init__(self, paciente_id: int):
        super().__init__()
        self.paciente_id = paciente_id

    def publicar(self, cambio: CambioHistoria) -> list:
        if cambio.paciente_id != self.paciente_id:
            raise ValueError("El cambio pertenece a otro paciente.")
        return self.notificar_observadores(cambio)


# =====================================================================
# EL OBSERVADOR CONCRETO
# =====================================================================
@dataclass
class _Aviso:
    cambio: CambioHistoria
    leido: bool = False


class BandejaAvisos(Observador):
    """La bandeja de avisos de UN usuario: guarda lo que le avisan los sujetos que sigue."""

    def __init__(self, usuario: str, limite: int = 100):
        self.usuario = usuario
        self._avisos = deque(maxlen=limite)
        self._cerrojo = threading.RLock()

    def actualizar(self, cambio: CambioHistoria) -> None:
        if cambio.autor == self.usuario:      # el autor ya sabe lo que hizo
            return
        with self._cerrojo:
            self._avisos.appendleft(_Aviso(cambio))

    def avisos(self, limite: int = None) -> list:
        """Los avisos, el más reciente primero, como diccionarios listos para pintar."""
        with self._cerrojo:
            salida = [
                {"paciente_id": a.cambio.paciente_id, "paciente_nombre": a.cambio.paciente_nombre,
                 "tipo": a.cambio.tipo, "detalle": a.cambio.detalle, "autor": a.cambio.autor,
                 "momento": a.cambio.momento, "leido": a.leido}
                for a in self._avisos
            ]
        return salida if limite is None else salida[:limite]

    def sin_leer(self) -> int:
        with self._cerrojo:
            return sum(1 for a in self._avisos if not a.leido)

    def marcar_leidos(self) -> int:
        """Marca todo como leído. Devuelve cuántos avisos estaban sin leer."""
        with self._cerrojo:
            pendientes = [a for a in self._avisos if not a.leido]
            for aviso in pendientes:
                aviso.leido = True
            return len(pendientes)


# =====================================================================
# EL ADMINISTRADOR DE SUSCRIPCIONES
# =====================================================================
class ServicioSeguimiento:
    """Guarda un sujeto por paciente seguido y una bandeja por usuario, y los conecta."""

    def __init__(self, limite_bandeja: int = 100):
        self._limite_bandeja = limite_bandeja
        self._sujetos = {}      # paciente_id -> PacienteObservable
        self._bandejas = {}     # usuario -> BandejaAvisos
        self._cerrojo = threading.RLock()

    def bandeja(self, usuario: str) -> BandejaAvisos:
        with self._cerrojo:
            return self._bandejas.setdefault(usuario, BandejaAvisos(usuario, self._limite_bandeja))

    def seguir(self, usuario: str, paciente_id: int) -> bool:
        """Suscribe la bandeja del usuario al paciente. False si ya lo seguía."""
        with self._cerrojo:
            sujeto = self._sujetos.setdefault(paciente_id, PacienteObservable(paciente_id))
            return sujeto.suscribir(self.bandeja(usuario))

    def dejar_de_seguir(self, usuario: str, paciente_id: int) -> bool:
        """Cancela la suscripción. False si no lo seguía."""
        with self._cerrojo:
            sujeto = self._sujetos.get(paciente_id)
            return sujeto.cancelar(self.bandeja(usuario)) if sujeto else False

    def pacientes_seguidos(self, usuario: str) -> set:
        with self._cerrojo:
            bandeja = self.bandeja(usuario)
            return {pid for pid, sujeto in self._sujetos.items() if bandeja in sujeto.observadores}

    def publicar(self, cambio: CambioHistoria) -> list:
        """Avisa del cambio a quienes siguen al paciente. Sin seguidores, no hace nada."""
        with self._cerrojo:
            sujeto = self._sujetos.get(cambio.paciente_id)
        return sujeto.publicar(cambio) if sujeto else []


if __name__ == "__main__":
    # Demostración sin Flask ni base de datos.
    servicio = ServicioSeguimiento()
    servicio.seguir("dr.perez", 7)
    servicio.seguir("dra.lopez", 7)
    servicio.seguir("dr.perez", 8)
    print("1) Siguen a Ana (7):", [u for u in ("dr.perez", "dra.lopez") if 7 in servicio.pacientes_seguidos(u)])

    servicio.publicar(CambioHistoria(7, "Ana Ruiz", "edicion", "Campos modificados: Diagnóstico", "dra.lopez"))
    print("2) dra.lopez edita a Ana → avisos de dr.perez:", servicio.bandeja("dr.perez").sin_leer(),
          "| avisos de dra.lopez (autora):", servicio.bandeja("dra.lopez").sin_leer())

    servicio.dejar_de_seguir("dr.perez", 7)
    servicio.publicar(CambioHistoria(7, "Ana Ruiz", "estado", "Registrada → En atención", "dra.lopez"))
    print("3) dr.perez deja de seguir a Ana → sigue con", servicio.bandeja("dr.perez").sin_leer(), "aviso (el de antes)")

    servicio.publicar(CambioHistoria(8, "Luis Gómez", "estado", "En atención → Atendida", "dra.lopez"))
    print("4) Cambio en Luis (8), al que dr.perez sigue:", servicio.bandeja("dr.perez").sin_leer(), "avisos sin leer")
    print("   Marcar leídos:", servicio.bandeja("dr.perez").marcar_leidos(), "→ quedan", servicio.bandeja("dr.perez").sin_leer())

    class Roto(Observador):
        def actualizar(self, cambio):
            raise RuntimeError("fallo a propósito")
    sujeto = PacienteObservable(9); sujeto.suscribir(Roto()); buena = BandejaAvisos("x"); sujeto.suscribir(buena)
    fallos = sujeto.publicar(CambioHistoria(9, "Zoe", "edicion", "d", "otro"))
    print("5) Un observador roto no afecta al resto: fallos =", len(fallos), "| la bandeja buena recibió", buena.sin_leer())

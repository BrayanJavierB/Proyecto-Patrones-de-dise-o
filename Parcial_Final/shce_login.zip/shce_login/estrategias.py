"""
estrategias.py
--------------
Implementación del patrón de diseño STRATEGY (comportamiento): definir una
FAMILIA de algoritmos intercambiables, encapsular cada uno en su clase y
elegir cuál usar en tiempo de ejecución, sin que quien los usa cambie.

¿Por qué Strategy aquí?
-----------------------
El listado de pacientes salía siempre en un solo orden (el más reciente
primero, el que entrega la base de datos). Pero el equipo clínico necesita
verlo de varias maneras según el momento: alfabético para buscar a alguien,
urgencias de mayor prioridad primero en un turno, o por el próximo control
más cercano. Sin Strategy, eso sería un `if orden == "nombre": ... elif ...`
dentro de la fachada o de la ruta, y cada criterio nuevo obligaría a editarlo.

Con Strategy, cada criterio es una CLASE con el mismo contrato, y el
contexto (OrdenadorPacientes) delega en la que se le entregue.

Estructura del patrón en este archivo:
  Strategy (interfaz)   -> EstrategiaOrden
  ConcreteStrategy      -> OrdenRecientes, OrdenNombre, OrdenUrgencia, OrdenControl
  Context               -> OrdenadorPacientes (guarda UNA estrategia y le delega)
  Cliente               -> la fachada (`listar_pacientes_enriquecidos(orden=...)`)

Decisiones de diseño:
  - La estrategia solo decide la CLAVE de orden de un paciente; el contexto
    hace el `sorted`. Así cada estrategia es una función pequeña y probable.
  - Las estrategias NO tienen estado (el paciente llega por parámetro), así
    que se comparten: hay una sola instancia de cada una en ESTRATEGIAS.
  - ELEGIR UNA ESTRATEGIA NO ES EL PATRÓN: `obtener_estrategia("nombre")` es solo
    el diccionario que traduce el texto de la URL a la clase. Una clave
    desconocida cae en la estrategia por defecto (no rompe la página).
  - Todas desempatan por «más reciente primero» para que el orden sea estable
    y predecible.
  - Strategy y State se parecen en la forma (un objeto delega en otro
    intercambiable) pero no en la intención: aquí QUIEN USA elige el algoritmo
    desde fuera; en State el propio objeto cambia de estado por sí mismo.
"""

from abc import ABC, abstractmethod
from datetime import date

_SIN_FECHA = "9999-99-99"           # los controles sin fecha válida van al final
_RANGO_PRIORIDAD = {"alta": 0, "media": 1, "baja": 2}


def _mas_reciente_primero(paciente: dict) -> int:
    """Desempate común: el id más alto (registrado después) va antes."""
    return -(paciente.get("id") or 0)


# =====================================================================
# ESTRATEGIA (interfaz)
# =====================================================================
class EstrategiaOrden(ABC):
    """Contrato de todo criterio de orden. Sin estado: el paciente llega por parámetro."""

    clave = ""      # texto que viaja en la URL (?orden=...)
    titulo = ""     # texto del botón en pantalla

    @abstractmethod
    def clave_orden(self, paciente: dict):
        """Valor por el que se compara este paciente (menor = antes)."""
        raise NotImplementedError


# =====================================================================
# ESTRATEGIAS CONCRETAS
# =====================================================================
class OrdenRecientes(EstrategiaOrden):
    clave, titulo = "recientes", "Más recientes"

    def clave_orden(self, paciente):
        return _mas_reciente_primero(paciente)


class OrdenNombre(EstrategiaOrden):
    clave, titulo = "nombre", "Nombre (A-Z)"

    def clave_orden(self, paciente):
        return ((paciente.get("nombre_completo") or "").casefold(), _mas_reciente_primero(paciente))


class OrdenUrgencia(EstrategiaOrden):
    """Urgencias primero (alta, media, baja, sin prioridad); luego todo lo demás."""
    clave, titulo = "urgencia", "Urgencias primero"

    def clave_orden(self, paciente):
        if paciente.get("tipo_atencion") == "urgencias":
            rango = _RANGO_PRIORIDAD.get((paciente.get("prioridad") or "").lower(), 3)
        else:
            rango = 4
        return (rango, _mas_reciente_primero(paciente))


class OrdenControl(EstrategiaOrden):
    """Próximo control más cercano primero; las historias sin control programado, al final."""
    clave, titulo = "control", "Próximo control"

    def clave_orden(self, paciente):
        texto = (paciente.get("fecha_proximo_control") or "").strip()
        try:
            fecha = date.fromisoformat(texto).isoformat()
        except ValueError:
            fecha = _SIN_FECHA
        return (fecha, _mas_reciente_primero(paciente))


#: Una sola instancia de cada estrategia (no tienen estado). El primero es el orden por defecto.
ESTRATEGIAS = {e.clave: e for e in (OrdenRecientes(), OrdenNombre(), OrdenUrgencia(), OrdenControl())}
ORDEN_POR_DEFECTO = "recientes"

#: Para poblar los botones de la interfaz web.
ORDENES_OPCIONES = [(clave, e.titulo) for clave, e in ESTRATEGIAS.items()]


def obtener_estrategia(clave) -> EstrategiaOrden:
    """La estrategia pedida, o la de por defecto si la clave no existe."""
    return ESTRATEGIAS.get(clave, ESTRATEGIAS[ORDEN_POR_DEFECTO])


# =====================================================================
# CONTEXTO
# =====================================================================
class OrdenadorPacientes:
    """
    Contexto: guarda UNA estrategia y le delega el criterio. No contiene ningún
    `if orden == ...`; cambiar de criterio es cambiar de objeto estrategia.
    """

    def __init__(self, estrategia: EstrategiaOrden = None):
        self._estrategia = estrategia or ESTRATEGIAS[ORDEN_POR_DEFECTO]

    @property
    def estrategia(self) -> EstrategiaOrden:
        return self._estrategia

    @estrategia.setter
    def estrategia(self, estrategia: EstrategiaOrden) -> None:
        self._estrategia = estrategia

    def ordenar(self, pacientes) -> list:
        """Devuelve una lista NUEVA ordenada; la original no se modifica."""
        return sorted(pacientes, key=self._estrategia.clave_orden)


if __name__ == "__main__":
    demo = [
        {"id": 1, "nombre_completo": "María López", "tipo_atencion": "consulta_general"},
        {"id": 2, "nombre_completo": "carlos Pérez", "tipo_atencion": "control", "fecha_proximo_control": "2026-12-01"},
        {"id": 3, "nombre_completo": "Sofía Ramírez", "tipo_atencion": "urgencias", "prioridad": "alta"},
        {"id": 4, "nombre_completo": "Luis Gómez", "tipo_atencion": "urgencias", "prioridad": "baja"},
        {"id": 5, "nombre_completo": "Ana Ruiz", "tipo_atencion": "control", "fecha_proximo_control": "2026-10-14"},
        {"id": 6, "nombre_completo": "Pedro Díaz", "tipo_atencion": "control", "fecha_proximo_control": "fecha-rota"},
    ]
    ordenador = OrdenadorPacientes()
    print("Mismo contexto y mismos datos; solo cambia la estrategia:")
    for clave in ESTRATEGIAS:
        ordenador.estrategia = obtener_estrategia(clave)
        print(f"  {clave:10} -> {[p['nombre_completo'].split()[0] for p in ordenador.ordenar(demo)]}")
    print("Clave inventada cae en el orden por defecto:", obtener_estrategia("xyz").clave)
    antes = [p["id"] for p in demo]
    ordenador.ordenar(demo)
    print("La lista original no se modifica:", antes == [p["id"] for p in demo])

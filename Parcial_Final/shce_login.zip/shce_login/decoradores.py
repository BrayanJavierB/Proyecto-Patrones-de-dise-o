"""
decoradores.py
---------------
Implementación del patrón de diseño DECORATOR (estructural), usado para
agregarle responsabilidades OPCIONALES a una exportación de historia
clínica (anonimizar, sellar con un hash de integridad, auditar) sin
modificar las clases de exportación y sin crear una subclase por cada
combinación posible.

¿Por qué Decorator aquí?
------------------------
El Factory Method (exportadores.py) ya resuelve CÓMO se genera cada
formato: PDF, TXT o CSV. Pero al exportar una historia clínica casi
siempre aparecen requisitos extra que NO dependen del formato y que el
usuario quiere activar o no según el caso:

  - Anonimizar:  compartir la historia con un tercero sin exponer la identidad.
  - Sellar:      entregar el archivo junto con su huella SHA-256 para que quien
                 lo reciba pueda comprobar que no fue alterado.
  - Auditar:     dejar registrado quién exportó qué historia (obligatorio en
                 software clínico).

Resolverlo con herencia sería una explosión de subclases: ExportadorPDF,
ExportadorPDFAnonimizado, ExportadorPDFSellado, ExportadorPDFAnonimizadoSellado...
y lo mismo para TXT y CSV (3 formatos x 2^3 combinaciones = 24 clases).
Resolverlo con `if` dentro de cada exportador mezclaría responsabilidades
que no le corresponden a un generador de PDF.

Con Decorator, cada responsabilidad es UNA clase que:
  1. Cumple la MISMA interfaz que el exportador (ExportadorHistoriaClinica),
     así que el código cliente no nota la diferencia.
  2. Guarda una referencia al exportador que envuelve (otro decorador o el
     exportador real), delega en él y añade su propio comportamiento antes
     o después.
Como un decorador también es un exportador, se pueden apilar en cualquier
cantidad y combinación, decidiéndolo en tiempo de ejecución.

Estructura del patrón en este archivo:
  Componente           -> ExportadorHistoriaClinica   (exportadores.py)
  Componentes concretos-> ExportadorPDF, ExportadorTXT, ExportadorCSV (exportadores.py)
  Decorador base       -> ExportadorDecorador
  Decoradores concretos-> ExportadorAnonimizado, ExportadorConSelloIntegridad,
                          ExportadorConAuditoria

Cómo colabora con los patrones que ya existen en el proyecto:
  - Factory Method : fabrica el exportador BASE (el que se decora).
  - Composite      : exportar una carpeta aplica los mismos decoradores a cada historia.
  - Singleton      : la auditoría se guarda con la única instancia de DatabaseManager.
  Decorator NO reemplaza a ninguno: se coloca entre la fábrica y el uso del objeto.

Nota sobre el ORDEN: importa. `decoradores_para()` apila siempre en este
orden, de adentro hacia afuera: anonimizar -> sellar -> auditar.
  - El sello se calcula DESPUÉS de anonimizar, así el hash corresponde al
    archivo que realmente se entrega (si fuera al revés, sellaría datos que
    nunca salen del sistema).
  - La auditoría va por fuera para ver la historia REAL del paciente (quién
    accedió a quién) y el resultado final de la cadena, y para registrar solo
    cuando todo lo de adentro terminó bien.
"""

import copy
import hashlib
import io
import re
import zipfile
from typing import Callable, Iterator

from exportadores import ExportadorHistoriaClinica


# =====================================================================
# DECORADOR BASE
# =====================================================================
class ExportadorDecorador(ExportadorHistoriaClinica):
    """
    Decorador base: ES un ExportadorHistoriaClinica (misma interfaz) y TIENE
    otro exportador adentro. Por defecto delega todo en el envuelto; cada
    decorador concreto sobrescribe solo lo que quiere cambiar.
    """

    #: nombre corto del decorador, usado en la bitácora de auditoría
    etiqueta: str = "decorador"

    def __init__(self, envuelto: ExportadorHistoriaClinica):
        self._envuelto = envuelto

    # --- Interfaz del componente: por defecto, igual que el envuelto ---
    @property
    def extension(self) -> str:
        return self._envuelto.extension

    @property
    def mimetype(self) -> str:
        return self._envuelto.mimetype

    def nombre_base(self, paciente: dict) -> str:
        return self._envuelto.nombre_base(paciente)

    def generar(self, paciente: dict) -> bytes:
        return self._envuelto.generar(paciente)

    # --- Utilidades para inspeccionar la cadena de decoradores ---
    def cadena(self) -> Iterator["ExportadorDecorador"]:
        """Produce este decorador y los que lleva adentro, de afuera hacia adentro."""
        actual = self
        while isinstance(actual, ExportadorDecorador):
            yield actual
            actual = actual._envuelto

    @property
    def exportador_base(self) -> ExportadorHistoriaClinica:
        """El exportador real (PDF/TXT/CSV) que está en el centro de la cadena."""
        actual = self._envuelto
        while isinstance(actual, ExportadorDecorador):
            actual = actual._envuelto
        return actual


# =====================================================================
# DECORADORES CONCRETOS
# =====================================================================
def _iniciales(nombre: str) -> str:
    partes = [p for p in (nombre or "").split() if p]
    return " ".join(f"{p[0].upper()}." for p in partes) or "Paciente anónimo"


def _enmascarar_documento(documento: str) -> str:
    documento = documento or ""
    if len(documento) <= 4:
        return "*" * max(len(documento), 4)
    return "*" * (len(documento) - 4) + documento[-4:]


def anonimizar_paciente(paciente: dict) -> dict:
    """
    Devuelve una COPIA del paciente sin los datos que lo identifican
    directamente (el original no se toca):
      - nombre_completo      -> solo iniciales ("María Fernanda López" -> "M. F. L.")
      - documento            -> enmascarado, solo los 4 últimos dígitos
      - fecha_nacimiento     -> solo el año (la edad queda aproximada)
      - notas                -> omitidas, porque el texto libre suele traer nombres o teléfonos
    El contenido clínico (motivo, diagnóstico, tratamiento) se conserva.
    """
    anonimo = copy.deepcopy(paciente)
    anonimo["nombre_completo"] = _iniciales(paciente.get("nombre_completo", ""))
    anonimo["documento"] = _enmascarar_documento(paciente.get("documento", ""))

    coincidencia = re.match(r"^(\d{4})-", paciente.get("fecha_nacimiento") or "")
    anonimo["fecha_nacimiento"] = f"{coincidencia.group(1)}-01-01" if coincidencia else ""

    if (paciente.get("notas") or "").strip():
        anonimo["notas"] = "[Omitidas por anonimización]"
    return anonimo


class ExportadorAnonimizado(ExportadorDecorador):
    """
    Decorador que ANTES de delegar reemplaza los datos identificatorios del
    paciente. El exportador envuelto (sea PDF, TXT o CSV) genera el archivo
    normalmente sin saber que recibió datos anonimizados.
    """

    etiqueta = "anonimizado"

    def generar(self, paciente: dict) -> bytes:
        return self._envuelto.generar(anonimizar_paciente(paciente))

    def nombre_base(self, paciente: dict) -> str:
        # El nombre del archivo NO puede delatar el documento real. Se usa el
        # id interno (único y sin significado fuera del sistema) para que dos
        # pacientes nunca produzcan el mismo nombre dentro de un .zip.
        identificador = paciente.get("id")
        if identificador is None:
            identificador = hashlib.sha256(
                str(paciente.get("documento", "")).encode("utf-8")
            ).hexdigest()[:10]
        return f"historia_clinica_anonima_{identificador}"


class ExportadorConSelloIntegridad(ExportadorDecorador):
    """
    Decorador que DESPUÉS de delegar calcula el SHA-256 del archivo generado
    y entrega un .zip con dos cosas: el archivo original y un `.sha256` con
    su huella. Cambia el tipo de salida (ahora es un .zip), y como también
    sobrescribe `extension` y `mimetype`, el resto del sistema lo sigue
    tratando como un exportador cualquiera.

    El archivo `.sha256` usa el formato de la herramienta estándar, así que
    el destinatario puede verificarlo con:  sha256sum -c <archivo>.sha256
    """

    etiqueta = "sello_sha256"
    extension = "zip"
    mimetype = "application/zip"

    def generar(self, paciente: dict) -> bytes:
        contenido = self._envuelto.generar(paciente)
        nombre_interno = self._envuelto.nombre_archivo(paciente)
        huella = hashlib.sha256(contenido).hexdigest()

        memoria = io.BytesIO()
        with zipfile.ZipFile(memoria, "w", zipfile.ZIP_DEFLATED) as paquete:
            paquete.writestr(nombre_interno, contenido)
            paquete.writestr(f"{nombre_interno}.sha256", f"{huella}  {nombre_interno}\n")
        return memoria.getvalue()


class ExportadorConAuditoria(ExportadorDecorador):
    """
    Decorador que no cambia el archivo: solo agrega el efecto lateral de
    dejar constancia de la exportación. Recibe un `registrar` (función) en
    vez de conocer la base de datos: así el decorador no depende del
    Singleton y se puede probar con cualquier función.

    El registro ocurre DESPUÉS de generar el archivo y ANTES de devolverlo:
    si el registro falla, la excepción sube y el archivo no se entrega (en
    un sistema clínico, una exportación sin rastro es peor que una fallida).
    """

    etiqueta = "auditoria"

    def __init__(self, envuelto: ExportadorHistoriaClinica,
                 registrar: Callable[[dict], None], usuario: str):
        super().__init__(envuelto)
        self._registrar = registrar
        self._usuario = usuario

    def generar(self, paciente: dict) -> bytes:
        contenido = super().generar(paciente)
        self._registrar({
            "usuario": self._usuario,
            "paciente_id": paciente.get("id"),
            "documento": paciente.get("documento", ""),   # el REAL: este decorador va por fuera
            "formato": self.exportador_base.extension,
            "opciones": ",".join(d.etiqueta for d in self.cadena() if d is not self),
        })
        return contenido


# =====================================================================
# PUNTO DE ENTRADA: de opciones del formulario a cadena de decoradores
# =====================================================================
#: Opciones que el usuario puede activar desde la interfaz web, en el orden en que se muestran.
OPCIONES_EXPORTACION = [
    ("anonimizar", "Anonimizar datos personales"),
    ("sello", "Sello de integridad SHA-256 (.zip)"),
]
_OPCIONES_VALIDAS = {valor for valor, _ in OPCIONES_EXPORTACION}


def opciones_validas(solicitadas) -> list:
    """Se queda solo con las opciones conocidas y sin repetir (ignora cualquier otra cosa en la URL)."""
    return [valor for valor, _ in OPCIONES_EXPORTACION if valor in set(solicitadas or [])]


def decoradores_para(opciones, usuario: str = None, registrar: Callable[[dict], None] = None) -> list:
    """
    Devuelve la lista de "envolturas" (funciones exportador -> exportador) a
    aplicar, de adentro hacia afuera, según las opciones pedidas. Si se pasa
    `registrar`, la auditoría se agrega SIEMPRE (no es opcional para el usuario).

    Es una lista de funciones y no de decoradores ya creados porque cada
    decorador necesita saber a quién envuelve, y eso solo se conoce cuando
    el Factory Method entrega el exportador base.
    """
    opciones = set(opciones_validas(opciones))
    envolturas = []
    if "anonimizar" in opciones:
        envolturas.append(ExportadorAnonimizado)
    if "sello" in opciones:
        envolturas.append(ExportadorConSelloIntegridad)
    if registrar is not None:
        envolturas.append(lambda exportador: ExportadorConAuditoria(exportador, registrar, usuario or "desconocido"))
    return envolturas


if __name__ == "__main__":
    # Demostración sin Flask: el mismo código cliente usa un exportador
    # "pelado" y uno con tres capas, sin enterarse de la diferencia.
    from exportadores import obtener_creador

    paciente_demo = {
        "id": 7, "nombre_completo": "María Fernanda López", "documento": "1098765432",
        "fecha_nacimiento": "1990-04-12", "motivo_consulta": "Dolor abdominal recurrente",
        "diagnostico": "Gastritis crónica", "tratamiento": "Omeprazol 20mg",
        "notas": "Llamar al 3001234567 si empeora.", "tipo_atencion": "consulta_general",
        "registrado_por": "admin", "creado_en": "2026-09-01 10:00:00",
    }
    bitacora = []

    for formato in ("txt", "csv", "pdf"):
        creador = obtener_creador(formato)
        contenido, mimetype, nombre = creador.exportar_historia(paciente_demo)
        print(f"[{formato}] sin decorar     -> {nombre} ({mimetype}, {len(contenido)} bytes)")

        envolturas = decoradores_para(["anonimizar", "sello"], "brayan", bitacora.append)
        contenido, mimetype, nombre = creador.exportar_historia(paciente_demo, envolturas)
        print(f"[{formato}] 3 decoradores   -> {nombre} ({mimetype}, {len(contenido)} bytes)")

    # Se ve qué hay adentro del paquete sellado (el último fue el PDF).
    with zipfile.ZipFile(io.BytesIO(contenido)) as paquete:
        print("\nContenido del .zip sellado:", paquete.namelist())
        sello = paquete.read(paquete.namelist()[1]).decode()
        archivo = paquete.read(paquete.namelist()[0])
        print("Sello      :", sello.strip())
        print("¿Coincide? :", hashlib.sha256(archivo).hexdigest() == sello.split()[0])

    # Se ve el efecto de anonimizar sobre el TXT.
    txt = obtener_creador("txt").exportar_historia(
        paciente_demo, decoradores_para(["anonimizar"]))[0].decode()
    print("\n" + "\n".join(txt.splitlines()[3:6] + txt.splitlines()[-4:-2]))

    print("\nBitácora de auditoría (la historia REAL queda registrada):")
    for evento in bitacora:
        print("  ", evento)
    print("\nEl original no se modificó:", paciente_demo["nombre_completo"], paciente_demo["documento"])

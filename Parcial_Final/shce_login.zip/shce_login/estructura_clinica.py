"""
estructura_clinica.py
----------------------
Implementación del patrón de diseño COMPOSITE (estructural), usado para
organizar las historias clínicas del SHCE en un ÁRBOL de carpetas y poder
operar sobre una historia suelta, sobre una carpeta o sobre todo el
árbol exactamente con el mismo código.

¿Por qué Composite aquí?
------------------------
Hasta ahora, cada operación del SHCE trabaja con UN paciente a la vez:
exportar una historia (Factory Method), notificar una historia (Bridge),
mostrar su etiqueta (Abstract Factory)... Pero en la vida real el equipo
clínico piensa en GRUPOS:

  - "Exporta todo lo que registró el Dr. Brayan."
  - "Avisa al equipo de todas las urgencias de prioridad alta."
  - "¿Cuántas historias de control tenemos?"

Sin Composite, el código cliente (las rutas de Flask) tendría que
distinguir con `if` entre "es un paciente" y "es un grupo de pacientes",
y recorrer los grupos a mano, con bucles anidados que cambian cada vez
que cambia la forma del árbol.

Composite resuelve esto con UNA interfaz común (ComponenteClinico) que
cumplen tanto las HOJAS (una historia clínica) como los COMPUESTOS (una
carpeta que contiene hojas y/u otras carpetas). El cliente llama
`nodo.exportar("csv")` o `nodo.notificar("urgencia", "email")` sin
saber (ni importarle) si `nodo` es un paciente o un grupo de 200.

Estructura del patrón en este archivo:
  Componente (interfaz común) -> ComponenteClinico
  Hoja                        -> HistoriaClinicaHoja   (un paciente)
  Compuesto                   -> GrupoClinico          (una carpeta)

Cómo colabora con los patrones que ya existen en el proyecto:
  - Singleton       : `db.obtener_pacientes()` alimenta la construcción del árbol.
  - Abstract Factory: la hoja pide su formateador para la etiqueta/color.
  - Factory Method  : la hoja pide su creador de exportación (PDF/TXT/CSV).
  - Decorator       : al exportar un grupo, las mismas envolturas (anonimizar,
                      sellar, auditar) se aplican a cada historia del árbol.
  - Bridge          : la hoja arma la notificación (tipo x canal).
  Composite NO reemplaza a ninguno: solo permite aplicarlos a un grupo
  completo con una sola llamada.
  - Visitor         : los nodos aceptan visitantes (`aceptar`), de modo que
                      reportes nuevos (estadísticas, completitud, controles)
                      recorren el árbol SIN agregar métodos a hojas ni grupos.

Variante usada (nota honesta): en el Composite clásico del GoF hay dos
estilos. En el "transparente" la interfaz común también declara
agregar()/quitar(), y las hojas las implementan lanzando error. Aquí
usamos el estilo "seguro": agregar()/quitar() existen SOLO en
GrupoClinico, porque no tiene sentido "agregarle un hijo a un paciente".
La contrapartida es que, para armar el árbol, hay que saber que se está
hablando con un grupo; para OPERAR sobre el árbol (contar, exportar,
notificar, buscar) la uniformidad es total.
"""

from iteradores import ColeccionIterable, IteradorProfundidad, IteradorAnchura, IteradorHojas  # Iterator
from visitantes import ElementoVisitable                                                       # Visitor
from abc import ABC, abstractmethod

# Reutilizamos los patrones ya existentes (ver el docstring del módulo).
from fabricas import obtener_fabrica, TIPOS_ATENCION
from exportadores import obtener_creador
from notificaciones import construir_notificacion


# =====================================================================
# COMPONENTE: la interfaz común de hojas y compuestos
# =====================================================================
class ComponenteClinico(ColeccionIterable, ElementoVisitable):
    """
    Interfaz que cumple CUALQUIER nodo del árbol clínico, sea una
    historia suelta o una carpeta con cientos. El código cliente solo
    conoce esta clase.
    """

    #: Permite a las plantillas y al cliente distinguir carpeta de historia
    #: SOLO cuando necesitan dibujarlas distinto (no para operar sobre ellas).
    es_grupo = False

    def __init__(self, clave: str, nombre: str):
        # `clave` identifica el nodo dentro del árbol (se usa en las URLs).
        # `nombre` es el texto legible que se muestra en pantalla.
        self.clave = clave
        self.nombre = nombre

    # ---- Operaciones uniformes: se llaman igual sobre hoja o compuesto ----
    @abstractmethod
    def contar_historias(self) -> int:
        """Cuántas historias clínicas hay en este nodo (1 para una hoja)."""
        raise NotImplementedError

    @abstractmethod
    def obtener_historias(self) -> list:
        """Lista PLANA con los diccionarios de todos los pacientes del nodo."""
        raise NotImplementedError

    @abstractmethod
    def exportar(self, formato: str, decoradores=()) -> list:
        """
        Exporta todas las historias del nodo en el formato pedido
        ("pdf", "txt" o "csv") usando el Factory Method. `decoradores` son
        las envolturas opcionales del patrón Decorator (decoradores.py) y se
        aplican a CADA historia. Devuelve una lista de tuplas
        (nombre_de_archivo, contenido_en_bytes), una por historia.
        """
        raise NotImplementedError

    @abstractmethod
    def notificar(self, tipo: str, canal: str) -> list:
        """
        Envía una notificación (Bridge: tipo x canal) por CADA historia
        del nodo. Devuelve la lista de resultados de envío.
        """
        raise NotImplementedError

    @abstractmethod
    def a_diccionario(self) -> dict:
        """Representación en diccionarios anidados, lista para la plantilla."""
        raise NotImplementedError

    # ---- Operaciones con comportamiento por defecto (el de una hoja) ----
    def buscar(self, clave: str):
        """Devuelve el nodo con esa clave dentro de este nodo, o None."""
        return self if self.clave == clave else None

    # ---- Iterator: este nodo es el AGREGADO que fabrica iteradores sobre sí mismo ----
    RECORRIDOS = {
        "profundidad": IteradorProfundidad,   # (nivel, nodo), cada carpeta junto a su contenido
        "anchura": IteradorAnchura,           # (nivel, nodo), piso por piso
        "hojas": IteradorHojas,               # solo las historias clínicas (nodos hoja)
    }

    def crear_iterador(self, recorrido: str = "profundidad"):
        """
        Devuelve un iterador (iteradores.py) que recorre este nodo y todo lo
        que contiene con la estrategia pedida: "profundidad", "anchura" u
        "hojas". Una hoja se recorre a sí misma; un grupo, a todo su subárbol.
        """
        try:
            return self.RECORRIDOS[recorrido](self)
        except KeyError:
            raise ValueError(
                f"Recorrido no soportado: {recorrido!r}. Usa uno de {sorted(self.RECORRIDOS)}."
            ) from None

    def recorrer(self, nivel: int = 0):
        """
        Produce (profundidad, nodo) en preorden: primero el propio nodo y
        luego, si es un grupo, todos sus descendientes. Es el recorrido
        "profundidad" de `crear_iterador`, empezando en el nivel dado. Se
        escribe UNA sola vez para hojas y grupos: ya no hay recursión duplicada.
        """
        return IteradorProfundidad(self, nivel)


# =====================================================================
# HOJA: una historia clínica (un paciente)
# =====================================================================
class HistoriaClinicaHoja(ComponenteClinico):
    """
    Hoja del árbol: envuelve el diccionario de UN paciente (tal como lo
    entrega DatabaseManager.obtener_paciente). No tiene hijos; cada
    operación uniforme se resuelve aquí mismo, apoyándose en los patrones
    ya existentes.
    """

    def __init__(self, paciente: dict):
        identificador = paciente.get("id", paciente.get("documento"))
        super().__init__(clave=f"paciente-{identificador}", nombre=paciente["nombre_completo"])
        self.paciente = paciente

    def contar_historias(self) -> int:
        return 1

    def obtener_historias(self) -> list:
        return [self.paciente]

    def exportar(self, formato: str, decoradores=()) -> list:
        # Factory Method: el creador concreto decide qué exportador usar.
        # Decorator: las envolturas se aplican sobre ese exportador.
        creador = obtener_creador(formato)
        contenido, _mimetype, nombre_archivo = creador.exportar_historia(self.paciente, decoradores)
        return [(nombre_archivo, contenido)]

    def notificar(self, tipo: str, canal: str) -> list:
        # Bridge: se conecta el TIPO de notificación con el CANAL elegido.
        notificacion = construir_notificacion(tipo, canal)
        resultado = notificacion.enviar_para(self.paciente)
        resultado["paciente_nombre"] = self.paciente.get("nombre_completo", "")
        return [resultado]

    def aceptar(self, visitante):
        # Visitor, primer salto del doble despacho: la hoja sabe que es una historia.
        visitante.visitar_historia(self)
        return visitante

    def a_diccionario(self) -> dict:
        # Abstract Factory: etiqueta y color salen de la MISMA familia.
        fabrica = obtener_fabrica(self.paciente.get("tipo_atencion"))
        formateador = fabrica.crear_formateador()
        return {
            "es_grupo": False,
            "clave": self.clave,
            "nombre": self.nombre,
            "documento": self.paciente.get("documento", ""),
            "etiqueta": formateador.etiqueta(self.paciente),
            "color": formateador.color_css,
            "total": 1,
        }


# =====================================================================
# COMPUESTO: una carpeta que contiene hojas y/u otras carpetas
# =====================================================================
class GrupoClinico(ComponenteClinico):
    """
    Compuesto: guarda una lista de ComponenteClinico (hojas u otros
    grupos, sin distinguirlos) y resuelve cada operación DELEGÁNDOLA en
    sus hijos y combinando los resultados. Como los hijos pueden ser a
    su vez grupos, la recursión recorre el árbol completo sin ningún
    bucle anidado escrito a mano.
    """

    es_grupo = True

    def __init__(self, clave: str, nombre: str):
        super().__init__(clave, nombre)
        self._hijos = []

    # ---- Gestión de hijos (solo existe en el compuesto: variante "segura") ----
    @property
    def hijos(self) -> tuple:
        """Los hijos directos, en solo lectura (una tupla no se puede alterar desde fuera)."""
        return tuple(self._hijos)

    def agregar(self, componente: ComponenteClinico) -> "GrupoClinico":
        """Agrega un hijo (hoja o grupo). Devuelve self para poder encadenar."""
        self._hijos.append(componente)
        return self

    def quitar(self, componente: ComponenteClinico) -> "GrupoClinico":
        """Quita un hijo directo. Devuelve self para poder encadenar."""
        self._hijos.remove(componente)
        return self

    # ---- Operaciones uniformes: delegar en los hijos y combinar ----
    def contar_historias(self) -> int:
        return sum(hijo.contar_historias() for hijo in self._hijos)

    def obtener_historias(self) -> list:
        # Lista plana de las historias del subárbol: justo para lo que sirve un iterador de hojas.
        return [hoja.paciente for hoja in self.crear_iterador("hojas")]

    def exportar(self, formato: str, decoradores=()) -> list:
        return [archivo for hijo in self._hijos for archivo in hijo.exportar(formato, decoradores)]

    def notificar(self, tipo: str, canal: str) -> list:
        return [resultado for hijo in self._hijos for resultado in hijo.notificar(tipo, canal)]

    def aceptar(self, visitante):
        # Visitor: el grupo avisa que entra, deja que cada hijo (hoja o grupo,
        # sin distinguirlos) reciba al visitante, y avisa que sale. El
        # recorrido vive aquí, así ningún visitante repite la lógica de recorrer.
        visitante.entrar_grupo(self)
        for hijo in self._hijos:
            hijo.aceptar(visitante)
        visitante.salir_grupo(self)
        return visitante

    def buscar(self, clave: str):
        if self.clave == clave:
            return self
        for hijo in self._hijos:
            encontrado = hijo.buscar(clave)   # misma llamada, sea hoja o grupo
            if encontrado is not None:
                return encontrado
        return None

    def a_diccionario(self) -> dict:
        return {
            "es_grupo": True,
            "clave": self.clave,
            "nombre": self.nombre,
            "total": self.contar_historias(),
            "hijos": [hijo.a_diccionario() for hijo in self._hijos],
        }


# =====================================================================
# CONSTRUCCIÓN DEL ÁRBOL a partir de los pacientes de la base de datos
# =====================================================================
# Cada "nivel" describe cómo se agrupan los pacientes en ese piso del árbol:
#   valor    -> de dónde sale la clave de agrupación (None = "no aplica")
#   etiqueta -> cómo se muestra el nombre de la carpeta
#   orden    -> cómo se ordenan las carpetas hermanas
# Si un paciente devuelve None en un nivel, NO se crea carpeta para él ahí:
# salta al siguiente nivel (o queda colgado directo de la carpeta actual).
# Por eso en la agrupación "tipo -> prioridad" solo Urgencias tiene
# subcarpetas de prioridad, y las demás carpetas contienen historias directas
# (un mismo grupo puede mezclar hojas y compuestos: justo lo que permite Composite).
_ORDEN_TIPOS = [valor for valor, _ in TIPOS_ATENCION]

_NIVELES = {
    "medico": {
        "valor": lambda p: p.get("registrado_por") or "(sin registrar)",
        "etiqueta": lambda v: f"Registrado por {v}",
        "orden": lambda v: v.lower(),
    },
    "tipo": {
        "valor": lambda p: p.get("tipo_atencion") or "consulta_general",
        "etiqueta": lambda v: dict(TIPOS_ATENCION).get(v, v),
        "orden": lambda v: _ORDEN_TIPOS.index(v) if v in _ORDEN_TIPOS else len(_ORDEN_TIPOS),
    },
    "prioridad": {
        "valor": lambda p: (p.get("prioridad") or None) if p.get("tipo_atencion") == "urgencias" else None,
        "etiqueta": lambda v: f"Prioridad {v}",
        "orden": lambda v: {"alta": 0, "media": 1, "baja": 2}.get(v, 9),
    },
}

#: Agrupaciones disponibles: qué niveles se aplican, de arriba hacia abajo.
AGRUPACIONES = {
    "medico": {"titulo": "Por médico → tipo de atención", "niveles": ("medico", "tipo")},
    "tipo": {"titulo": "Por tipo de atención → prioridad", "niveles": ("tipo", "prioridad")},
}

#: Para poblar el selector de la interfaz web.
AGRUPACIONES_OPCIONES = [(clave, datos["titulo"]) for clave, datos in AGRUPACIONES.items()]


def _agrupar(pacientes: list, niveles: tuple, grupo: GrupoClinico) -> None:
    """Reparte `pacientes` dentro de `grupo` aplicando, recursivamente, los niveles restantes."""
    if not pacientes:
        return

    if not niveles:
        for paciente in pacientes:
            grupo.agregar(HistoriaClinicaHoja(paciente))
        return

    nivel, resto = niveles[0], niveles[1:]
    definicion = _NIVELES[nivel]

    por_valor, sin_valor = {}, []
    for paciente in pacientes:
        valor = definicion["valor"](paciente)
        if valor is None:
            sin_valor.append(paciente)
        else:
            por_valor.setdefault(valor, []).append(paciente)

    for valor in sorted(por_valor, key=definicion["orden"]):
        subgrupo = GrupoClinico(f"{grupo.clave}/{nivel}={valor}", definicion["etiqueta"](valor))
        grupo.agregar(subgrupo)
        _agrupar(por_valor[valor], resto, subgrupo)

    # Los que no aplican a este nivel siguen al siguiente, dentro de la misma carpeta.
    _agrupar(sin_valor, resto, grupo)


def construir_arbol(pacientes: list, agrupacion: str = "medico") -> GrupoClinico:
    """
    Arma el árbol completo (raíz + carpetas + historias) a partir de la
    lista de pacientes. Si la agrupación pedida no existe, usa "medico".
    """
    if agrupacion not in AGRUPACIONES:
        agrupacion = "medico"
    raiz = GrupoClinico("raiz", "Todas las historias clínicas")
    _agrupar(list(pacientes), AGRUPACIONES[agrupacion]["niveles"], raiz)
    return raiz


if __name__ == "__main__":
    # Demostración sin Flask: el MISMO código opera sobre una hoja, una
    # carpeta y el árbol completo.
    pacientes_demo = [
        {"id": 1, "nombre_completo": "María López", "documento": "100", "tipo_atencion": "consulta_general",
         "registrado_por": "admin", "motivo_consulta": "Dolor abdominal"},
        {"id": 2, "nombre_completo": "Carlos Pérez", "documento": "200", "tipo_atencion": "control",
         "fecha_proximo_control": "2026-10-05", "registrado_por": "brayan"},
        {"id": 3, "nombre_completo": "Sofía Ramírez", "documento": "300", "tipo_atencion": "urgencias",
         "prioridad": "alta", "registrado_por": "brayan", "motivo_consulta": "Disnea"},
        {"id": 4, "nombre_completo": "Luis Gómez", "documento": "400", "tipo_atencion": "urgencias",
         "prioridad": "baja", "registrado_por": "admin", "motivo_consulta": "Esguince"},
    ]

    for agrupacion in AGRUPACIONES:
        raiz = construir_arbol(pacientes_demo, agrupacion)
        print(f"\n=== Agrupación: {AGRUPACIONES[agrupacion]['titulo']} ===")
        for nivel, nodo in raiz.recorrer():
            tipo_nodo = "📁" if nodo.es_grupo else "📄"
            print(f"{'    ' * nivel}{tipo_nodo} {nodo.nombre} ({nodo.contar_historias()})")

    raiz = construir_arbol(pacientes_demo, "tipo")
    urgencias = raiz.buscar("raiz/tipo=urgencias")
    sofia = raiz.buscar("paciente-3")

    print("\n--- Misma llamada, distinto tipo de nodo ---")
    for nodo in (sofia, urgencias, raiz):
        archivos = nodo.exportar("csv")
        print(f"{type(nodo).__name__:22} '{nodo.nombre}': "
              f"{nodo.contar_historias()} historia(s), {len(archivos)} archivo(s) CSV")

    envios = urgencias.notificar("urgencia", "sms")
    print(f"\nNotificar a '{urgencias.nombre}' -> {len(envios)} SMS simulados:")
    for envio in envios:
        print("  ", envio["mensaje_final"])

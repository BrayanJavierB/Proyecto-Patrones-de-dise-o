"""
iteradores.py
-------------
Implementación del patrón de diseño ITERATOR (comportamiento): una forma
uniforme de recorrer los elementos de una colección, UNO A UNO, sin que
quien recorre tenga que conocer cómo está organizada por dentro.

¿Por qué Iterator aquí?
-----------------------
El proyecto recorre colecciones de formas muy distintas:

  - el árbol de carpetas del Composite (hojas dentro de grupos dentro de grupos),
  - los registros del sistema externo (que hay que pedir de a uno, y cada
    pedido puede costar una llamada a un tercero),
  - el historial de notificaciones (una lista que crece, de la que solo se
    quieren los envíos que cumplan cierto criterio).

Antes, cada una de esas formas de recorrer vivía mezclada con la lógica de
quien la necesitaba: una recursión escrita dos veces en el Composite (una
en la hoja y otra en el grupo), una comprensión de listas que pedía los
registros externos en bloque, un corte `[:limite]` sin filtros. Con Iterator
cada forma de recorrer es un OBJETO con un contrato único:

    iterador.hay_siguiente()   ->  ¿queda algo por entregar?
    iterador.siguiente()       ->  entrega el siguiente elemento
    iterador.reiniciar()       ->  vuelve al principio

y además funciona directamente en un `for` (protocolo `__iter__`/`__next__`
de Python), así que el cliente escribe `for nivel, nodo in raiz.recorrer():`
sin saber si por detrás hay una pila, una cola o llamadas de red.

Estructura del patrón en este archivo:
  Iterator (interfaz)       -> Iterador
  ConcreteIterator          -> IteradorProfundidad, IteradorAnchura, IteradorHojas,
                               IteradorRegistrosExternos, IteradorHistorial
  Aggregate (interfaz)      -> ColeccionIterable (define `crear_iterador`)
  ConcreteAggregate         -> ComponenteClinico (estructura_clinica.py): el nodo del
                               Composite crea su iterador según el recorrido pedido
  Cliente                   -> la fachada (fachada.py) y el propio Composite

Decisiones de diseño:
  - ITERADOR EXTERNO: es el cliente quien decide cuándo pedir el siguiente
    elemento (a diferencia de un `forEach` que recorre todo de golpe). Eso
    permite detenerse a mitad de camino, y es lo que hace útil la pereza.
  - PEREZA (lazy): los iteradores no hacen trabajo hasta que se les pide un
    elemento. Crear un `IteradorRegistrosExternos` no llama al sistema
    externo; cada `siguiente()` pide exactamente UN registro.
  - SIN RECURSIÓN: los recorridos del árbol usan una pila (profundidad) o una
    cola (anchura) explícitas. Por eso no dependen del límite de recursión de
    Python y cambiar de estrategia es cambiar de estructura de datos, nada más.
  - ESTADO PROPIO: cada iterador guarda su posición. Se pueden tener varios
    recorridos simultáneos sobre la misma colección sin que se estorben.
  - INSTANTÁNEA donde la colección cambia: `IteradorHistorial` trabaja sobre
    una copia de la lista al crearse (o reiniciarse). Si llegan notificaciones
    nuevas durante el recorrido, no se desordena ni se repite nada.
  - Los iteradores del árbol NO importan `estructura_clinica`: solo usan lo
    que cualquier nodo ofrece (`es_grupo` y, si es grupo, `hijos`). Así no hay
    dependencia circular y sirven para cualquier árbol con esa forma.
"""

from abc import ABC, abstractmethod
from collections import deque

_SIN_ADELANTAR = object()   # marca: "todavía no hay un elemento mirado por adelantado"


# =====================================================================
# INTERFAZ DEL ITERADOR
# =====================================================================
class Iterador(ABC):
    """
    Contrato común de todos los iteradores.

    Las subclases solo escriben dos métodos pequeños:
      _producir()   -> devuelve el siguiente elemento o lanza StopIteration.
      _reiniciar()  -> deja su estado interno como al principio.
    De lo demás (hay_siguiente, siguiente, reiniciar y el protocolo de `for`)
    se encarga esta clase base, que mira UN elemento por adelantado para poder
    responder `hay_siguiente()` sin perderlo.
    """

    def __init__(self):
        self._adelantado = _SIN_ADELANTAR
        self._reiniciar()

    # ---- lo que implementa cada iterador concreto ----
    @abstractmethod
    def _producir(self):
        """Siguiente elemento, o `raise StopIteration` si no queda ninguno."""
        raise NotImplementedError

    @abstractmethod
    def _reiniciar(self) -> None:
        """Vuelve el estado interno al punto de partida."""
        raise NotImplementedError

    # ---- el contrato público del patrón ----
    def hay_siguiente(self) -> bool:
        """True si todavía queda al menos un elemento por entregar."""
        if self._adelantado is _SIN_ADELANTAR:
            try:
                self._adelantado = self._producir()
            except StopIteration:
                return False
        return True

    def siguiente(self):
        """Entrega el siguiente elemento. Lanza StopIteration si ya no hay más."""
        if not self.hay_siguiente():
            raise StopIteration
        elemento, self._adelantado = self._adelantado, _SIN_ADELANTAR
        return elemento

    def reiniciar(self) -> "Iterador":
        """Vuelve al principio para recorrer otra vez. Devuelve self."""
        self._adelantado = _SIN_ADELANTAR
        self._reiniciar()
        return self

    # ---- protocolo de Python: permite usarlo en `for`, list(), etc. ----
    def __iter__(self):
        return self

    def __next__(self):
        return self.siguiente()


# =====================================================================
# INTERFAZ DEL AGREGADO
# =====================================================================
class ColeccionIterable(ABC):
    """
    Una colección que sabe fabricar iteradores sobre sí misma. El cliente le
    pide un iterador por NOMBRE de recorrido y no necesita saber qué clase
    concreta lo implementa.
    """

    @abstractmethod
    def crear_iterador(self, *args, **kwargs) -> Iterador:
        raise NotImplementedError


# =====================================================================
# ITERADORES SOBRE EL ÁRBOL (Composite)
# =====================================================================
class IteradorProfundidad(Iterador):
    """
    Recorrido en PROFUNDIDAD, en preorden: primero el nodo y luego, de uno en
    uno, todos los descendientes de su primer hijo, después los del segundo...
    Entrega tuplas (nivel, nodo). Usa una PILA.

    Es el orden natural para mostrar el árbol con sangría (cada carpeta
    aparece justo encima de lo que contiene).
    """

    def __init__(self, raiz, nivel_inicial: int = 0):
        self._raiz = raiz
        self._nivel_inicial = nivel_inicial
        super().__init__()

    def _reiniciar(self):
        self._pila = [(self._nivel_inicial, self._raiz)]

    def _producir(self):
        if not self._pila:
            raise StopIteration
        nivel, nodo = self._pila.pop()
        # Se apilan al revés para que el PRIMER hijo sea el primero en salir.
        for hijo in reversed(getattr(nodo, "hijos", ())):
            self._pila.append((nivel + 1, hijo))
        return nivel, nodo


class IteradorAnchura(Iterador):
    """
    Recorrido en ANCHURA: primero el nodo, luego todos los de su mismo nivel
    hacia abajo, piso por piso. Entrega tuplas (nivel, nodo). Usa una COLA.

    Es el orden natural para preguntas "por piso" (¿cuántas carpetas hay en
    el segundo nivel?), porque los niveles salen en orden creciente.
    """

    def __init__(self, raiz, nivel_inicial: int = 0):
        self._raiz = raiz
        self._nivel_inicial = nivel_inicial
        super().__init__()

    def _reiniciar(self):
        self._cola = deque([(self._nivel_inicial, self._raiz)])

    def _producir(self):
        if not self._cola:
            raise StopIteration
        nivel, nodo = self._cola.popleft()
        for hijo in getattr(nodo, "hijos", ()):
            self._cola.append((nivel + 1, hijo))
        return nivel, nodo


class IteradorHojas(Iterador):
    """
    Entrega SOLO las hojas (las historias clínicas), en el mismo orden que el
    recorrido en profundidad, saltándose las carpetas. Entrega el nodo hoja.

    Se construye sobre IteradorProfundidad: un iterador puede apoyarse en otro
    en lugar de repetir su lógica.
    """

    def __init__(self, raiz, nivel_inicial: int = 0):
        self._raiz = raiz
        self._nivel_inicial = nivel_inicial
        super().__init__()

    def _reiniciar(self):
        self._base = IteradorProfundidad(self._raiz, self._nivel_inicial)

    def _producir(self):
        for _nivel, nodo in self._base:
            if not nodo.es_grupo:
                return nodo
        raise StopIteration


# =====================================================================
# ITERADOR SOBRE EL SISTEMA EXTERNO (Adapter + Proxy)
# =====================================================================
class IteradorRegistrosExternos(Iterador):
    """
    Recorre las historias del sistema externo pidiendo UNA por vez.

    Entrega diccionarios {"codigo": ..., **registro_en_formato_crudo}.

    Es perezoso: al crearlo no se llama al sistema; la lista de códigos se
    pide cuando se solicita el primer elemento, y cada `siguiente()` consulta
    un solo registro. Si el cliente se detiene a la mitad, los registros que
    no pidió nunca se consultan. Si el sistema es el ProxySistemaExterno, cada
    consulta pasa por su caché sin que el iterador lo sepa.

    `sistema` es cualquier objeto con `listar_codigos_disponibles()` y
    `consultar_registro(codigo)`.
    """

    def __init__(self, sistema):
        self._sistema = sistema
        super().__init__()

    def _reiniciar(self):
        self._codigos = None   # todavía no se le ha preguntado nada al sistema
        self._posicion = 0

    def _producir(self):
        if self._codigos is None:
            self._codigos = list(self._sistema.listar_codigos_disponibles())
        if self._posicion >= len(self._codigos):
            raise StopIteration
        codigo = self._codigos[self._posicion]
        self._posicion += 1
        return {"codigo": codigo, **self._sistema.consultar_registro(codigo)}


# =====================================================================
# ITERADOR SOBRE EL HISTORIAL DE NOTIFICACIONES (Bridge)
# =====================================================================
class IteradorHistorial(Iterador):
    """
    Recorre el historial de notificaciones entregando solo los envíos que
    cumplan TODOS los filtros dados, y como máximo `limite` de ellos.

      tipo_notificacion -> p. ej. "urgencia"
      canal             -> p. ej. "sms"
      paciente          -> p. ej. "sofía"
      limite            -> None = sin tope

    Cada filtro compara si el texto buscado está CONTENIDO en el campo, sin
    distinguir mayúsculas (los resultados guardan nombres legibles como
    "Consola / log interno", no claves). Un filtro en None se ignora. Con
    todos los filtros en None y un límite, equivale a `historial[:limite]`.

    Trabaja sobre una INSTANTÁNEA del historial tomada al crearse (o al
    reiniciarse), así que no le afectan los envíos que lleguen durante el recorrido.
    """

    _CAMPOS = (("tipo_notificacion", "tipo_notificacion"), ("canal", "canal"), ("paciente", "paciente_nombre"))

    def __init__(self, historial, tipo_notificacion=None, canal=None, paciente=None, limite=None):
        self._historial = historial
        self._filtros = [
            (campo, str(buscado).lower())
            for (parametro, campo), buscado in zip(self._CAMPOS, (tipo_notificacion, canal, paciente))
            if buscado
        ]
        self._limite = limite
        super().__init__()

    def _reiniciar(self):
        self._instantanea = tuple(self._historial)
        self._posicion = 0
        self._entregados = 0

    def _cumple(self, envio: dict) -> bool:
        return all(buscado in str(envio.get(campo, "")).lower() for campo, buscado in self._filtros)

    def _producir(self):
        if self._limite is not None and self._entregados >= self._limite:
            raise StopIteration
        while self._posicion < len(self._instantanea):
            envio = self._instantanea[self._posicion]
            self._posicion += 1
            if self._cumple(envio):
                self._entregados += 1
                return envio
        raise StopIteration


if __name__ == "__main__":
    # Demostración sin Flask y sin base de datos. Muestra los cinco iteradores.
    from estructura_clinica import construir_arbol

    def paciente(i, nombre, tipo, prioridad=None):
        return {"id": i, "nombre_completo": nombre, "documento": f"100{i}", "fecha_nacimiento": "1990-01-01",
                "tipo_atencion": tipo, "prioridad": prioridad, "fecha_proximo_control": None,
                "registrado_por": "admin"}

    raiz = construir_arbol([
        paciente(1, "María López", "consulta_general"),
        paciente(2, "Sofía Ramírez", "urgencias", "alta"),
        paciente(3, "Luis Gómez", "urgencias", "baja"),
        paciente(4, "Carlos Pérez", "control"),
    ], "tipo")

    print("1) En PROFUNDIDAD (pila): cada carpeta junto a su contenido")
    for nivel, nodo in raiz.crear_iterador("profundidad"):
        print("   " + "    " * nivel + ("📁 " if nodo.es_grupo else "📄 ") + nodo.nombre)

    print("2) En ANCHURA (cola): piso por piso")
    for nivel, nodo in raiz.crear_iterador("anchura"):
        print(f"   nivel {nivel}: {nodo.nombre}")

    print("3) Solo HOJAS:", [hoja.nombre for hoja in raiz.crear_iterador("hojas")])

    it = raiz.crear_iterador("hojas")
    print("   Contrato manual:", it.hay_siguiente(), "->", it.siguiente().nombre, "-> reiniciar ->",
          it.reiniciar().siguiente().nombre)

    class ExternoDeMentira:
        def __init__(self):
            self.llamadas = []

        def listar_codigos_disponibles(self):
            self.llamadas.append("listar")
            return ["EXT-1", "EXT-2", "EXT-3"]

        def consultar_registro(self, codigo):
            self.llamadas.append(codigo)
            return {"nombre": f"Registro {codigo}"}

    externo = ExternoDeMentira()
    registros = IteradorRegistrosExternos(externo)
    print("4) Externo perezoso: al crearlo, llamadas =", externo.llamadas)
    print("   Pido solo el primero:", registros.siguiente()["codigo"], "-> llamadas =", externo.llamadas)

    historial = [
        {"tipo_notificacion": "Urgencia", "canal": "SMS", "paciente_nombre": "Sofía Ramírez"},
        {"tipo_notificacion": "Control", "canal": "Correo electrónico", "paciente_nombre": "Carlos Pérez"},
        {"tipo_notificacion": "Urgencia", "canal": "Consola / log interno", "paciente_nombre": "Luis Gómez"},
    ]
    print("5) Historial filtrado por 'urgencia':",
          [e["paciente_nombre"] for e in IteradorHistorial(historial, tipo_notificacion="urgencia")])
    print("   Urgencias, solo 1:",
          [e["paciente_nombre"] for e in IteradorHistorial(historial, tipo_notificacion="URGENCIA", limite=1)])

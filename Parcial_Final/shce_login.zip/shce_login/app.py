"""
app.py
------
Aplicación web local (Flask) que expone el login y el registro del
Sistema de Historias Clínicas Electrónicas (SHCE).

Las rutas NO orquestan los patrones de diseño: hablan con una única
FACHADA (patrón Facade, fachada.py), que es quien coordina el Singleton,
el Builder, las fábricas, el Adapter, el Bridge, el Composite, el
Decorator, el Visitor y el resto. Aquí solo queda lo que es propio de la web: leer
el formulario, manejar la sesión, mostrar mensajes y elegir qué
plantilla o redirección devolver.

Las rutas no hablan con la fachada directamente sino a través de
`fachada_actual()`: un PROXY de protección (patrón Proxy, proxies.py) que
tiene la misma interfaz que la fachada pero comprueba el rol del usuario
antes de dejar pasar cada operación.
"""

# Flask: micro-framework web. Con esto servimos páginas HTML y procesamos formularios.
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, g

# functools.wraps: para que el decorador de login conserve el nombre y
# la documentación de la función original (buena práctica al hacer decoradores).
from functools import wraps

# io: para envolver los bytes que genera la fachada y enviarlos como descarga.
import io

# El patrón Facade: interfaz única y simplificada hacia todos los demás
# patrones. Es lo ÚNICO del núcleo del SHCE que este archivo necesita importar.
from fachada import FachadaSHCE, ErrorFachada, PacienteNoEncontrado, RegistroExternoNoEncontrado

# El patrón Proxy (de protección): se interpone entre las rutas y la fachada
# y comprueba, con el rol de la sesión, si cada operación está permitida.
from proxies import ProxyProteccionFachada, AccesoDenegado

# Creamos la aplicación Flask. __name__ le dice a Flask dónde buscar las
# carpetas "templates" y "static".
import os
import secrets
from datetime import date, timedelta

from flask import abort, jsonify
from markupsafe import Markup

from seguridad import clave_secreta_flask, clave_api_dispositivos

app = Flask(__name__)

# Clave secreta usada por Flask para firmar la cookie de sesión
# (evita que alguien falsifique su sesión). En un entorno real esto
# debería venir de una variable de entorno, no estar escrito en el código.
app.secret_key = clave_secreta_flask(os.getcwd())     # SHCE_SECRET_KEY o secret_key.key (nunca escrita en el código)

# Cookie de sesión endurecida: no accesible desde JavaScript, no se envía desde otros sitios,
# y la sesión caduca tras 30 minutos sin actividad. Con HTTPS, activa SHCE_HTTPS=1 para marcarla "Secure".
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SHCE_HTTPS") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
    CSRF_ACTIVO=True,
)
API_KEY_DISPOSITIVOS = clave_api_dispositivos(os.getcwd())   # la que deben presentar los dispositivos IoT

#: Rutas que no usan el token CSRF porque no las llama un navegador con sesión (la API se autentica con clave).
_RUTAS_SIN_CSRF = {"api_signos"}


@app.before_request
def _proteger_csrf():
    """
    Protección CSRF: toda petición que modifica datos debe traer el token de la sesión (campo oculto
    `csrf_token`). Así otra página no puede enviar formularios en nombre del usuario conectado.
    """
    if (request.method in ("POST", "PUT", "PATCH", "DELETE") and app.config["CSRF_ACTIVO"]
            and request.endpoint not in _RUTAS_SIN_CSRF):
        esperado = session.get("csrf_token", "")
        enviado = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
        if not esperado or not secrets.compare_digest(esperado.encode(), enviado.encode()):
            abort(400, description="Token CSRF inválido o ausente. Recarga la página e inténtalo de nuevo.")


@app.context_processor
def _csrf_en_plantillas():
    def csrf_input():
        token = session.setdefault("csrf_token", secrets.token_hex(16))
        return Markup(f'<input type="hidden" name="csrf_token" value="{token}">')
    return {"csrf_input": csrf_input}

# ---------------------------------------------------------------------
# Aquí se crea la ÚNICA fachada real de la app. Por dentro, ella obtiene la
# única instancia del Singleton (DatabaseManager) y el sistema externo
# del Adapter (detrás de un proxy de caché), y guarda el historial de
# notificaciones del Bridge.
# ---------------------------------------------------------------------
fachada_real = FachadaSHCE()


def fachada_actual():
    """
    La fachada tal como la ve ESTA petición: el mismo objeto de siempre pero
    envuelto en un ProxyProteccionFachada con el usuario y el rol de la
    sesión. Las rutas la usan igual que a la fachada real (misma interfaz);
    la diferencia es que cada operación pasa antes por la tabla de permisos.
    Se crea una vez por petición y se guarda en `g`.
    """
    if "fachada" not in g:
        g.fachada = ProxyProteccionFachada(
            fachada_real,
            usuario=session.get("usuario"),
            rol=session.get("rol"),
            registrar_denegacion=fachada_real.registrar_denegacion,
        )
    return g.fachada


@app.errorhandler(AccesoDenegado)
def _acceso_denegado(error):
    """
    Cualquier ruta cuya operación niegue el proxy termina aquí: se avisa con
    el mensaje del proxy y se devuelve al usuario al panel. Las rutas no
    necesitan un `except` propio para los permisos.
    """
    if request.endpoint == "dashboard":
        # Ni el panel está permitido (rol no reconocido): redirigir al panel sería un bucle.
        return str(error), 403
    flash(str(error))
    return redirect(url_for("dashboard"))


@app.context_processor
def _inyectar_opciones_exportacion():
    """Hace disponibles en TODAS las plantillas las casillas de opciones de exportación (Decorator)."""
    return {"opciones_exportacion": fachada_actual().opciones_exportacion}


@app.context_processor
def _inyectar_avisos():
    """Hace disponible en TODAS las plantillas cuántos avisos sin leer tiene el usuario (Observer): lo usa la barra superior."""
    usuario = session.get("usuario")
    if not usuario:
        return {"avisos_sin_leer": 0}
    return {"avisos_sin_leer": fachada_actual().avisos_sin_leer(usuario)}


def requiere_login(vista):
    """
    Decorador para no repetir en cada ruta protegida el mismo
    `if not session.get("usuario"): return redirect(...)`.
    Se usa poniendo @requiere_login justo encima de la función de la ruta.
    """
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login"))
        return vista(*args, **kwargs)
    return envoltura


def _descargar(archivo):
    """Envía un ArchivoExportado de la fachada como descarga, directo desde memoria."""
    return send_file(
        io.BytesIO(archivo.contenido),
        mimetype=archivo.mimetype,
        as_attachment=True,
        download_name=archivo.nombre,
    )


@app.route("/")
def index():
    """
    Ruta raíz: si ya hay una sesión activa, manda directo al panel;
    si no, manda al login.
    """
    if session.get("usuario"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    """
    GET  -> muestra el formulario de login.
    POST -> procesa lo que el usuario escribió en el formulario.
    """
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")

        if fachada_real.cuenta_bloqueada(usuario):
            flash("Demasiados intentos fallidos. Por seguridad, la cuenta está bloqueada unos minutos.")
            return render_template("login.html", usuario_previo=usuario), 429

        # La fachada valida las credenciales (y deja el intento en la bitácora).
        registro = fachada_actual().iniciar_sesion(usuario, password)

        if registro:
            # Guardamos datos básicos en la sesión del navegador (cookie
            # firmada) para saber, en las siguientes peticiones, quién es
            # el usuario sin pedirle la contraseña de nuevo.
            session.clear()                                   # sesión nueva (evita fijación de sesión)
            session.permanent = True                          # caduca a los 30 min sin actividad
            session["usuario"] = registro["usuario"]
            session["nombre_completo"] = registro["nombre_completo"]
            session["rol"] = registro["rol"]
            return redirect(url_for("dashboard"))

        # Si las credenciales fallaron, mostramos un mensaje de error
        # (flash) y volvemos a renderizar el formulario, conservando lo
        # que el usuario ya había escrito en el campo "usuario".
        flash("Usuario o contraseña incorrectos.")
        return render_template("login.html", usuario_previo=usuario), 401

    # Método GET: primera vez que se entra a la página.
    return render_template("login.html", usuario_previo="")


@app.route("/registro", methods=["GET", "POST"])
def registro():
    """
    GET  -> muestra el formulario para crear una cuenta nueva.
    POST -> la fachada valida los datos y crea el usuario.
    """
    if request.method == "POST":
        nombre_completo = request.form.get("nombre_completo", "").strip()
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        confirmar_password = request.form.get("confirmar_password", "")
        rol = request.form.get("rol", "medico")

        resultado = fachada_actual().registrar_usuario(
            nombre_completo, usuario, password, confirmar_password, rol
        )

        if not resultado.exitoso:
            # Mostramos todos los errores encontrados y volvemos a
            # renderizar el formulario sin perder lo ya escrito.
            for error in resultado.errores:
                flash(error)
            return render_template(
                "registro.html",
                nombre_completo=nombre_completo,
                usuario=usuario,
                rol=rol,
            ), 400

        flash("Cuenta creada correctamente. Ya puedes iniciar sesión.")
        return redirect(url_for("login"))

    # Método GET: mostramos el formulario vacío.
    return render_template("registro.html", nombre_completo="", usuario="", rol="medico")


@app.route("/dashboard")
@requiere_login
def dashboard():
    """Panel principal, solo visible si hay una sesión iniciada."""
    return render_template(
        "dashboard.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        # bitacora, total_pacientes, exportaciones e instancia_id
        # (el id del Singleton) llegan ya armados desde la fachada.
        **fachada_actual().resumen_panel(),
    )


@app.route("/pacientes")
@requiere_login
def pacientes():
    """
    Lista todas las historias clínicas registradas, con botones para exportarlas.
    `?orden=...` elige el criterio de orden (patrón Strategy); uno desconocido usa el de por defecto.
    """
    orden = fachada_actual().normalizar_orden(request.args.get("orden", ""))
    return render_template(
        "pacientes.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        # Cada paciente ya trae su edad, etiqueta y color de tipo de atención.
        pacientes=fachada_actual().listar_pacientes_enriquecidos(orden),
        # Strategy: criterios disponibles y el que está activo.
        ordenes=fachada_actual().ordenes_disponibles,
        orden=orden,
        # Observer: ids de las historias que este usuario sigue (para pintar «Seguir» o «Siguiendo»).
        siguiendo=fachada_actual().pacientes_seguidos(session.get("usuario")),
    )


@app.route("/pacientes/<int:paciente_id>/duplicar")
@requiere_login
def paciente_duplicar(paciente_id):
    """
    Precarga el formulario de "nueva historia clínica" con los datos
    clínicos de un paciente existente (diagnóstico, tratamiento, tipo de
    atención...), como plantilla para una consulta de seguimiento. La
    fachada se encarga de clonar la historia sin documento ni notas.
    """
    try:
        plantilla, nombre_origen = fachada_actual().plantilla_desde_paciente(paciente_id)
    except PacienteNoEncontrado as error:
        flash(str(error))
        return redirect(url_for("pacientes"))

    flash(
        f"Formulario precargado a partir de la historia de "
        f"{nombre_origen}. Revisa los datos y "
        f"asigna un documento nuevo antes de guardar."
    )
    return render_template("paciente_nuevo.html", tipos_atencion=fachada_actual().tipos_atencion, **plantilla)


@app.route("/pacientes/nuevo", methods=["GET", "POST"])
@requiere_login
def paciente_nuevo():
    """
    GET  -> muestra el formulario para crear una nueva historia clínica.
    POST -> la fachada arma, valida y guarda el paciente (y notifica si
            es de Urgencias o Control).
    """
    if request.method == "POST":
        resultado = fachada_actual().registrar_paciente(request.form, registrado_por=session.get("usuario"))

        if not resultado.exitoso:
            for error in resultado.errores:
                flash(error)
            # resultado.datos trae lo que escribió el usuario, para no perderlo.
            return render_template(
                "paciente_nuevo.html", tipos_atencion=fachada_actual().tipos_atencion, **resultado.datos
            ), 400

        flash("Historia clínica creada correctamente.")
        return redirect(url_for("pacientes"))

    # Método GET: formulario vacío.
    campos_vacios = {
        "nombre_completo": "", "documento": "", "fecha_nacimiento": "",
        "motivo_consulta": "", "diagnostico": "", "tratamiento": "", "notas": "",
        "tipo_atencion": "consulta_general", "prioridad": "", "fecha_proximo_control": "",
    }
    return render_template("paciente_nuevo.html", tipos_atencion=fachada_actual().tipos_atencion, **campos_vacios)


@app.route("/pacientes/<int:paciente_id>/editar", methods=["GET", "POST"])
@requiere_login
def paciente_editar(paciente_id):
    """
    GET  -> muestra el formulario con los datos clínicos actuales de la historia.
    POST -> la fachada valida y guarda los cambios, tomando antes una instantánea del
            estado anterior (patrón Memento) para poder deshacerlos. Nombre, documento y
            fecha de nacimiento no se editan.
    """
    fachada = fachada_actual()
    try:
        if request.method == "POST":
            resultado = fachada.editar_paciente(paciente_id, request.form, editado_por=session.get("usuario"))
            if not resultado.exitoso:
                for error in resultado.errores:
                    flash(error)
                return render_template(
                    "paciente_editar.html", tipos_atencion=fachada.tipos_atencion,
                    nombre_completo=session.get("nombre_completo"), rol=session.get("rol"), **resultado.datos
                ), 400
            flash("Historia clínica actualizada. Si te equivocaste, puedes deshacer el cambio desde «Versiones».")
            return redirect(url_for("paciente_versiones", paciente_id=paciente_id))
        datos = fachada.datos_edicion(paciente_id)
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))

    return render_template(
        "paciente_editar.html", tipos_atencion=fachada.tipos_atencion,
        nombre_completo=session.get("nombre_completo"), rol=session.get("rol"), **datos
    )


@app.route("/pacientes/<int:paciente_id>/versiones")
@requiere_login
def paciente_versiones(paciente_id):
    """Historial de versiones de una historia, con deshacer, rehacer y restaurar (patrón Memento)."""
    try:
        datos = fachada_actual().versiones_paciente(paciente_id)
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))
    return render_template(
        "paciente_versiones.html",
        nombre_completo=session.get("nombre_completo"), rol=session.get("rol"), **datos
    )


def _accion_de_versiones(paciente_id, operacion, mensaje, *argumentos):
    """Ejecuta una operación del historial de versiones y vuelve a la página de versiones."""
    try:
        getattr(fachada_actual(), operacion)(paciente_id, *argumentos, session.get("usuario"))
        flash(mensaje)
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("paciente_versiones", paciente_id=paciente_id))


@app.route("/pacientes/<int:paciente_id>/versiones/deshacer", methods=["POST"])
@requiere_login
def paciente_deshacer(paciente_id):
    """Deshace la última edición de la historia."""
    return _accion_de_versiones(paciente_id, "deshacer_edicion", "Se deshizo la última edición.")


@app.route("/pacientes/<int:paciente_id>/versiones/rehacer", methods=["POST"])
@requiere_login
def paciente_rehacer(paciente_id):
    """Vuelve a aplicar la edición que se acaba de deshacer."""
    return _accion_de_versiones(paciente_id, "rehacer_edicion", "Se rehizo la edición.")


@app.route("/pacientes/<int:paciente_id>/versiones/restaurar/<int:version>", methods=["POST"])
@requiere_login
def paciente_restaurar(paciente_id, version):
    """Lleva la historia al estado de una versión anterior (la restauración también se puede deshacer)."""
    return _accion_de_versiones(paciente_id, "restaurar_version", f"Historia restaurada a la versión {version}.", version)


@app.route("/pacientes/<int:paciente_id>/estado/<accion>", methods=["POST"])
@requiere_login
def paciente_estado(paciente_id, accion):
    """
    Ejecuta una acción del ciclo de vida de la historia (patrón State): iniciar atención, dar de alta,
    cerrar o reabrir. Qué acciones existen y a qué estado llevan lo decide el estado actual de la historia.
    """
    try:
        nuevo = fachada_actual().cambiar_estado(paciente_id, accion, session.get("usuario"))
        flash(f"Estado de la historia actualizado: {nuevo}.")
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("pacientes"))


@app.route("/pacientes/<int:paciente_id>/seguir", methods=["POST"])
@requiere_login
def paciente_seguir(paciente_id):
    """Suscribe al usuario a los cambios de la historia (patrón Observer)."""
    try:
        fachada_actual().seguir_paciente(paciente_id, session.get("usuario"))
        flash("Ahora sigues esta historia: recibirás un aviso cuando alguien más la modifique.")
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("pacientes"))


@app.route("/pacientes/<int:paciente_id>/dejar-de-seguir", methods=["POST"])
@requiere_login
def paciente_dejar_de_seguir(paciente_id):
    """Cancela la suscripción a los cambios de la historia."""
    try:
        fachada_actual().dejar_de_seguir(paciente_id, session.get("usuario"))
        flash("Dejaste de seguir esta historia. Los avisos que ya recibiste se conservan.")
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("pacientes"))


@app.route("/avisos")
@requiere_login
def avisos():
    """La bandeja de avisos del usuario: los cambios en las historias que sigue (patrón Observer)."""
    fachada = fachada_actual()
    usuario = session.get("usuario")
    return render_template(
        "avisos.html",
        nombre_completo=session.get("nombre_completo"), rol=session.get("rol"),
        avisos=fachada.avisos_de(usuario), sin_leer=fachada.avisos_sin_leer(usuario),
    )


@app.route("/avisos/leer", methods=["POST"])
@requiere_login
def avisos_leer():
    """Marca todos los avisos del usuario como leídos."""
    cantidad = fachada_actual().marcar_avisos_leidos(session.get("usuario"))
    flash(f"{cantidad} aviso(s) marcado(s) como leído(s).")
    return redirect(url_for("avisos"))


@app.route("/pacientes/<int:paciente_id>/exportar/<formato>")
@requiere_login
def exportar_paciente(paciente_id, formato):
    """
    Genera y descarga la historia clínica de un paciente en el formato
    pedido (pdf, txt o csv). Las casillas de la URL (?opciones=anonimizar
    &opciones=sello) se las pasamos tal cual a la fachada; la auditoría
    se aplica siempre, con el usuario de la sesión.
    """
    try:
        archivo = fachada_actual().exportar_paciente(
            paciente_id,
            formato,
            opciones=request.args.getlist("opciones"),
            usuario=session.get("usuario"),
        )
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))

    return _descargar(archivo)


@app.route("/pacientes/importar")
@requiere_login
def importar_externo_listar():
    """
    Muestra las historias disponibles en el Sistema Externo de Historias
    (SEH), en SU formato crudo, para que el médico elija cuál importar.
    """
    return render_template(
        "importar_externo.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        registros=fachada_actual().listar_registros_externos(),
    )


@app.route("/pacientes/importar/<codigo_externo>", methods=["GET", "POST"])
@requiere_login
def importar_externo_detalle(codigo_externo):
    """
    GET  -> muestra, lado a lado, el dato CRUDO del sistema externo y el
            dato ya ADAPTADO al formato de SHCE.
    POST -> confirma la importación. La fachada aplica la misma
            validación, guardado y notificación que el formulario manual.
    """
    if request.method == "POST":
        try:
            resultado = fachada_actual().importar_desde_externo(
                codigo_externo, registrado_por=session.get("usuario")
            )
        except RegistroExternoNoEncontrado as error:
            flash(str(error))
            return redirect(url_for("importar_externo_listar"))

        if not resultado.exitoso:
            for error in resultado.errores:
                flash(error)
            return redirect(url_for("importar_externo_detalle", codigo_externo=codigo_externo))

        flash(f"Historia clínica importada correctamente desde el sistema externo ({codigo_externo}).")
        return redirect(url_for("pacientes"))

    try:
        crudo, adaptado = fachada_actual().previsualizar_importacion(codigo_externo)
    except RegistroExternoNoEncontrado as error:
        flash(str(error))
        return redirect(url_for("importar_externo_listar"))

    return render_template(
        "importar_externo_detalle.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        codigo_externo=codigo_externo,
        crudo=crudo,
        adaptado=adaptado,
    )


@app.route("/logout")
def logout():
    """Cierra la sesión actual y vuelve al login."""
    session.clear()
    return redirect(url_for("login"))


@app.route("/notificaciones", methods=["GET", "POST"])
@requiere_login
def notificaciones():
    """
    Permite elegir cualquier paciente, cualquier TIPO de notificación y
    cualquier CANAL de envío, y combinarlos en tiempo real. También
    muestra el historial de notificaciones ya enviadas (incluidas las
    que se dispararon automáticamente al crear pacientes de Urgencias/Control).
    """
    resultado_envio = None

    if request.method == "POST":
        try:
            resultado_envio = fachada_actual().notificar_paciente(
                request.form.get("paciente_id", ""),
                request.form.get("tipo_notificacion", "informativa"),
                request.form.get("canal_envio", "consola"),
            )
            flash(f"Notificación enviada por {resultado_envio['canal']}.")
        except PacienteNoEncontrado as error:
            flash(str(error))

    return render_template(
        "notificaciones.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        pacientes=fachada_actual().listar_pacientes(),
        tipos_notificacion=fachada_actual().tipos_notificacion,
        canales_envio=fachada_actual().canales_envio,
        resultado_envio=resultado_envio,
        historial=fachada_actual().historial_notificaciones(limite=10),
    )


@app.route("/estructura")
@requiere_login
def estructura():
    """
    Muestra las historias clínicas como un árbol de carpetas y ofrece,
    por cada carpeta, exportar todas sus historias o notificar a todas
    con una sola acción.
    """
    vista = fachada_actual().consultar_estructura(request.args.get("agrupar", ""))

    return render_template(
        "estructura.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        arbol=vista["arbol"],
        agrupacion=vista["agrupacion"],
        agrupaciones=fachada_actual().agrupaciones,
        grupos=vista["grupos"],
        tipos_notificacion=fachada_actual().tipos_notificacion,
        canales_envio=fachada_actual().canales_envio,
        # Command: acciones de estado disponibles y el historial de acciones de este usuario.
        acciones_estado=fachada_actual().acciones_estado,
        comandos=fachada_actual().comandos_recientes(session.get("usuario")),
    )


@app.route("/estructura/exportar/<formato>")
@requiere_login
def estructura_exportar(formato):
    """
    Descarga un .zip con la historia clínica de CADA paciente del nodo
    elegido (una carpeta, o una historia suelta) en el formato pedido.
    """
    agrupacion = fachada_actual().normalizar_agrupacion(request.args.get("agrupar", ""))

    try:
        archivo = fachada_actual().exportar_nodo(
            formato,
            request.args.get("nodo"),     # None -> se exporta todo el árbol
            agrupacion,
            opciones=request.args.getlist("opciones"),
            usuario=session.get("usuario"),
        )
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("estructura", agrupar=agrupacion))

    return _descargar(archivo)


@app.route("/estructura/notificar", methods=["POST"])
@requiere_login
def estructura_notificar():
    """
    Envía una notificación (tipo x canal) a TODAS las historias del nodo
    elegido con una sola llamada. Los envíos quedan en el mismo historial
    que muestra /notificaciones.
    """
    agrupacion = fachada_actual().normalizar_agrupacion(request.form.get("agrupar", ""))

    try:
        nombre_nodo, cantidad = fachada_actual().notificar_nodo(
            request.form.get("nodo", ""),
            agrupacion,
            request.form.get("tipo_notificacion", "informativa"),
            request.form.get("canal_envio", "consola"),
        )
        flash(
            f"Se enviaron {cantidad} notificación(es) a '{nombre_nodo}'. "
            f"Puedes verlas en el historial de Notificaciones."
        )
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("estructura", agrupar=agrupacion))


@app.route("/pacientes/<int:paciente_id>")
@requiere_login
def paciente_detalle(paciente_id):
    """Página de UN paciente: historia, signos vitales, citas y alertas de interacciones medicamentosas."""
    try:
        detalle = fachada_actual().detalle_paciente(paciente_id)
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))
    return render_template("paciente_detalle.html", nombre_completo=session.get("nombre_completo"),
                           rol=session.get("rol"), hoy=date.today().isoformat(), **detalle)


@app.route("/pacientes/<int:paciente_id>/signos", methods=["POST"])
@requiere_login
def paciente_signos(paciente_id):
    """Registra signos vitales digitados por el personal (los de un dispositivo entran por /api/signos)."""
    try:
        resultado = fachada_actual().registrar_signos(paciente_id, request.form, session.get("usuario"))
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))
    if resultado.errores:
        for error in resultado.errores:
            flash(error)
    else:
        flash("Signos vitales registrados en la historia clínica.")
        for _nivel, texto in resultado.datos["alertas"]:
            flash("⚠ " + texto)
    return redirect(url_for("paciente_detalle", paciente_id=paciente_id))


@app.route("/pacientes/<int:paciente_id>/eliminar", methods=["POST"])
@requiere_login
def paciente_eliminar(paciente_id):
    """Elimina una historia clínica (solo administradores; el Proxy lo hace cumplir). Pide confirmación."""
    if request.form.get("confirmar") != "si":
        flash("Debes confirmar la eliminación.")
        return redirect(url_for("paciente_detalle", paciente_id=paciente_id))
    try:
        nombre = fachada_actual().eliminar_paciente(paciente_id, session.get("usuario"))
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("pacientes"))
    flash(f"Historia clínica de '{nombre}' eliminada (con sus citas y signos vitales).")
    return redirect(url_for("pacientes"))


@app.route("/citas")
@requiere_login
def citas():
    """Agenda de citas: las programadas, las ya atendidas o canceladas, y el formulario para programar una."""
    todas = fachada_actual().listar_citas()
    return render_template(
        "citas.html", nombre_completo=session.get("nombre_completo"), rol=session.get("rol"),
        programadas=[c for c in todas if c["estado"] == "programada"],
        historial=[c for c in todas if c["estado"] != "programada"][::-1],
        pacientes=fachada_actual().listar_pacientes(), medicos=fachada_actual().medicos_disponibles(),
        hoy=date.today().isoformat(),
    )


@app.route("/citas/nueva", methods=["POST"])
@requiere_login
def cita_nueva():
    """Programa una cita. `volver=detalle` regresa a la página del paciente; si no, a la agenda."""
    try:
        paciente_id = int(request.form.get("paciente_id", ""))
        resultado = fachada_actual().programar_cita(paciente_id, request.form, session.get("usuario"))
    except ValueError:
        flash("Selecciona un paciente.")
        return redirect(url_for("citas"))
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("citas"))
    if resultado.errores:
        for error in resultado.errores:
            flash(error)
    else:
        flash(f"Cita programada para {resultado.datos['nombre_paciente']}.")
    if request.form.get("volver") == "detalle":
        return redirect(url_for("paciente_detalle", paciente_id=paciente_id))
    return redirect(url_for("citas"))


@app.route("/citas/<int:cita_id>/estado", methods=["POST"])
@requiere_login
def cita_estado(cita_id):
    """Marca una cita como cumplida o cancelada."""
    try:
        estado = fachada_actual().cambiar_estado_cita(cita_id, request.form.get("estado", ""), session.get("usuario"))
        flash(f"Cita marcada como {estado}.")
    except ErrorFachada as error:
        flash(str(error))
    if request.form.get("volver_paciente"):
        return redirect(url_for("paciente_detalle", paciente_id=int(request.form["volver_paciente"])))
    return redirect(url_for("citas"))


@app.route("/api/signos", methods=["POST"])
def api_signos():
    """
    Entrada de los dispositivos IoT (monitores de signos vitales). Autenticada con la cabecera
    `X-API-Key` (no con sesión de usuario). Cuerpo JSON: {"documento", "dispositivo", y los signos}.
    Ver `simulador_iot.py`.
    """
    enviada = request.headers.get("X-API-Key", "")
    if not secrets.compare_digest(enviada.encode(), API_KEY_DISPOSITIVOS.encode()):
        return jsonify(error="Clave de API inválida."), 401
    datos = request.get_json(silent=True)
    if not isinstance(datos, dict):
        return jsonify(error="El cuerpo debe ser un objeto JSON."), 400
    dispositivo = str(datos.get("dispositivo") or "")[:60] or None
    try:
        resultado = fachada_real.registrar_signos_dispositivo(str(datos.get("documento") or ""), datos, dispositivo)
    except ErrorFachada as error:
        return jsonify(error=str(error)), 404
    if resultado.errores:
        return jsonify(errores=resultado.errores), 422
    return jsonify(ok=True, lectura_id=resultado.datos["lectura_id"],
                   alertas=[{"nivel": n, "texto": t} for n, t in resultado.datos["alertas"]]), 201


@app.route("/reportes")
@requiere_login
def reportes():
    """
    Reportes sobre las historias clínicas (patrón Visitor): estadísticas,
    historias incompletas y agenda de controles. Se pueden pedir sobre todo
    el árbol o sobre una sola carpeta (`?nodo=...`), y la agrupación del árbol
    (`?agrupar=...`) decide qué carpetas existen y en cuál queda cada historia.
    """
    agrupacion = fachada_actual().normalizar_agrupacion(request.args.get("agrupar", ""))

    try:
        reporte = fachada_actual().generar_reporte(agrupacion, request.args.get("nodo") or None)
    except ErrorFachada as error:
        flash(str(error))
        return redirect(url_for("reportes", agrupar=agrupacion))

    return render_template(
        "reportes.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        agrupaciones=fachada_actual().agrupaciones,
        **reporte,
    )


def _comando_de_estructura(operacion, mensaje, argumentos):
    """
    Ejecuta una operación de comando (Command) desde la página de estructura, muestra el
    resultado y vuelve a ella en la misma agrupación. `mensaje` se completa con lo que
    devuelva la fachada.
    """
    agrupacion = fachada_actual().normalizar_agrupacion(request.form.get("agrupar", ""))
    try:
        resultado = getattr(fachada_actual(), operacion)(*argumentos(agrupacion), session.get("usuario"))
        flash(mensaje(resultado))
    except ErrorFachada as error:
        flash(str(error))
    return redirect(url_for("estructura", agrupar=agrupacion))


@app.route("/estructura/estado", methods=["POST"])
@requiere_login
def estructura_estado():
    """Aplica una acción de ciclo de vida a TODAS las historias de una carpeta (comando macro)."""
    return _comando_de_estructura(
        "cambiar_estado_nodo",
        lambda r: f"Acción aplicada en '{r[0]}': {r[1]} historia(s) cambiada(s)"
                  + (f", {r[2]} omitida(s) por su estado actual." if r[2] else ".")
                  + " Puedes deshacerla desde el historial de acciones.",
        lambda agrupacion: (request.form.get("nodo", ""), agrupacion, request.form.get("accion", "")),
    )


@app.route("/comandos/deshacer", methods=["POST"])
@requiere_login
def comando_deshacer():
    return _comando_de_estructura("deshacer_comando", lambda d: f"Deshecho: {d}.", lambda a: ())


@app.route("/comandos/rehacer", methods=["POST"])
@requiere_login
def comando_rehacer():
    return _comando_de_estructura("rehacer_comando", lambda d: f"Rehecho: {d}.", lambda a: ())


# Este bloque solo se ejecuta cuando corres "python3 app.py" directamente
# (no cuando otro archivo importa cosas de app.py).
if __name__ == "__main__":
    print("SHCE corriendo localmente en http://127.0.0.1:5000")
    print("Usuarios de prueba -> admin / Admin123   |   brayan / Medico123")
    # Seguridad: el modo debug (que expone un depurador) solo se activa si lo pides: SHCE_DEBUG=1.
    app.run(debug=os.environ.get("SHCE_DEBUG") == "1", port=5000)

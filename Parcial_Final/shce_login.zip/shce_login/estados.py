"""
estados.py
----------
Implementación del patrón de diseño STATE (comportamiento): un objeto cambia
su COMPORTAMIENTO cuando cambia su estado interno, y lo hace delegando en un
objeto-estado distinto por cada estado, en lugar de llenar el código de `if`.

¿Por qué State aquí?
--------------------
Una historia clínica tiene un ciclo de vida, y lo que se puede hacer con ella
depende de en qué punto está:

  - Recién registrada, o en plena atención, se puede editar libremente.
  - Una vez dada de alta (Atendida) ya no se debe modificar a la ligera.
  - Cerrada, queda archivada: solo se puede reabrir.

Sin State, cada operación tendría que preguntar "si el estado es A... si es
B... si es C..." y esos `if` se repetirían (en la edición, en los botones de la
pantalla, en las transiciones). Con State, cada estado es una CLASE que sabe qué
permite, qué acciones ofrece y a qué estado pasa.

El ciclo de vida:

    Registrada ──iniciar_atencion──▶ En atención ──dar_alta──▶ Atendida ──cerrar──▶ Cerrada
                                         ▲                        │                    │
                                         └──────── reabrir ───────┴────── reabrir ─────┘

  Estado        ¿Se puede editar?   Acciones que ofrece
  ------------  ------------------  ---------------------------------------
  Registrada    Sí                  iniciar_atencion
  En atención   Sí                  dar_alta
  Atendida      No                  cerrar, reabrir
  Cerrada       No                  reabrir

Estructura del patrón en este archivo:
  Context (contexto)       -> CicloVidaHistoria: guarda el estado actual y delega en él
  State (interfaz)         -> EstadoHistoria: puede_editar, acciones y las transiciones
  ConcreteState            -> Registrada, EnAtencion, Atendida, Cerrada
  Cliente                  -> la fachada (fachada.py): lee el estado de la BD, ejecuta la
                              acción y vuelve a guardar el estado resultante

Decisiones de diseño:
  - LAS TRANSICIONES LAS DECIDE EL ESTADO: es el estado actual quien le dice al contexto
    a cuál pasar (`ciclo._cambiar_a(...)`). El contexto no tiene una tabla de reglas.
  - ACCIÓN NO PERMITIDA = ERROR CLARO: pedir una acción que el estado no ofrece lanza
    TransicionInvalida con un mensaje legible; nunca se llega a un estado imposible.
  - LISTA BLANCA DE ACCIONES: el contexto solo ejecuta nombres que estén en `acciones` del
    estado actual. Un texto arbitrario que llegue desde la URL no puede invocar otro método.
  - ESTADOS SIN ESTADO PROPIO: las clases-estado no guardan datos (solo comportamiento),
    así que se comparten: hay UNA instancia de cada una (`ESTADOS`).
  - EL ESTADO SE GUARDA EN LA BASE DE DATOS (columna `estado_atencion`): a diferencia del
    historial de versiones o los avisos, el estado es un dato clínico y debe sobrevivir a
    reinicios. El contexto se reconstruye en cada petición a partir de esa columna.
  - Las historias que ya existían quedan en "Registrada" (editables): nada cambia para ellas.
  - EL ESTADO NO CONOCE ROLES: quién puede cambiar el estado lo decide el proxy de protección
    (proxies.py); este módulo solo define qué transiciones existen.
"""

from abc import ABC, abstractmethod


class TransicionInvalida(Exception):
    """Se pidió una acción que el estado actual no permite."""


# =====================================================================
# INTERFAZ DEL ESTADO
# =====================================================================
class EstadoHistoria(ABC):
    """
    Lo que sabe todo estado: cómo se llama, si permite editar, qué acciones ofrece y
    qué hace cada una. Una acción que no ofrece lanza TransicionInvalida.
    """

    clave = ""          # lo que se guarda en la base de datos
    etiqueta = ""       # el nombre legible
    clase_css = ""      # sufijo de la clase de color de la insignia
    acciones = {}       # acción -> texto del botón (solo las que este estado permite)

    @abstractmethod
    def puede_editar(self) -> bool:
        raise NotImplementedError

    def motivo_bloqueo(self) -> str:
        """Por qué no se puede editar (vacío si sí se puede)."""
        if self.puede_editar():
            return ""
        return f"La historia está «{self.etiqueta}» y no admite ediciones. Reábrela para poder modificarla."

    # ---- las transiciones: por defecto NO válidas; cada estado concreto sobrescribe las suyas ----
    def iniciar_atencion(self, ciclo: "CicloVidaHistoria") -> None:
        raise self._invalida("iniciar_atencion")

    def dar_alta(self, ciclo: "CicloVidaHistoria") -> None:
        raise self._invalida("dar_alta")

    def cerrar(self, ciclo: "CicloVidaHistoria") -> None:
        raise self._invalida("cerrar")

    def reabrir(self, ciclo: "CicloVidaHistoria") -> None:
        raise self._invalida("reabrir")

    def _invalida(self, accion: str) -> TransicionInvalida:
        return TransicionInvalida(f"No se puede «{accion}» cuando la historia está «{self.etiqueta}».")


# =====================================================================
# LOS CUATRO ESTADOS CONCRETOS
# =====================================================================
class Registrada(EstadoHistoria):
    clave, etiqueta, clase_css = "registrada", "Registrada", "registrada"
    acciones = {"iniciar_atencion": "▶ Iniciar atención"}

    def puede_editar(self) -> bool:
        return True

    def iniciar_atencion(self, ciclo):
        ciclo._cambiar_a(ESTADOS["en_atencion"])


class EnAtencion(EstadoHistoria):
    clave, etiqueta, clase_css = "en_atencion", "En atención", "en-atencion"
    acciones = {"dar_alta": "✔ Dar de alta"}

    def puede_editar(self) -> bool:
        return True

    def dar_alta(self, ciclo):
        ciclo._cambiar_a(ESTADOS["atendida"])


class Atendida(EstadoHistoria):
    clave, etiqueta, clase_css = "atendida", "Atendida", "atendida"
    acciones = {"cerrar": "🔒 Cerrar historia", "reabrir": "↺ Reabrir atención"}

    def puede_editar(self) -> bool:
        return False

    def cerrar(self, ciclo):
        ciclo._cambiar_a(ESTADOS["cerrada"])

    def reabrir(self, ciclo):
        ciclo._cambiar_a(ESTADOS["en_atencion"])


class Cerrada(EstadoHistoria):
    clave, etiqueta, clase_css = "cerrada", "Cerrada", "cerrada"
    acciones = {"reabrir": "↺ Reabrir atención"}

    def puede_editar(self) -> bool:
        return False

    def motivo_bloqueo(self) -> str:
        return "La historia está cerrada (archivada). Reábrela para poder modificarla."

    def reabrir(self, ciclo):
        ciclo._cambiar_a(ESTADOS["en_atencion"])


# Los estados no guardan datos, así que se comparten: una sola instancia de cada uno.
ESTADOS = {e.clave: e for e in (Registrada(), EnAtencion(), Atendida(), Cerrada())}
ESTADO_INICIAL = "registrada"


def estado_desde_clave(clave) -> EstadoHistoria:
    """El estado que corresponde a lo guardado en la base de datos (vacío = registrada)."""
    clave = clave or ESTADO_INICIAL
    if clave not in ESTADOS:
        raise ValueError(f"Estado desconocido: {clave!r}. Los válidos son {sorted(ESTADOS)}.")
    return ESTADOS[clave]


# =====================================================================
# EL CONTEXTO
# =====================================================================
class CicloVidaHistoria:
    """
    Guarda el estado actual de UNA historia y le delega todo lo que depende de él.
    No contiene ningún `if estado == ...`: pregunta al estado.
    """

    def __init__(self, clave_estado=None):
        self._estado = estado_desde_clave(clave_estado)

    @property
    def estado(self) -> EstadoHistoria:
        return self._estado

    def puede_editar(self) -> bool:
        return self._estado.puede_editar()

    def acciones_disponibles(self) -> list:
        """Lista de (acción, texto del botón) que el estado actual permite."""
        return list(self._estado.acciones.items())

    def ejecutar(self, accion: str) -> EstadoHistoria:
        """Ejecuta una acción (solo si el estado la ofrece) y devuelve el estado resultante."""
        if accion not in self._estado.acciones:
            raise TransicionInvalida(
                f"La acción «{accion}» no está disponible cuando la historia está «{self._estado.etiqueta}»."
            )
        getattr(self._estado, accion)(self)
        return self._estado

    def _cambiar_a(self, estado: EstadoHistoria) -> None:
        """Lo llaman los estados para indicar a cuál pasa el contexto."""
        self._estado = estado


if __name__ == "__main__":
    ciclo = CicloVidaHistoria()
    mostrar = lambda: print(f"   estado: {ciclo.estado.etiqueta:<12} editable: {str(ciclo.puede_editar()):<5} "
                            f"acciones: {[a for a, _ in ciclo.acciones_disponibles()]}")
    print("1) Recorrido completo del ciclo de vida"); mostrar()
    for accion in ("iniciar_atencion", "dar_alta", "cerrar"):
        ciclo.ejecutar(accion); print(f"   → {accion}"); mostrar()
    print("2) Una acción que el estado no ofrece se rechaza:")
    for accion in ("dar_alta", "borrar_todo"):
        try:
            ciclo.ejecutar(accion)
        except TransicionInvalida as error:
            print("  ", error)
    print("3) Reabrir devuelve a «En atención» (editable otra vez)")
    ciclo.ejecutar("reabrir"); mostrar()
    print("4) Motivo de bloqueo según el estado:", repr(ESTADOS["atendida"].motivo_bloqueo()))
    print("5) Reconstruir desde lo guardado en la BD:", CicloVidaHistoria("atendida").estado.etiqueta,
          "| vacío ->", CicloVidaHistoria(None).estado.etiqueta)

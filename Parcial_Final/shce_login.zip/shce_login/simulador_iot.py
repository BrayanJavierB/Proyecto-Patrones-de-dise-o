"""
simulador_iot.py
----------------
Simula un DISPOSITIVO IoT (un monitor de signos vitales) que envía lecturas al sistema
por HTTP, igual que lo haría un equipo real (Objetivo 2). Cada lectura llega al endpoint
`POST /api/signos`, se valida y se guarda automáticamente en la historia clínica del
paciente, sin que nadie la digite.

Uso (con el servidor corriendo):
    python3 simulador_iot.py --documento 1098765432 --cantidad 5 --intervalo 2
    python3 simulador_iot.py --documento 1098765432 --anormal      # valores de alerta

La clave de la API se toma de --clave, de la variable SHCE_API_KEY o del archivo
`api_key.key` que el servidor crea al arrancar por primera vez.
"""

import argparse
import json
import os
import random
import time
import urllib.error
import urllib.request


def leer_clave(clave_cli):
    if clave_cli:
        return clave_cli
    if os.environ.get("SHCE_API_KEY"):
        return os.environ["SHCE_API_KEY"].strip()
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "api_key.key")
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            return f.read().strip()
    raise SystemExit("No hay clave de API: usa --clave, SHCE_API_KEY o arranca el servidor para crear api_key.key.")


def generar_lectura(anormal=False):
    """Una lectura plausible; con `anormal` se fuerzan valores que disparan alertas."""
    if anormal:
        return {"frecuencia_cardiaca": random.randint(125, 150), "presion_sistolica": random.randint(160, 190),
                "presion_diastolica": random.randint(95, 115), "temperatura": round(random.uniform(38.2, 39.6), 1),
                "saturacion_o2": random.randint(86, 91), "glucosa": random.randint(190, 260)}
    return {"frecuencia_cardiaca": random.randint(60, 95), "presion_sistolica": random.randint(105, 125),
            "presion_diastolica": random.randint(65, 80), "temperatura": round(random.uniform(36.2, 37.2), 1),
            "saturacion_o2": random.randint(95, 99), "glucosa": random.randint(75, 120)}


def enviar(url, clave, cuerpo):
    peticion = urllib.request.Request(
        url, data=json.dumps(cuerpo).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json", "X-API-Key": clave},
    )
    try:
        with urllib.request.urlopen(peticion, timeout=10) as respuesta:
            return respuesta.status, json.loads(respuesta.read())
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read() or b"{}")


def main():
    p = argparse.ArgumentParser(description="Simulador de monitor de signos vitales (IoT)")
    p.add_argument("--documento", required=True, help="documento del paciente al que está conectado el monitor")
    p.add_argument("--url", default="http://127.0.0.1:5000/api/signos")
    p.add_argument("--dispositivo", default="monitor-sim-01")
    p.add_argument("--cantidad", type=int, default=3)
    p.add_argument("--intervalo", type=float, default=1.0, help="segundos entre lecturas")
    p.add_argument("--anormal", action="store_true", help="enviar valores fuera de rango (genera alertas)")
    p.add_argument("--clave", help="clave de la API (por defecto SHCE_API_KEY o api_key.key)")
    args = p.parse_args()

    clave = leer_clave(args.clave)
    for numero in range(1, args.cantidad + 1):
        lectura = generar_lectura(args.anormal)
        estado, respuesta = enviar(args.url, clave, {"documento": args.documento, "dispositivo": args.dispositivo, **lectura})
        print(f"[{numero}/{args.cantidad}] {estado} {lectura} -> {respuesta}")
        if numero < args.cantidad:
            time.sleep(args.intervalo)


if __name__ == "__main__":
    main()

"""
procesos_alta.py
----------------
Implementación del patrón de diseño TEMPLATE METHOD (comportamiento): una
clase base define el ESQUELETO de un algoritmo en un método (el «método
plantilla») y deja que las subclases rellenen solo los pasos que varían, sin
poder cambiar el orden general.

¿Por qué Template Method aquí?
------------------------------
Dar de alta a un paciente sigue SIEMPRE la misma secuencia, venga de donde venga:

    1. armar los datos de la historia        <- ESTO es lo que cambia
    2. comprobar que el documento no exista
    3. validar según el tipo de atención (Abstract Factory)
    4. guardar (Singleton)
    5. avisar del alta (Mediator -> notificación automática)

El formulario manual arma los datos con el Builder; la importación del sistema
externo los obtiene con el Adapter. Todo lo demás es idéntico. Antes, la fachada
resolvía esto con un método auxiliar al que cada alta llegaba después de hacer a
mano su primer paso; la secuencia común dependía de que cada llamador se
acordara de usarlo. Con Template Method la secuencia vive en UN método de la
clase base y una tercera vía de alta (p. ej. desde un archivo CSV) solo tiene
que decir cómo arma los datos.

Estructura del patrón en este archivo:
  Clase abstracta    -> ProcesoAlta  (el método plantilla es `ejecutar`)
  Pasos abstractos   -> armar_datos()          (obligatorio: cada alta lo escribe)
  Pasos concretos    -> verificar_documento(), validar_tipo(), guardar()  (comunes)
  Ganchos (hooks)    -> entrada_validador(), despues_de_guardar()  (se pueden sobrescribir)
  Clases concretas   -> AltaManual (Builder), AltaImportada (Adapter)
  Cliente            -> la fachada: `registrar_paciente` e `importar_desde_externo`

Decisiones de diseño:
  - EL MÉTODO PLANTILLA NO SE SOBRESCRIBE. Python no tiene `final`, así que
    `__init_subclass__` lo hace cumplir: una subclase que defina `ejecutar` falla
    al declararse (TypeError), no en producción.
  - PASO ABSTRACTO vs GANCHO: el paso abstracto es obligatorio (sin él no hay
    alta); el gancho tiene una implementación por defecto razonable y solo se
    sobrescribe si hace falta. `AltaManual` sobrescribe `entrada_validador`
    (el validador recibe el formulario tal cual); `despues_de_guardar` avisa del
    alta por defecto y es el punto donde una alta nueva podría añadir algo más.
  - El módulo NO importa fachada.py: devuelve un `ResultadoAlta` propio y la fachada
    lo convierte; el aviso del alta le llega como un callback (`al_registrar`).
  - Los errores de VALIDACIÓN son un resultado, no una excepción (igual que en
    la fachada). Los errores de la fuente de datos (p. ej. código externo
    inexistente) sí se propagan como excepción desde `armar_datos`.
  - Template Method y Strategy se parecen (ambos varían un algoritmo) pero se
    resuelven distinto: Strategy cambia el algoritmo ENTERO por composición
    (se le entrega otro objeto); Template Method fija el esqueleto y cambia
    PASOS sueltos por herencia.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from fabricas import obtener_fabrica                      # Abstract Factory: validador por tipo
from constructor_historia import ConstructorHistoriaClinica   # Builder: alta manual

MENSAJE_DOCUMENTO_REPETIDO = "Ya existe un paciente registrado con ese documento."


@dataclass
class ResultadoAlta:
    """errores: mensajes de validación (vacía = éxito). datos: la historia con la que se trabajó."""
    errores: list = field(default_factory=list)
    datos: dict = field(default_factory=dict)


# =====================================================================
# CLASE ABSTRACTA con el método plantilla
# =====================================================================
class ProcesoAlta(ABC):
    """
    `db` es el receptor (necesita `obtener_paciente_por_documento` y `crear_paciente`).
    `al_registrar(datos)` es el callback que avisa del alta (la fachada lo conecta al Mediator).
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if "ejecutar" in cls.__dict__:
            raise TypeError(
                f"{cls.__name__} no puede sobrescribir `ejecutar`: es el método plantilla. "
                "Sobrescribe solo los pasos (armar_datos) o los ganchos."
            )

    def __init__(self, db, al_registrar=None):
        self._db = db
        self._al_registrar = al_registrar

    # ---- EL MÉTODO PLANTILLA: la secuencia fija ------------------------
    def ejecutar(self, registrado_por: str) -> ResultadoAlta:
        datos, errores = self.armar_datos()                          # 1) paso abstracto
        errores = list(errores)
        errores += self.verificar_documento(datos)                   # 2) paso común
        errores += self.validar_tipo(datos)                          # 3) paso común (usa un gancho)
        if errores:
            return ResultadoAlta(errores=errores, datos=datos)

        if not self.guardar(datos, registrado_por):                  # 4) paso común
            # Red de seguridad: otro alta con el mismo documento se coló entre la
            # comprobación y el guardado (la BD tiene la restricción UNIQUE).
            return ResultadoAlta(errores=[MENSAJE_DOCUMENTO_REPETIDO], datos=datos)

        self.despues_de_guardar(datos)                               # 5) gancho
        return ResultadoAlta(datos=datos)

    # ---- Paso abstracto: lo único que cada alta debe escribir -----------
    @abstractmethod
    def armar_datos(self) -> tuple:
        """Devuelve (datos_de_la_historia, errores_previos)."""
        raise NotImplementedError

    # ---- Pasos comunes -----------------------------------------------
    def verificar_documento(self, datos: dict) -> list:
        if self._db.obtener_paciente_por_documento(datos["documento"]):
            return [MENSAJE_DOCUMENTO_REPETIDO]
        return []

    def validar_tipo(self, datos: dict) -> list:
        validador = obtener_fabrica(datos["tipo_atencion"]).crear_validador()
        return list(validador.validar(self.entrada_validador(datos)))

    def guardar(self, datos: dict, registrado_por: str) -> bool:
        return bool(self._db.crear_paciente(**datos, registrado_por=registrado_por))

    # ---- Ganchos: tienen comportamiento por defecto -------------------
    def entrada_validador(self, datos: dict):
        """Lo que recibe el validador del tipo de atención. Por defecto, la propia historia."""
        return datos

    def despues_de_guardar(self, datos: dict) -> None:
        """Por defecto, avisa del alta (el Mediator decide quién reacciona)."""
        if self._al_registrar is not None:
            self._al_registrar(datos)


# =====================================================================
# CLASES CONCRETAS
# =====================================================================
class AltaManual(ProcesoAlta):
    """Alta desde el formulario web: los datos se arman con el Builder."""

    def __init__(self, db, formulario, al_registrar=None):
        super().__init__(db, al_registrar)
        self._formulario = formulario      # cualquier mapeo con `.get` (p. ej. request.form)

    def armar_datos(self) -> tuple:
        f = self._formulario

        def texto(clave, defecto=""):
            return (f.get(clave, defecto) or "").strip()

        datos = (
            ConstructorHistoriaClinica()
            .con_datos_personales(texto("nombre_completo"), texto("documento"), texto("fecha_nacimiento"))
            .con_motivo_consulta(texto("motivo_consulta"))
            .con_diagnostico(texto("diagnostico"))
            .con_tratamiento(texto("tratamiento"))
            .con_notas(texto("notas"))
            .con_tipo_atencion(
                f.get("tipo_atencion", "consulta_general"),
                prioridad=texto("prioridad") or None,
                fecha_proximo_control=texto("fecha_proximo_control") or None,
            )
            .construir()
        )
        errores = []
        if not datos["nombre_completo"] or not datos["documento"]:
            errores.append("Nombre completo y documento son obligatorios.")
        return datos, errores

    def entrada_validador(self, datos: dict):
        return self._formulario            # gancho sobrescrito: el validador lee el formulario original


class AltaImportada(ProcesoAlta):
    """
    Alta desde el sistema externo. `obtener_adaptado` es una función sin argumentos que
    devuelve la historia ya traducida a nuestro formato (Adapter, con la caché del Proxy
    detrás); si el código externo no existe, su excepción llega tal cual a quien llamó.
    """

    def __init__(self, db, obtener_adaptado, al_registrar=None):
        super().__init__(db, al_registrar)
        self._obtener_adaptado = obtener_adaptado

    def armar_datos(self) -> tuple:
        return self._obtener_adaptado(), []


if __name__ == "__main__":
    class _BDFalsa:
        def __init__(self): self.filas = {}
        def obtener_paciente_por_documento(self, d): return self.filas.get(d)
        def crear_paciente(self, **datos):
            self.filas[datos["documento"]] = datos; return True

    avisos = []
    bd = _BDFalsa()
    formulario = {"nombre_completo": "Ana Ruiz", "documento": "1", "tipo_atencion": "urgencias", "prioridad": "alta"}

    print("1) Mismo esqueleto, dos formas de armar los datos:")
    r = AltaManual(bd, formulario, avisos.append).ejecutar("admin")
    print("   manual   ->", "OK" if not r.errores else r.errores, "| avisos:", len(avisos))
    externo = lambda: {"nombre_completo": "Luis Gómez", "documento": "2", "fecha_nacimiento": "1980-01-01",
                       "motivo_consulta": "x", "diagnostico": "", "tratamiento": "", "notas": "",
                       "tipo_atencion": "consulta_general", "prioridad": None, "fecha_proximo_control": None}
    r = AltaImportada(bd, externo, avisos.append).ejecutar("admin")
    print("   importada ->", "OK" if not r.errores else r.errores, "| avisos:", len(avisos))

    print("2) Los pasos comunes validan igual para ambas:")
    print("   documento repetido:", AltaManual(bd, formulario).ejecutar("admin").errores)
    sin_prioridad = dict(formulario, documento="3", prioridad="")
    print("   urgencia sin prioridad:", AltaManual(bd, sin_prioridad).ejecutar("admin").errores)
    print("   si falla la validación no se guarda ni se avisa:", "3" not in bd.filas, len(avisos) == 2)
    print("   faltan datos básicos:", AltaManual(bd, {"tipo_atencion": "consulta_general"}).ejecutar("admin").errores)

    print("3) Una tercera vía de alta solo escribe armar_datos:")
    class AltaDesdeCSV(ProcesoAlta):
        def armar_datos(self): return dict(externo(), documento="4"), []
    print("   ->", "OK" if not AltaDesdeCSV(bd).ejecutar("admin").errores else "falló", "| en BD:", "4" in bd.filas)

    print("4) El método plantilla no se puede sobrescribir:")
    try:
        class Tramposa(ProcesoAlta):
            def armar_datos(self): return {}, []
            def ejecutar(self, registrado_por): return None
    except TypeError as e:
        print("   TypeError:", e)

    print("5) Sin armar_datos no se puede instanciar:")
    class Incompleta(ProcesoAlta): pass
    try: Incompleta(bd)
    except TypeError as e: print("   TypeError:", str(e)[:70], "...")

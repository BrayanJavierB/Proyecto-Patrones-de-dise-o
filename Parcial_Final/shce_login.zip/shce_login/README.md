# SHCE — Sistema de Historias Clínicas Electrónicas (prototipo local)

Prototipo local (Flask + SQLite) del SHCE: login, registro de usuarios,
y un módulo de pacientes que permite registrar historias clínicas por
tipo de atención, clonarlas como plantilla para una consulta nueva,
importarlas de un sistema externo, notificarlas al equipo clínico,
organizarlas en un árbol de carpetas, y exportarlas en PDF, TXT o CSV
(una historia o una carpeta completa) con opciones como anonimizar o sellar
el archivo con una huella SHA-256, dejando siempre rastro en una bitácora.

Implementa cinco patrones creacionales: **Singleton**, **Factory Method**,
**Abstract Factory**, **Builder** y **Prototype**; y siete patrones
estructurales: **Adapter**, **Bridge**, **Composite**, **Decorator**, **Facade**, **Flyweight** y **Proxy**; y nueve patrones de comportamiento: **Iterator**, **Mediator**, **Memento**, **Observer**, **State**, **Visitor**, **Command**, **Strategy** y **Template Method** (todos explicados más abajo).

> **Nota sobre `app.py` y la Fachada:** las rutas de Flask ya no orquestan los patrones
> directamente; hablan con una única `FachadaSHCE` (`fachada.py`). Por eso, en las secciones
> de cada patrón, las viñetas «`app.py` → ruta X» indican **qué ruta dispara la operación**,
> y la orquestación real (qué patrón se llama y en qué orden) ocurre dentro de `fachada.py`.
> Ver la sección «¿Dónde está el patrón Facade?» para el mapa completo.

## Cumplimiento de los objetivos del proyecto

Esta sección resume **dónde y cómo** cumple el sistema cada objetivo específico del documento del proyecto, y qué límites tiene.

### Objetivo 1: pacientes, citas, diagnósticos y tratamientos

| Función | Dónde está |
|---|---|
| **Registrar** pacientes | `fachada.registrar_paciente()` → `procesos_alta.py` (Template Method) → `singleton.crear_paciente()`; formulario `paciente_nuevo.html`; también importación del sistema externo |
| **Consultar** | Lista (`/pacientes`, con orden por Strategy), **página de detalle** (`/pacientes/<id>`, `paciente_detalle.html`), estructura de carpetas y reportes |
| **Actualizar** | `fachada.editar_paciente()` con historial de versiones (Memento); cambios de estado (State + Command) |
| **Eliminar** | `fachada.eliminar_paciente()` → `singleton.eliminar_paciente()`: borra la historia, sus citas y sus signos vitales en **una transacción**, y deja constancia en la tabla `bitacora_eliminaciones` (quién, qué documento, cuándo). **Solo el administrador** (regla en `PERMISOS`), con casilla de confirmación |
| **Programar citas** | Tabla `citas`; `fachada.programar_cita()` valida paciente, fecha real y no pasada, hora `HH:MM`, médico válido y que **el médico no tenga otra cita a esa fecha y hora**; `cambiar_estado_cita()` (programada → cumplida o cancelada, una sola vez); página `/citas` y sección «Citas» en el detalle del paciente |
| **Diagnósticos y tratamientos** | Campos `diagnostico` y `tratamiento` de cada historia, capturados y editados con historial de versiones; el tratamiento alimenta el detector de interacciones |

Límites: el diagnóstico y el tratamiento siguen siendo un texto libre por historia (no hay un registro separado por cada consulta), y una cita no se puede reprogramar (se cancela y se crea otra). Eliminar es un borrado **físico**; en un sistema real normalmente se exige conservar la historia por ley, y lo habitual es una baja lógica.

### Objetivo 2: signos vitales desde un formulario o un dispositivo IoT

- **Formulario:** en el detalle del paciente (`POST /pacientes/<id>/signos`), para cualquier rol.
- **Dispositivo:** `POST /api/signos` recibe JSON (`documento`, `dispositivo` y los signos) y lo guarda **automáticamente** en la historia del paciente. Se autentica con la cabecera `X-API-Key` (no con sesión de usuario).
- **Simulador:** `simulador_iot.py` imita un monitor y envía lecturas por HTTP:
  ```
  python3 app.py                                                    # terminal 1
  python3 simulador_iot.py --documento 1098765432 --cantidad 5     # terminal 2 (lecturas normales)
  python3 simulador_iot.py --documento 1098765432 --anormal        # lecturas que disparan alertas
  ```
- **Validación y alertas:** `signos_vitales.py` rechaza valores imposibles (un dato corrupto no entra a la historia) y compara con rangos clínicos de referencia; las lecturas fuera de rango muestran una alerta «atención» o «crítica» en la historia y **avisan a quienes siguen al paciente** (Observer, tipo de cambio `signos`).
- **Dónde se guardan:** tabla `signos_vitales` (con `origen` manual o dispositivo, e identificador del equipo).

Límites: no es «tiempo real» con conexión permanente (la página muestra las lecturas al recargarla), la clave de API es una sola compartida por todos los dispositivos y los rangos son orientativos para adultos.

### Objetivo 3: alertas de interacciones medicamentosas

- `interacciones.py` contiene la **base predefinida** (`INTERACCIONES`: 26 pares con gravedad, descripción y recomendación) y el catálogo de medicamentos con alias comerciales (`advil` cuenta como ibuprofeno).
- `buscar_interacciones(tratamiento)` normaliza el texto del tratamiento (sin tildes, con plurales), detecta los medicamentos y busca cada par en la base.
- **Alerta visible:** insignia «⚠ Interacción medicamentosa» en la lista de pacientes, y un bloque destacado en el detalle con los medicamentos, la gravedad, qué puede pasar y la recomendación.
- Se evalúa siempre sobre el tratamiento actual: al editarlo, la alerta aparece o desaparece sola.

Límites: es una base **didáctica** (pocos fármacos, sin dosis ni contexto del paciente). Que no haya alerta no significa que no haya interacción. El medicamento se detecta dentro del texto del tratamiento; no hay una lista estructurada de medicamentos.

### Objetivo 4: seguridad de la información

| Medida | Dónde está |
|---|---|
| **Autenticación** | Contraseñas con hash (`werkzeug`) en `singleton.py`; sesión firmada; `@requiere_login` en las rutas. **Política de contraseña:** mínimo 8 caracteres con letras y números. **Bloqueo:** 5 intentos fallidos seguidos bloquean la cuenta 15 minutos |
| **Sesión** | Clave de firma fuera del código; cookie `HttpOnly` y `SameSite=Lax` (y `Secure` con `SHCE_HTTPS=1`); caduca a los 30 min de inactividad; sesión nueva al iniciar sesión; protección **CSRF** con token en todos los formularios |
| **Control de acceso por roles** | `proxies.py` (`PERMISOS`, niega lo que no figure) con administrador, médico y enfermería; las denegaciones quedan en `bitacora_denegaciones`. **Corregido:** el registro público ya **no permite elegir administrador** (solo médico o enfermería) |
| **Cifrado de datos sensibles** | `seguridad.py` cifra con **Fernet (AES + HMAC)** el nombre, la fecha de nacimiento, el motivo, el diagnóstico, el tratamiento y las notas; en la base de datos solo queda `enc:v1:...` y se descifra al leer (`singleton.py`). Al arrancar, **migra** una base antigua sin cifrar |
| **Gestión de claves** | La clave de cifrado, la de sesión y la de la API salen de variables de entorno (`SHCE_CLAVE_CIFRADO`, `SHCE_SECRET_KEY`, `SHCE_API_KEY`) o se generan en archivos `.key` (permisos 600) junto a la base, que `.gitignore` excluye |
| **Auditoría** | `bitacora_accesos`, `bitacora_exportaciones`, `bitacora_denegaciones` y `bitacora_eliminaciones` |
| **Modo debug** | Desactivado por defecto; solo con `SHCE_DEBUG=1` |

**Importante:** los archivos `.key` se crean la primera vez que se ejecuta la aplicación. **Si los pierdes, los datos cifrados no se pueden recuperar**; haz copia de ellos por separado de la base de datos.

Límites (honestos): el `documento` **no** se cifra, porque la base de datos lo usa para evitar duplicados y buscar (cifrarlo exigiría un índice ciego); quien tenga acceso al servidor y al archivo de clave puede leer los datos; el cifrado en tránsito (HTTPS) lo debe aportar el servidor web, no esta aplicación; y cumplir HIPAA u otras leyes exige además procesos (acuerdos, capacitación, copias de seguridad, gestión de incidentes) que no son código. Estas medidas son una base, no una certificación.

## Cómo ejecutarlo

```bash
cd shce_login
python3 -m venv venv && source venv/bin/activate   # opcional pero recomendado
pip install -r requirements.txt
python3 app.py
```

Abre **http://127.0.0.1:5000** en tu navegador.

Usuarios de prueba (se crean automáticamente la primera vez):

| Usuario | Contraseña   | Rol            |
|---------|--------------|----------------|
| admin   | Admin123     | administrador  |
| brayan  | Medico123    | medico         |

También puedes crear tu propia cuenta desde **"¿No tienes cuenta? Regístrate aquí"**
en la pantalla de login, o entrando directo a `/registro`.

La base de datos local `shce_local.db` (SQLite) se crea sola en la primera
ejecución, con **3 pacientes de ejemplo** ya cargados (uno de cada tipo de
atención: consulta general, control y urgencias) para que puedas probar
la exportación sin crear uno a mano.

## Estructura

```
shce_login/
├── app.py                  # rutas Flask (solo capa web: formularios, sesión, mensajes); habla solo con la fachada
├── fachada.py               # patrón Facade: punto de entrada único a todos los demás patrones
├── singleton.py             # DatabaseManager (patrón Singleton): usuarios + pacientes
├── exportadores.py          # patrón Factory Method: exportar historias en PDF/TXT/CSV
├── fabricas.py               # patrón Abstract Factory: familias validador+formateador por tipo de atención
├── constructor_historia.py   # patrón Builder: arma paso a paso los datos de una historia clínica
├── prototipos.py              # patrón Prototype: clona una historia clínica como plantilla
├── adaptadores.py              # patrón Adapter: integra el Sistema Externo de Historias
├── notificaciones.py             # patrón Bridge: tipo de notificación x canal de envío
├── estructura_clinica.py          # patrón Composite: árbol de carpetas de historias clínicas
├── decoradores.py                  # patrón Decorator: anonimizar / sellar / auditar exportaciones
├── peso_ligero.py                   # patrón Flyweight: pool de objetos sin estado que se comparten (validadores, formateadores, canales, estilos del PDF)
├── iteradores.py                       # patrón Iterator: recorridos del árbol (profundidad/anchura/hojas), del sistema externo y del historial
├── mediador.py                         # patrón Mediator: eventos clínicos que coordinan notificador, historial y auditoría sin que se conozcan
├── memento.py                          # patrón Memento: instantáneas inmutables de la historia clínica para deshacer, rehacer y restaurar versiones
├── observador.py                       # patrón Observer: seguir historias y recibir avisos cuando cambian
├── estados.py                          # patrón State: ciclo de vida de la historia (Registrada, En atención, Atendida, Cerrada)
├── seguridad.py                        # cifrado en reposo de datos sensibles y gestión de claves (Objetivo 4)
├── interacciones.py                    # base de interacciones medicamentosas y detector sobre el tratamiento (Objetivo 3)
├── signos_vitales.py                   # validación y alertas de signos vitales (Objetivo 2)
├── simulador_iot.py                    # script que imita un monitor IoT y envía lecturas a /api/signos (Objetivo 2)
├── procesos_alta.py                    # patrón Template Method: la secuencia fija del alta de un paciente (manual o importada)
├── comandos.py                         # patrón Command: acciones de estado como objetos que se pueden deshacer, rehacer y agrupar por carpeta
├── estrategias.py                      # patrón Strategy: criterios intercambiables para ordenar el listado de pacientes
├── visitantes.py                       # patrón Visitor: reportes (estadísticas, completitud, controles) que recorren el árbol sin modificar sus nodos
├── proxies.py                        # patrón Proxy: caché del sistema externo + protección por rol delante de la fachada
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── _macros.html         # macro reutilizable del campo de contraseña
│   ├── _opciones_exportacion.html  # casillas de decoradores (anonimizar, sello) para exportar
│   ├── _topbar.html         # barra de navegación compartida (Panel / Pacientes / Notificaciones / Estructura)
│   ├── login.html
│   ├── registro.html
│   ├── dashboard.html
│   ├── pacientes.html       # listado + badge de tipo de atención + exportar + "usar como plantilla"
│   ├── paciente_nuevo.html  # formulario (también recibe plantillas del Prototype)
│   ├── paciente_editar.html           # formulario de edición (identidad de solo lectura)
│   ├── paciente_versiones.html        # historial de versiones: deshacer, rehacer y restaurar
│   ├── avisos.html                       # bandeja de avisos del usuario (Observer)
│   ├── reportes.html                     # estadísticas, completitud y agenda de controles (Visitor)
│   ├── importar_externo.html         # listado de historias del sistema externo (Adapter)
│   ├── importar_externo_detalle.html # comparación crudo vs adaptado + confirmar importación
│   ├── notificaciones.html            # combina tipo x canal en vivo (Bridge) + historial
│   └── estructura.html                # árbol de carpetas + exportar/notificar un grupo (Composite)
└── static/
    ├── css/style.css
    └── js/main.js            # icono de ojo + mostrar/ocultar campos condicionales del formulario
```

## ¿Dónde está el patrón Singleton?

En `singleton.py`, la clase `SingletonMeta` es una **metaclase** que
intercepta la creación de instancias. Cualquier clase que la use
(`class DatabaseManager(metaclass=SingletonMeta)`) queda garantizada a tener
**una sola instancia viva** durante toda la ejecución del programa,
sin importar cuántas veces se escriba `DatabaseManager()`.

Por qué tiene sentido en un SHCE:
- Solo debe existir **una** conexión activa a la base de datos (usuarios y pacientes).
- Toda validación de credenciales y toda auditoría de accesos (tabla
  `bitacora_accesos`) pasa por el mismo punto central.
- Es thread-safe (usa `Lock`), pensado para cuando Flask maneje varias
  peticiones al mismo tiempo.

## ¿Dónde está el patrón Factory Method?

En `exportadores.py`. Cuando alguien pide exportar una historia clínica
en PDF, TXT o CSV, la ruta `/pacientes/<id>/exportar/<formato>` de
`app.py` no sabe (ni le importa) cómo se construye cada tipo de archivo.

- `CreadorExportador` es el **creador abstracto**: define el flujo general
  (`exportar_historia`) sin conocer el formato concreto.
- `CreadorPDF`, `CreadorTXT`, `CreadorCSV` son los **creadores concretos**:
  cada uno sobrescribe el **método fábrica** `crear_exportador()` para
  devolver el objeto exportador que le corresponde
  (`ExportadorPDF`, `ExportadorTXT`, `ExportadorCSV`).
- `obtener_creador("pdf")` es solo un diccionario de búsqueda que traduce
  el string del formulario al Creador concreto correcto — eso NO es el
  patrón en sí, es el punto de entrada cómodo.

Ventaja práctica: agregar un formato nuevo (ej. Word) solo exige crear
`ExportadorWord` + `CreadorWord`, sin tocar el código de PDF/TXT/CSV.

## ¿Dónde está el patrón Abstract Factory?

En `fabricas.py`. La diferencia clave con Factory Method: aquí cada
"tipo de atención" (Consulta General, Urgencias, Control) no necesita
UN solo objeto, sino una **familia de dos objetos relacionados que deben
coincidir entre sí**:

1. Un **`ValidadorAtencion`** — sabe qué campos extra exige ese tipo
   (Urgencias exige `prioridad`, Control exige `fecha_proximo_control`).
2. Un **`FormateadorAtencion`** — sabe construir la etiqueta corta que se
   ve en el listado y en las exportaciones (ej. `"Urgencia · Prioridad alta"`),
   junto con su color de badge.

La jerarquía:
- `FabricaAtencion` es la **fábrica abstracta**: declara `crear_validador()`
  y `crear_formateador()`, sin saber a qué tipo de atención pertenecen.
- `FabricaConsultaGeneral`, `FabricaUrgencias`, `FabricaControl` son las
  **fábricas concretas**: cada una construye la pareja validador+formateador
  que le corresponde a SU tipo, garantizando que nunca queden mezclados
  (ej. nunca se valida como "Urgencias" pero se muestra la etiqueta de "Control").
- `obtener_fabrica("urgencias")` es, igual que en Factory Method, solo el
  punto de entrada cómodo — el patrón está en la jerarquía de clases.

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_nuevo()`: pide el **validador** de la fábrica
  para exigir los campos correctos según el tipo de atención elegido.
- `app.py` → ruta `pacientes()`: pide el **formateador** de la fábrica
  para mostrar el badge (texto + color) de cada paciente en el listado.
- `exportadores.py` → reutiliza la misma fábrica para incluir la etiqueta
  de tipo de atención dentro del PDF/TXT/CSV exportado, así los tres
  patrones (Singleton, Factory Method, Abstract Factory) trabajan juntos
  sin pisarse.

Ventaja práctica: agregar un tipo de atención nuevo (ej. "Hospitalización")
solo exige crear su `ValidadorHospitalizacion` + `FormateadorHospitalizacion`
+ `FabricaHospitalizacion`, sin tocar el código de los tipos existentes.

## ¿Dónde está el patrón Builder?

En `constructor_historia.py`. Una historia clínica tiene muchos campos
(11 en total). En vez de pasar todos de golpe como parámetros sueltos
(fácil de desordenar y difícil de leer), `ConstructorHistoriaClinica`
los arma **paso a paso**, encadenando métodos:

```python
ConstructorHistoriaClinica()
    .con_datos_personales("Ana Ruiz", "123", "1990-01-01")
    .con_motivo_consulta("Chequeo anual")
    .con_tipo_atencion("consulta_general")
    .construir()
```

Cada `con_xxx(...)` configura una parte y devuelve `self` (para poder
encadenar); `construir()` es el único método que entrega el diccionario
final ya completo.

`DirectorHistoriaClinica` va un paso más allá: conoce "recetas" para los
casos más comunes (`construir_urgencia_basica`, `construir_control_seguimiento`)
y arma toda la secuencia de pasos por dentro, para que el código que solo
necesita un caso típico no tenga que repetirla.

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_nuevo()`: arma los datos del formulario con
  el Builder en vez de un diccionario literal.
- `singleton.py` → `_sembrar_usuarios_iniciales()`: arma los 3 pacientes
  de ejemplo, mostrando las dos formas de uso (manual, y con el Director).

## ¿Dónde está el patrón Prototype?

En `prototipos.py`. Pensado para el caso típico de "el paciente vuelve
por lo mismo": en una consulta de seguimiento, casi todo se repite
(diagnóstico base, tratamiento, tipo de atención) y solo cambian un par
de detalles. En vez de que el código copie campo por campo (arriesgándose
a copiar por error algo que NO debería repetirse, como el documento),
`HistoriaClinicaPrototype` sabe **clonarse a sí misma**:

- `clonar()` — devuelve una copia profunda e independiente
  (`copy.deepcopy`) de la historia clínica. Modificar el clon nunca
  afecta al original.
- `como_plantilla_nueva()` — clona y además limpia los campos que nunca
  deben heredarse tal cual: el `documento` (es único en la base de
  datos) y las `notas` (son específicas de la cita anterior).

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_duplicar()` (`/pacientes/<id>/duplicar`):
  toma un paciente existente, lo envuelve en el prototipo, pide la
  plantilla, y precarga con ella el formulario de "nueva historia clínica".
- `pacientes.html` → el enlace **"↻ Usar como plantilla para nueva consulta"**
  en cada fila dispara esa ruta.

## ¿Dónde está el patrón Adapter?

En `adaptadores.py`. Es un patrón **estructural** (distinto a los cinco
anteriores, que son creacionales): en vez de resolver CÓMO se crea un
objeto, resuelve cómo hacer que dos interfaces incompatibles trabajen
juntas sin modificar ninguna de las dos.

El caso de uso: el hospital necesita integrar historias que llegan de un
**Sistema Externo de Historias (SEH)** — el software de otra institución,
con un formato de datos totalmente distinto al de SHCE (nombre/apellido
separados, fechas en DD/MM/AAAA, tipo de atención como código numérico,
prioridad como letra). No podemos ni debemos modificar ese sistema
externo, y tampoco queremos que el resto de SHCE aprenda su formato.

- **`FuenteHistoriaClinica`** es el **target**: la interfaz que el resto
  de SHCE ya espera (`obtener_historia_estandar()` → el mismo diccionario
  que produce el Builder).
- **`SistemaExternoHistorias`** es el **adaptee**: el sistema de terceros,
  con su propio método (`consultar_registro()`) y su propio formato,
  incompatible con el nuestro.
- **`AdaptadorSistemaExterno`** es el **adapter**: envuelve (por
  composición, no herencia) una instancia de `SistemaExternoHistorias` y
  traduce cada diferencia de formato, reutilizando el propio
  `ConstructorHistoriaClinica` (Builder) para entregar el resultado con
  la misma forma exacta que ya usa el resto del sistema.

**Dónde se usa en el código:**
- `app.py` → ruta `importar_externo_listar()` (`/pacientes/importar`):
  muestra las historias disponibles en el sistema externo, en su formato
  crudo.
- `app.py` → ruta `importar_externo_detalle()`
  (`/pacientes/importar/<codigo_externo>`): en GET muestra, lado a lado,
  el dato crudo y el dato ya adaptado (aquí es donde se ve el patrón en
  acción); en POST reutiliza la validación del Abstract Factory y guarda
  con el Singleton, exactamente igual que el formulario manual.
- `pacientes.html` → el botón **"⇄ Importar de sistema externo"** dispara
  este flujo.

Ventaja práctica: si mañana el hospital necesita integrarse con OTRO
sistema externo (con su propio formato distinto), solo hay que escribir
un adaptador nuevo — el resto de SHCE (Builder, Abstract Factory,
Singleton, las rutas de Flask) no cambia ni una línea.

## ¿Dónde está el patrón Bridge?

En `notificaciones.py`. También es un patrón **estructural**, pero
resuelve un problema distinto al de Adapter: aquí no hay una interfaz
ajena que traducir, sino **dos cosas que varían de forma independiente**
y que, sin Bridge, terminarían generando una explosión de subclases.

El caso de uso: notificar al equipo clínico tiene dos dimensiones que
cambian por separado:

- **Qué se notifica** (urgencia, recordatorio de control, informativa) — el asunto y el cuerpo del mensaje son distintos para cada una.
- **Cómo se envía** (consola/log interno, email simulado, SMS simulado) — el formato final del mensaje es distinto para cada canal.

Sin Bridge, cada combinación sería una clase (`NotificacionUrgenciaPorEmail`,
`NotificacionUrgenciaPorSMS`, `NotificacionControlPorEmail`...): con 3
tipos y 3 canales, 9 clases. Con Bridge son solo 3 + 3 = 6, conectadas
por **composición** en vez de herencia:

- **`CanalEnvio`** es el **implementador**: la interfaz que cualquier
  canal debe cumplir (`enviar(destinatario, asunto, cuerpo)`).
  `CanalConsola`, `CanalEmailSimulado` y `CanalSMSSimulado` son los
  implementadores concretos — cada uno decide solo CÓMO se formatea y
  entrega el mensaje.
- **`Notificacion`** es la **abstracción**: guarda una *referencia* a un
  `CanalEnvio` (el "puente") y decide QUÉ dice el mensaje, sin saber
  cómo se envía. `NotificacionUrgencia`, `NotificacionControlProximo` y
  `NotificacionInformativa` son las abstracciones refinadas.
- `enviar_para(paciente)` es el método puente: arma el contenido y se
  lo entrega al canal — ninguno de los dos lados conoce los detalles
  internos del otro.

**Dónde se usa en el código:**
- `mediador.py` → `NotificadorAutomatico` (colega que reacciona al evento `paciente_registrado`): se dispara
  automáticamente al crear un paciente de Urgencias o Control (ya sea
  desde el formulario manual o desde una importación por Adapter),
  combinando el tipo correcto con el canal "consola" por defecto.
- `app.py` → ruta `notificaciones()` (`/notificaciones`): página manual
  donde se puede elegir CUALQUIER paciente, tipo y canal, y ver el
  resultado combinado en vivo — aquí es donde más se nota el patrón,
  porque cualquiera de las 9 combinaciones funciona sin código extra.
- `notificaciones.html` → el enlace **"Notificaciones"** en la barra de
  navegación lleva a esta página; también muestra el historial de
  envíos (incluidos los automáticos).

Ventaja práctica: agregar un canal nuevo (ej. WhatsApp) o un tipo nuevo
(ej. "Notificación de alta médica") es una clase más de un solo lado del
puente — nunca hay que tocar ni multiplicar las clases del otro lado.

## ¿Dónde está el patrón Composite?

En `estructura_clinica.py`. Es el tercer patrón **estructural** y resuelve
un problema distinto a Adapter y Bridge: cómo tratar de la misma forma a
**un objeto individual y a un grupo de objetos**, cuando esos grupos pueden
anidarse formando un árbol.

El caso de uso: hasta ahora cada operación del SHCE trabajaba con UN
paciente (exportar su historia, notificarla, mostrar su etiqueta). Pero el
equipo clínico piensa en grupos: "exporta todo lo que registró el Dr.
Brayan", "avisa de todas las urgencias de prioridad alta". Sin Composite,
las rutas de Flask tendrían que distinguir con `if` entre "paciente" y
"grupo", y recorrer los grupos con bucles anidados que cambian cada vez que
cambia la forma del árbol.

- **`ComponenteClinico`** es el **componente**: la interfaz común que
  cumplen hojas y grupos (`contar_historias()`, `obtener_historias()`,
  `exportar(formato)`, `notificar(tipo, canal)`, `buscar(clave)`,
  `recorrer()`). El código cliente solo conoce esta clase.
- **`HistoriaClinicaHoja`** es la **hoja**: envuelve a UN paciente y
  resuelve cada operación apoyándose en los patrones que ya existían
  (Factory Method para exportar, Bridge para notificar, Abstract Factory
  para la etiqueta y el color).
- **`GrupoClinico`** es el **compuesto**: guarda una lista de componentes
  (hojas u otros grupos, sin distinguirlos) y resuelve cada operación
  **delegándola en sus hijos** y combinando los resultados. Como un hijo
  puede ser otro grupo, la recursión recorre todo el árbol sin bucles
  anidados escritos a mano.
- `construir_arbol(pacientes, agrupacion)` arma el árbol a partir de los
  pacientes de la base de datos. Hay dos agrupaciones: *médico → tipo de
  atención* y *tipo de atención → prioridad* (en esta última solo
  Urgencias tiene subcarpetas, así que una misma carpeta puede mezclar
  hojas y grupos: justo lo que permite el patrón).

**Variante usada:** estilo "seguro" del GoF. `agregar()` y `quitar()`
existen solo en `GrupoClinico`, porque no tiene sentido agregarle un hijo a
un paciente. Para *operar* sobre el árbol la uniformidad es total; para
*armarlo* hay que saber que se habla con un grupo.

**Dónde se usa en el código:**
- `app.py` → ruta `estructura()` (`/estructura`): construye el árbol con los
  pacientes del Singleton y lo muestra como carpetas anidadas, con el
  contador de historias de cada carpeta.
- `app.py` → ruta `estructura_exportar()`
  (`/estructura/exportar/<formato>?nodo=...`): llama `nodo.exportar(formato)`
  y entrega un `.zip` con una historia por paciente. Funciona igual para la
  raíz, una subcarpeta o una historia suelta (`nodo` puede ser cualquiera).
- `app.py` → ruta `estructura_notificar()` (`/estructura/notificar`): llama
  `nodo.notificar(tipo, canal)` y notifica a todas las historias de la
  carpeta; los envíos aparecen en el historial de `/notificaciones`.
- `estructura.html` → una macro recursiva dibuja hojas y grupos con el mismo
  código; el enlace **"Estructura"** de la barra de navegación lleva a la página.
- `aceptar(visitante)` → hojas y grupos aceptan visitantes (ver «¿Dónde está el patrón Visitor?»):
  así los reportes nuevos recorren este mismo árbol sin agregarle métodos.

Ventaja práctica: agregar un nivel de agrupación nuevo (ej. por año de
registro) es una entrada más en `_NIVELES`, y agregar una operación nueva
sobre grupos (ej. "archivar") es un método más en el componente — las rutas
no necesitan saber qué forma tiene el árbol.

Probar el módulo sin Flask: `python3 estructura_clinica.py` imprime el árbol
de ejemplo y aplica la misma llamada a una hoja, a una carpeta y a la raíz.

## ¿Dónde está el patrón Decorator?

En `decoradores.py`. Es el cuarto patrón **estructural** y resuelve un
problema distinto a los anteriores: agregarle responsabilidades **opcionales**
a un objeto **sin modificar su clase** y sin crear una subclase por cada
combinación posible.

El caso de uso: el Factory Method ya resuelve CÓMO se genera cada formato
(PDF, TXT, CSV). Pero al exportar una historia clínica aparecen requisitos
extra que no dependen del formato y que el usuario activa según el caso:

- **Anonimizar**: compartir la historia sin exponer la identidad.
- **Sellar**: entregar el archivo con su huella SHA-256 para comprobar que no fue alterado.
- **Auditar**: dejar registrado quién exportó qué historia.

Con herencia serían 3 formatos × 2³ combinaciones = 24 clases; con `if`
dentro de cada exportador se mezclarían responsabilidades que no le
corresponden a un generador de PDF. Con Decorator cada responsabilidad es una
clase, y se apilan en tiempo de ejecución:

- **`ExportadorHistoriaClinica`** (en `exportadores.py`) es el **componente**:
  la interfaz (`generar`, `extension`, `mimetype`, `nombre_archivo`).
- **`ExportadorPDF`, `ExportadorTXT`, `ExportadorCSV`** son los **componentes
  concretos** que ya existían, sin ninguna modificación en su lógica.
- **`ExportadorDecorador`** es el **decorador base**: cumple la misma interfaz
  y guarda una referencia al exportador que envuelve, al que delega por defecto.
- **`ExportadorAnonimizado`**: antes de delegar, reemplaza nombre (iniciales),
  documento (solo 4 últimos dígitos), fecha de nacimiento (solo el año) y
  notas (omitidas). El original no se toca.
- **`ExportadorConSelloIntegridad`**: después de delegar, calcula el SHA-256 y
  entrega un `.zip` con el archivo y su `.sha256`. Verificable con
  `sha256sum -c archivo.sha256`.
- **`ExportadorConAuditoria`**: no cambia el archivo; registra la exportación
  en la tabla `bitacora_exportaciones`. Si el registro falla, el archivo no se
  entrega.

Como un decorador **es** un exportador, el resto del sistema no nota la
diferencia: `CreadorExportador.exportar_historia()` solo recibe una lista
opcional de envolturas y las aplica sobre el exportador que fabrica.

**El orden importa.** `decoradores_para()` apila siempre de adentro hacia
afuera: anonimizar → sellar → auditar. El sello se calcula sobre el archivo ya
anonimizado (el que realmente sale del sistema) y la auditoría, por fuera, ve
la historia **real** del paciente y registra solo si todo lo de adentro terminó bien.

**Dónde se usa en el código:**
- `exportadores.py` → `CreadorExportador.exportar_historia(paciente, decoradores=())`:
  fabrica el exportador (Factory Method) y lo envuelve (Decorator).
- `fachada.py` → `_envolturas()`: traduce las opciones de la URL (`?opciones=anonimizar&opciones=sello`,
  que las rutas `exportar_paciente()` y `estructura_exportar()` de `app.py` le pasan tal cual) a la lista
  de envolturas. La auditoría se agrega siempre, con el usuario de la sesión.
- `estructura_clinica.py` (Composite) → `exportar(formato, decoradores)`: al
  exportar una carpeta, las mismas envolturas se aplican a **cada** historia del árbol.
- `singleton.py` → `registrar_exportacion()` / `obtener_exportaciones()`: la
  bitácora se guarda con la única instancia de `DatabaseManager`. La tabla se
  crea sola al arrancar, así que tu `shce_local.db` anterior sigue funcionando.
- `_opciones_exportacion.html` + `main.js`: casillas "Anonimizar" y "Sello" en
  `/pacientes` y `/estructura`; el JS las agrega a la URL de cada botón PDF/TXT/CSV.
- `dashboard.html` → tarjeta **"Exportaciones recientes (auditoría)"**.

Detalles a tener en cuenta:
- Con anonimización, el nombre del archivo usa el id interno
  (`historia_clinica_anonima_3.pdf`) para no delatar el documento y para que
  dos pacientes nunca choquen dentro de un `.zip`.
- Al exportar una **carpeta** con "Sello", cada historia viaja en su propio
  `.zip` sellado dentro del `.zip` de la carpeta.
- En la bitácora se guarda el documento **real** aunque la exportación sea
  anonimizada: quién accedió a quién es justo lo que se audita.

Ventaja práctica: agregar una responsabilidad nueva (ej. marca de agua o
cifrado) es una clase más que hereda de `ExportadorDecorador` y una línea en
`decoradores_para()`; no se toca ningún exportador ni ninguna ruta.

Probar el módulo sin Flask: `python3 decoradores.py` exporta una historia con
y sin decoradores en los tres formatos, verifica el sello y muestra la bitácora.

## ¿Dónde está el patrón Facade?

En `fachada.py`. Es el quinto patrón **estructural** y el único que no resuelve
cómo crear, adaptar o extender un objeto, sino **cuánto tiene que saber el
cliente** para usar un conjunto de subsistemas.

El caso de uso: con los nueve patrones anteriores en marcha, cada ruta de Flask
tenía que conocer y coordinar a mano varios de ellos. Registrar un paciente
exigía Builder → Singleton (documento único) → Abstract Factory (validar) →
Singleton (guardar) → Bridge (notificar); y la importación desde el sistema
externo repetía casi la misma secuencia con el Adapter al inicio. Esa
coreografía estaba copiada en varias rutas, y cambiar una regla obligaba a
tocarlas todas.

- **`FachadaSHCE`** es la **fachada**: ofrece operaciones con nombres del negocio
  (`registrar_paciente`, `importar_desde_externo`, `exportar_nodo`...) y por dentro
  decide qué subsistema llamar y en qué orden.
- **Los diez módulos de patrones** son los **subsistemas**. La fachada no contiene
  lógica propia de ninguno de ellos: solo los coordina.
- **Las rutas de `app.py`** son los **clientes**: ya no importan ningún módulo de
  patrones, solo `fachada`.

| Operación de la fachada | Subsistemas que coordina |
|---|---|
| `registrar_paciente()` | Template Method (`AltaManual`): Builder → Singleton → Abstract Factory → Singleton → Mediator/Bridge |
| `importar_desde_externo()` | Template Method (`AltaImportada`): Adapter → Singleton → Abstract Factory → Singleton → Mediator/Bridge |
| `listar_pacientes_enriquecidos()` | Singleton + Abstract Factory (formateador) |
| `plantilla_desde_paciente()` | Singleton + Prototype |
| `exportar_paciente()` | Singleton + Factory Method + Decorator |
| `exportar_nodo()` | Composite + Factory Method + Decorator (+ empaquetado en `.zip`) |
| `notificar_paciente()` / `notificar_nodo()` | Bridge (+ Composite para carpetas) |
| `resumen_panel()` | Singleton (bitácora, exportaciones, conteo) + Flyweight (estadísticas del pool) |
| `cambiar_estado()` / `cambiar_estado_nodo()` | State + Command (+ Composite para carpetas) + Observer |
| `deshacer_comando()` / `rehacer_comando()` | Command (historial por usuario) + Observer |
| `listar_pacientes_enriquecidos(orden)` | Singleton + Abstract Factory + State + Strategy |
| `generar_reporte()` | Singleton + Composite + Visitor (tres visitantes recorren el mismo nodo del árbol) |

Decisiones de diseño a tener en cuenta:
- **La fachada no conoce Flask.** No lee `request`, no toca `session` y no llama a
  `flash`: recibe datos simples (el formulario como mapeo, el usuario como texto) y
  devuelve datos simples. Por eso se puede usar y probar sin levantar el servidor.
- **Dos tipos de fallo, dos mecanismos.** Los errores de *validación* (campos
  faltantes, documento repetido) son un resultado normal del flujo y se devuelven en
  un `ResultadoOperacion` con la lista completa de errores. Los errores *esperables
  de otro tipo* (paciente inexistente, formato no soportado, carpeta vacía) son
  subclases de `ErrorFachada`, cuyo mensaje ya es el texto para el usuario: la ruta
  solo hace `flash(str(error))`.
- **El historial de notificaciones** (antes una variable global en `app.py`) ahora es
  estado del colega `HistorialNotificaciones` (ver Mediator), porque es estado del negocio y no de la web. Sigue viviendo
  en memoria y se reinicia con el servidor.
- **Es un atajo, no una barrera.** Los subsistemas siguen siendo independientes y
  cada módulo conserva su `python3 modulo.py`. La fachada también acepta una BD o un
  sistema externo distintos en su constructor (`FachadaSHCE(db=..., sistema_externo=...)`).
- **Una sola clase, siete áreas.** La fachada agrupa cuentas, panel, pacientes,
  importación, exportación, notificaciones y estructura. Si crece mucho, lo natural es
  dividirla en fachadas más pequeñas por área (p. ej. `FachadaPacientes`,
  `FachadaEstructura`) detrás de esta misma interfaz.

**Dónde se usa en el código:**
- `app.py` → `fachada = FachadaSHCE()`: la única instancia; todas las rutas la usan.
- `app.py` → `registro()`, `paciente_nuevo()`, `importar_externo_detalle()`,
  `exportar_paciente()`, `estructura_exportar()`...: cada una es ahora una llamada a la
  fachada más el manejo web del resultado (flash, redirección o plantilla).
- `templates/` no cambió: el catálogo de opciones (`tipos_atencion`, `canales_envio`,
  `agrupaciones`, `opciones_exportacion`) se lo entrega la fachada a las plantillas.

Ventaja práctica: una regla nueva de negocio (p. ej. «notificar también las consultas
generales») se cambia **en un solo lugar** y vale igual para el formulario manual y para
la importación externa. Y una interfaz nueva (una API REST, una línea de comandos) puede
reutilizar toda la lógica llamando a la misma fachada, sin copiar nada de `app.py`.

Probar el módulo sin Flask: `python3 fachada.py` recorre login, alta, importación,
listado, exportación sellada, árbol y notificación masiva sobre una BD temporal (no
toca tu `shce_local.db`).

## ¿Dónde está el patrón Flyweight?

En `peso_ligero.py`. Es el sexto patrón **estructural** y el único que no trata
de la forma de las clases sino de **cuántos objetos hay en memoria**: evita crear
una y otra vez objetos que son exactamente iguales, compartiendo una sola instancia.

El caso de uso: varios de los patrones anteriores producían objetos que **no tienen
ningún estado propio**, y aun así se construían de nuevo en cada uso:

- `obtener_fabrica(tipo)` (Abstract Factory) instanciaba una fábrica y, con ella, un
  validador y un formateador nuevos. Se llamaba una vez por paciente en el listado,
  una vez por hoja del árbol (Composite) y una vez por cada archivo exportado.
- `construir_notificacion(tipo, canal)` (Bridge) instanciaba un canal de envío nuevo
  por notificación: avisar a una carpeta de 200 historias creaba 200 canales idénticos.
- Cada PDF (Factory Method) reconstruía su hoja de estilos completa: cinco
  `ParagraphStyle` y la paleta de colores, aunque siempre fueran los mismos.

Flyweight separa dos clases de estado. Lo que **no depende del contexto** (estado
*intrínseco*) vive dentro del objeto y se comparte; lo que **cambia en cada uso**
(estado *extrínseco*) nunca se guarda en él: el cliente lo pasa como argumento.

| Peso ligero | Estado intrínseco (compartido) | Estado extrínseco (lo pasa el cliente) |
|---|---|---|
| Validador de atención | la regla («Urgencias exige prioridad») | `datos_formulario` |
| Formateador de atención | `color_css` y la forma de la etiqueta | `paciente` |
| Fábrica de atención | su `tipo` | — |
| Canal de envío | su nombre y su formato (SMS: sin saltos, 160 car.) | destinatario, asunto y cuerpo |
| `EstilosPDF` | tipografías, tamaños y paleta de colores | `paciente`, vía `generar(paciente)` |

- **`PesoLigero`** es el **contrato**: un mixin que **impone la inmutabilidad**. Un
  peso ligero que un cliente modificara cambiaría el comportamiento de todos los
  demás, así que cualquier asignación lanza un `AttributeError` con un mensaje claro.
- **`FabricaPesosLigeros`** es la **fábrica de flyweights** (el *pool*):
  `obtener(categoria, clave, constructor)` devuelve siempre el mismo objeto para la
  misma clave y lo construye solo la primera vez. `estadisticas()` cuenta pedidos
  frente a objetos realmente creados. `PESOS_LIGEROS` es la instancia compartida.
- Los **flyweights concretos** son clases que ya existían: `ValidadorAtencion`,
  `FormateadorAtencion` y `FabricaAtencion` con sus subclases (`fabricas.py`),
  `CanalEnvio` con sus subclases (`notificaciones.py`) y la nueva `EstilosPDF`
  (`exportadores.py`).
- Los **clientes** (rutas, fachada, Composite, exportadores) son quienes aportan el
  estado extrínseco, y **no cambiaron**: `obtener_fabrica()`, `crear_formateador()` y
  `construir_notificacion()` conservan su firma y ahora devuelven la instancia compartida.

**Dónde se usa en el código:**
- `fabricas.py` → `obtener_fabrica()` y los `crear_validador()` / `crear_formateador()`
  de cada fábrica concreta piden sus objetos al pool. Esto alcanza sin tocar nada más al
  listado de `pacientes()`, a la validación del paso común de `ProcesoAlta` (Template Method), a la etiqueta de
  cada hoja del Composite y a la etiqueta dentro del PDF/TXT/CSV.
- `notificaciones.py` → `construir_notificacion()` pide el canal al pool. Todas las
  notificaciones, sean de una historia o de una carpeta entera, comparten el mismo canal.
- `exportadores.py` → `obtener_estilos_pdf()` entrega la `EstilosPDF` única, que usa
  `ExportadorPDF.generar()`. Exportar una carpeta en PDF ya no reconstruye los estilos por historia.
- `fachada.py` → `resumen_panel()` expone `PESOS_LIGEROS.estadisticas()` y
  `dashboard.html` lo muestra en la tarjeta **«Patrón Flyweight en acción»** (pedidos
  frente a objetos creados desde que arrancó el servidor). La tarjeta se llena cuando
  abres Pacientes o Estructura y vuelves al panel.

Decisiones de diseño a tener en cuenta:
- **El pool está acotado a propósito.** Las claves se normalizan *antes* de llegar al
  pool: un tipo de atención inventado cae en `consulta_general` y un canal inventado en
  `consola`. Sin esto, cada valor basura que llegara desde un formulario crearía una
  entrada permanente en memoria. El máximo posible es de 13 objetos (3 fábricas, 3
  validadores, 3 formateadores, 3 canales y 1 juego de estilos).
- **Es thread-safe.** Flask atiende varias peticiones a la vez; un `Lock` garantiza
  que dos hilos nunca creen dos pesos ligeros para la misma clave.
- **La fábrica es una instancia de módulo, no un `SingletonMeta`.** Usar la metaclase de
  `singleton.py` obligaría a `fabricas.py`, `notificaciones.py` y `exportadores.py` (hoy
  independientes) a depender de ese módulo, que arrastra sqlite3, werkzeug y el Builder.
  Una instancia de módulo da la misma garantía de unicidad sin ese acoplamiento.
- **Qué NO se comparte, y por qué.** `Notificacion` (la abstracción del Bridge) es la
  parte que más probablemente gane estado propio. Los decoradores guardan estado por
  petición (`_envuelto`, y en `ExportadorConAuditoria` también el usuario y el
  callback), así que no son compartibles. Los creadores y exportadores concretos del
  Factory Method tampoco tienen estado, pero construirlos cuesta lo mismo que
  consultar el pool, así que compartirlos no habría aportado nada.
- **Hoy `EstilosPDF` tiene una sola variante («shce»).** Una apariencia nueva (p. ej.
  alto contraste) sería otra clave con su propia clase, sin tocar a quien ya usa la actual.
- **Si agregas un peso ligero nuevo:** que herede de `PesoLigero`, que reciba el
  contexto por parámetro (nunca en `__init__`) y que su clave salga de un conjunto
  finito. Si la clave puede venir de un formulario, normalízala primero.

**El beneficio real, dicho con honestidad.** En este prototipo la mejora es de
**cantidad de objetos y memoria**, no de velocidad: construir cada uno de estos
objetos cuesta microsegundos y el tiempo de un PDF lo domina `reportlab`. Medido sobre
400 historias (mismo equipo, antes y después; `tracemalloc`):

| | Sin Flyweight | Con Flyweight |
|---|---|---|
| Objetos distintos de atención + canal | 1600 | 4 |
| Memoria retenida por las 400 hojas preparadas (incluye la lista y las 400 `Notificacion`, que no se comparten) | ≈ 177 KiB | ≈ 65 KiB |
| Tiempo de exportar 400 PDF | ≈ 1,1 – 1,2 s | ≈ 1,2 s (sin diferencia apreciable) |
| Pico de memoria al exportar 400 PDF | ≈ 850 KiB | ≈ 825 KiB |

Con los 3 pacientes de ejemplo no se nota nada. El patrón se justifica por la escala
(carpetas con cientos de historias) y porque convierte «este objeto no tiene estado» de
una suposición en una regla que el código hace cumplir.

Probar el módulo sin Flask: `python3 peso_ligero.py` comprueba que dos peticiones
devuelven el mismo objeto, que el estado extrínseco entra por parámetro, que modificar
un peso ligero falla, cuántos objetos se ahorra un caso masivo (800 pedidos → 4
objetos), que 1000 claves inventadas no hacen crecer el pool y que 8 hilos
simultáneos comparten un único objeto.

## ¿Dónde está el patrón Proxy?

En `proxies.py`. Es el séptimo patrón **estructural**. Un proxy tiene **la misma
interfaz** que otro objeto (el *sujeto real*), se coloca delante de él y decide si,
cuándo y cómo se le pasa cada llamada. Se parece a Decorator por la forma (los dos
envuelven un objeto con su misma interfaz), pero la intención es otra: Decorator
**agrega** responsabilidades a lo que entrega el objeto; Proxy **controla el acceso**
sin cambiar lo que ofrece. Y se diferencia de Facade en que no simplifica varios
subsistemas: se interpone delante de **uno solo**.

El proyecto tenía dos lugares donde controlar el acceso tenía sentido real, así que el
módulo trae dos proxies:

**1) `ProxySistemaExterno` — proxy de caché (con papel de proxy remoto).**
El sujeto real es `SistemaExternoHistorias`, el software de *otra institución*. Cada
consulta a un tercero es costosa, y SHCE la repetía sin necesidad: listar las historias
externas pedía cada registro de nuevo en cada visita, y la vista previa de una importación
consultaba el mismo registro **dos veces** (una cruda y otra a través del Adapter). El proxy
recuerda las respuestas `ttl_segundos` (60 por defecto) y solo llama al sistema real cuando
no tiene el dato o está vencido.

- **`RegistrosExternos`** (en `adaptadores.py`) es el **sujeto**: la interfaz común
  (`listar_codigos_disponibles()`, `consultar_registro()`). La implementan el sistema real y su proxy.
- **`ProxySistemaExterno`** es el **proxy**: guarda las respuestas y lleva la cuenta de
  consultas, aciertos y llamadas reales (`estadisticas()`).
- El **Adapter no cambió su lógica**: recibe un `RegistrosExternos` y no sabe si es el real o el proxy.

**2) `ProxyProteccionFachada` — proxy de protección.**
El sujeto real es `FachadaSHCE`. El sistema ya tenía roles (médico, enfermería, administrador)
pero ninguna regla los usaba. El proxy se coloca delante de la fachada con el usuario y el rol
de **quien hace la petición** y comprueba el permiso **antes** de ejecutar cada operación. Si se
niega, lanza `AccesoDenegado` y deja el intento en la tabla `bitacora_denegaciones`.

La política vive en **una sola tabla**, `PERMISOS`, al comienzo de `proxies.py`:

| Operación | Administrador | Médico | Enfermería |
|---|---|---|---|
| Ver panel, pacientes, estructura, reportes y notificaciones | ✔ | ✔ | ✔ |
| Enviar notificaciones (a un paciente o a una carpeta) | ✔ | ✔ | ✔ |
| Registrar paciente, usar plantilla | ✔ | ✔ | ✘ |
| Cambiar estados (también por carpeta), deshacer y rehacer esas acciones | ✔ | ✔ | ✘ |
| Elegir el orden del listado de pacientes | ✔ | ✔ | ✔ |
| Consultar / importar del sistema externo | ✔ | ✔ | ✘ |
| Exportar historia o carpeta | ✔ | ✔ | solo con «Anonimizar» marcado |

**Dónde se usa en el código:**
- `fachada.py` → `__init__()`: envuelve el sistema externo (el real o el que se le pase) en un
  `ProxySistemaExterno`; `resumen_panel()` expone sus estadísticas y las últimas denegaciones.
- `app.py` → `fachada_actual()`: crea, **una vez por petición**, un `ProxyProteccionFachada` con
  el usuario y el rol de la sesión. Todas las rutas lo usan donde antes usaban `fachada`
  (la fachada real ahora se llama `fachada_real`).
- `app.py` → `@app.errorhandler(AccesoDenegado)`: un único lugar que convierte cualquier
  denegación en un mensaje y una redirección al panel; las rutas no necesitan un `except` propio.
- `singleton.py` → `registrar_denegacion()` / `obtener_denegaciones()`: la bitácora se guarda con la
  única instancia de `DatabaseManager`. La tabla se crea sola al arrancar, así que tu
  `shce_local.db` anterior sigue funcionando.
- `dashboard.html` → tarjetas **«Patrón Proxy en acción»**: ahorro de consultas al sistema
  externo y accesos denegados recientes.

Decisiones de diseño a tener en cuenta:
- **Falla cerrado.** Una operación pública de la fachada que no figure en `PERMISOS` se **niega**
  en lugar de dejarse pasar. Así, agregar un método nuevo a la fachada sin decidir quién puede
  usarlo no abre un hueco de seguridad por descuido. Solo `iniciar_sesion` y `registrar_usuario`
  son públicas (son las que crean la sesión o la cuenta); los catálogos (`tipos_atencion`...) son
  datos, no operaciones, y pasan sin comprobación.
- **Un proxy por petición, una fachada para todos.** El usuario y el rol son de cada petición, así
  que el proxy de protección se crea y se descarta con ella; la fachada real (con el historial de
  notificaciones en memoria) sigue siendo única.
- **El proxy lee los argumentos, no solo el nombre de la operación.** La regla de enfermería
  («solo exporta anonimizado») mira el argumento `opciones` con `inspect.signature`, así que
  funciona igual si la ruta lo pasa por nombre o por posición.
- **Un fallo al auditar nunca convierte un NO en un SÍ:** si no se puede guardar la denegación, la
  operación se niega igual.
- **Los errores del sistema externo no se guardan en la caché.** Si el tercero no tiene un código
  (`ValueError`), la excepción llega tal cual y no se crea ninguna entrada; así un código inventado
  en la URL no hace crecer la memoria. Tampoco se entregan referencias internas: el proxy devuelve
  copias, como ya hacía el sistema real.
- **La caché no se entera de los cambios del tercero:** durante el TTL puede mostrar un registro que
  el externo ya modificó. `invalidar()` fuerza una consulta nueva.
- **El proxy de protección vive en la capa web, no en la base de datos.** Protege las operaciones
  de la fachada; quien use `DatabaseManager` directamente (como hacen los scripts de demostración)
  no pasa por él.

Ventaja práctica: cambiar quién puede qué es editar una fila de `PERMISOS`, y cambiar a otro
sistema externo (o a una caché más sofisticada) no toca ni al Adapter ni a las rutas: la fachada y
las rutas hablan con la misma interfaz de siempre.

Probar el módulo sin Flask: `python3 proxies.py` muestra la caché (aciertos, vencimiento, copias,
errores sin cachear) y los permisos por rol sobre una BD temporal (no toca tu `shce_local.db`).

## ¿Dónde está el patrón Iterator?

En `iteradores.py`. Es un patrón de **comportamiento** (los anteriores eran
creacionales y estructurales): no trata de cómo se crean u organizan los objetos,
sino de **cómo se recorre una colección** sin que quien recorre conozca su organización
interna.

El caso de uso: el proyecto recorre colecciones muy distintas, y cada forma de recorrer
estaba mezclada con la lógica de quien la necesitaba: una recursión escrita **dos veces**
en el Composite (hoja y grupo), una comprensión de listas que pedía todos los registros
externos en bloque, un corte `[:limite]` sin posibilidad de filtrar. Con Iterator, cada
forma de recorrer es un objeto con el mismo contrato (`hay_siguiente()`, `siguiente()`,
`reiniciar()`) y además funciona en un `for` normal de Python.

- **`Iterador`** es la **interfaz del iterador**. Cada iterador concreto solo escribe dos
  métodos pequeños (`_producir` y `_reiniciar`); el contrato público, el elemento mirado por
  adelantado y el protocolo `for` los resuelve la clase base.
- **`ColeccionIterable`** es la **interfaz del agregado**: define `crear_iterador()`.
  `ComponenteClinico` (el nodo del Composite) la implementa.
- **Iteradores concretos:**

| Iterador | Recorre | Entrega | Estructura |
|---|---|---|---|
| `IteradorProfundidad` | árbol de carpetas | `(nivel, nodo)`, cada carpeta junto a su contenido | pila |
| `IteradorAnchura` | árbol de carpetas | `(nivel, nodo)`, piso por piso | cola |
| `IteradorHojas` | árbol de carpetas | solo las historias clínicas | se apoya en `IteradorProfundidad` |
| `IteradorRegistrosExternos` | sistema externo (Adapter + Proxy) | un registro crudo por vez, **perezoso** | lista de códigos + posición |
| `IteradorHistorial` | historial de notificaciones (Bridge) | solo los envíos que cumplan los filtros, con tope | instantánea + posición |

Decisiones de diseño a tener en cuenta:
- **Iterador externo y perezoso.** El cliente decide cuándo pide el siguiente elemento. Crear un
  `IteradorRegistrosExternos` no llama al sistema externo; cada `siguiente()` consulta exactamente
  un registro, de modo que lo que nunca se pide nunca se consulta.
- **Sin recursión.** Los recorridos del árbol usan una pila o una cola explícitas: cambiar de
  profundidad a anchura es cambiar de estructura de datos, nada más.
- **Cada iterador tiene su propio estado**, así que puede haber varios recorridos simultáneos
  sobre el mismo árbol sin estorbarse.
- **Instantánea donde la colección cambia.** `IteradorHistorial` copia la lista al crearse: las
  notificaciones que lleguen durante el recorrido no lo desordenan.
- **Los iteradores del árbol no importan `estructura_clinica`.** Solo usan `es_grupo` y `hijos`,
  que ofrece cualquier nodo; así no hay dependencia circular.

**Dónde se usa en el código:**
- `estructura_clinica.py` → `ComponenteClinico.crear_iterador("profundidad" | "anchura" | "hojas")`:
  el nodo fabrica el iterador. `recorrer()` es ahora una sola implementación (antes eran dos
  generadores recursivos) y `GrupoClinico.obtener_historias()` usa el iterador de hojas.
- `fachada.py` → `consultar_estructura()`: arma las carpetas con sangría usando `recorrer()`.
- `fachada.py` → `resumen_por_niveles()`: operación nueva que cuenta carpetas e historias por piso
  con el recorrido en **anchura** (por ahora no la llama ninguna ruta; está lista para una vista).
- `fachada.py` → `listar_registros_externos()`: usa `IteradorRegistrosExternos`.
- `fachada.py` → `historial_notificaciones(limite, tipo_notificacion, canal, paciente)`: usa
  `IteradorHistorial`; con los filtros en `None` se comporta exactamente como antes.
- `proxies.py` → `PERMISOS`: la operación nueva `resumen_por_niveles` tiene su política (el Proxy
  de protección deniega toda operación que no figure ahí).

Probar el módulo sin Flask ni base de datos: `python3 iteradores.py`.

## ¿Dónde está el patrón Mediator?

En `mediador.py`. Es el segundo patrón de **comportamiento** (junto con Iterator): no
organiza objetos ni recorre colecciones, sino que decide **cómo se comunican** varios
objetos entre sí.

El caso de uso: cuando ocurre algo en el SHCE hay reacciones en cadena. Al registrar un
paciente de Urgencias o Control hay que notificarlo, y ese envío debe quedar en el
historial; cuando el proxy niega un acceso hay que dejarlo en la bitácora. Antes, la
fachada cableaba todo a mano: llamaba directo al código de la notificación automática, que
escribía directo en la lista del historial (una lista que se tocaba desde **tres** sitios
distintos), y reenviaba la denegación directo a la base de datos. Cada reacción nueva
obligaba a editar a quien origina el hecho.

Con Mediator, quien origina un hecho solo **avisa** de que ocurrió, y el mediador reparte
el aviso a los colegas suscritos. Los colegas no se conocen entre sí: solo conocen al
mediador.

- **`Mediador`** es la **interfaz** que ven los colegas: `notificar(emisor, evento, **datos)`.
- **`MediadorClinico`** es el **mediador concreto**: guarda la tabla «evento → colegas
  suscritos» y reparte cada aviso en orden de suscripción.
- **`Colega`** es la base de los colegas: conoce solo a su mediador.
- **Colegas concretos y eventos:**

| Evento (`Evento.…`) | Quién lo avisa | Quién reacciona |
|---|---|---|
| `PACIENTE_REGISTRADO` | la fachada, tras guardar el paciente | `NotificadorAutomatico`: si es Urgencias o Control, arma la notificación (Bridge) |
| `NOTIFICACION_ENVIADA` | la fachada (envío manual o a una carpeta) y `NotificadorAutomatico` (envío automático) | `HistorialNotificaciones`: guarda el envío; es ahora la **única** puerta al historial |
| `ACCESO_DENEGADO` | la fachada, cuando el proxy de protección le reporta una denegación | `AuditoriaDenegaciones`: lo deja en la bitácora (Singleton) |

El recorrido de un alta de Urgencias: la fachada avisa `paciente_registrado` → el mediador
se lo entrega al notificador → el notificador avisa `notificacion_enviada` → el mediador se
lo entrega al historial. El notificador no sabe que existe un historial, y viceversa.

Decisiones de diseño a tener en cuenta:
- **Eventos con nombre y validados.** Avisar de un evento inexistente lanza `ValueError`: un
  error de escritura falla de inmediato en vez de no hacer nada en silencio.
- **El emisor no recibe su propio aviso**, así que un colega puede reaccionar a un evento y
  emitir otro distinto sin riesgo de bucles consigo mismo.
- **Orden predecible y errores visibles.** Los colegas reciben cada evento en el orden en que
  se suscribieron, y si uno falla la excepción llega a quien avisó: el mediador coordina, no
  oculta problemas.
- **Rastro de eventos.** `eventos_recientes()` devuelve los últimos eventos procesados con su
  emisor y receptores; sirve para entender y depurar la cadena de reacciones.
- **Una reacción nueva es un colega nuevo.** Por ejemplo, «avisar al médico responsable cuando
  llegue una urgencia» sería otro colega suscrito a `PACIENTE_REGISTRADO`, sin tocar la fachada
  ni el resto de colegas (salvo su línea de suscripción en `FachadaSHCE.__init__`).
- **Riesgo conocido del patrón:** el mediador puede acabar sabiendo demasiado. Aquí se evita
  manteniéndolo «tonto» (solo reparte avisos) y dejando la lógica de cada reacción en su colega.

**Dónde se usa en el código:**
- `fachada.py` → `FachadaSHCE.__init__`: arma el mediador y suscribe a cada colega a su evento.
  Es el único lugar donde se decide quién reacciona a qué.
- `fachada.py` → `_dar_de_alta()`, `notificar_paciente()`, `notificar_nodo()` y
  `registrar_denegacion()`: ya no llaman a nadie, solo avisan con `self._mediador.notificar(...)`.
- `fachada.py` → `historial_notificaciones()`: consulta al colega `HistorialNotificaciones`, que
  usa el Iterator (`IteradorHistorial`) para filtrar.
- `proxies.py`: sin cambios; sigue reportando la denegación a `FachadaSHCE.registrar_denegacion`.

Probar el módulo sin Flask ni base de datos: `python3 mediador.py`.

## ¿Dónde está el patrón Memento?

En `memento.py`. Es el tercer patrón de **comportamiento** (junto con Iterator y Mediator) y
resuelve un problema concreto: **volver un objeto a un estado anterior sin que nadie de afuera
tenga que conocer sus detalles internos**.

El caso de uso: hasta ahora las historias clínicas solo se podían *crear*, nunca corregir. Este
patrón llegó junto con una función nueva, **editar la historia clínica con historial de versiones**.
Un sistema clínico que permite editar tiene que permitir también equivocarse: un diagnóstico mal
escrito, un tratamiento cambiado por error. Antes de cada cambio se toma una instantánea del estado
anterior; con esas instantáneas se puede **deshacer**, **rehacer** o **restaurar** cualquier versión.

- **`HistoriaClinicaEditable`** es el **originador**: la parte editable de la historia. Es el único que
  sabe tomarse una instantánea (`crear_memento`) y volver a ella (`restaurar`).
- **`MementoHistoria`** es el **memento**: la instantánea. Es inmutable y hacia afuera solo muestra
  metadatos (quién, cuándo, por qué, un resumen); su contenido solo lo lee el originador de esa misma historia.
- **`HistorialVersiones`** es el **cuidador**: guarda las pilas de deshacer y rehacer por paciente.
  **Nunca mira dentro** de una instantánea (hay una prueba con un «espía» que lo verifica).
- **La fachada** hace de cliente: coordina originador, cuidador, Builder, validador y base de datos.

| Operación de la fachada | Qué hace con el Memento |
|---|---|
| `editar_paciente()` | foto del estado anterior → aplica el cambio → guarda en la BD → entrega la foto al cuidador |
| `deshacer_edicion()` | pide al cuidador la foto previa (dejando el estado actual en «rehacer») y la restaura |
| `rehacer_edicion()` | lo contrario: vuelve a aplicar lo que se acaba de deshacer |
| `restaurar_version()` | lleva la historia a una versión elegida, tomando antes una foto del estado actual |
| `versiones_paciente()` | lista las versiones guardadas (solo metadatos) y qué acciones están disponibles |

Decisiones de diseño a tener en cuenta:
- **Encapsulación.** El memento guarda su estado en un atributo privado y solo lo entrega a un originador de
  *su misma historia*: restaurar la foto del paciente 3 en el paciente 5 lanza `ValueError`. Python no tiene
  «privado» real, así que es protección por convención y verificación: evita errores, no detiene a quien
  decida saltársela a propósito.
- **Inmutabilidad.** El estado se copia en profundidad al crear la foto y se guarda en un `MappingProxyType`
  de solo lectura; además se prohíbe asignar atributos. Editar la historia después no altera fotos ya tomadas.
- **La identidad no se edita.** Nombre, documento y fecha de nacimiento identifican al paciente y quedan fuera
  de lo que se captura: aunque alguien los incluya en la petición, se ignoran. Solo se versionan los campos
  clínicos (`CAMPOS_CLINICOS`).
- **Mismas reglas que el alta.** La edición arma los datos con el **Builder** y los valida con el validador del
  tipo de atención (**Abstract Factory**), así que no hay reglas duplicadas. Editar no dispara notificaciones
  automáticas (solo el alta lo hace).
- **Un cambio nuevo descarta el «rehacer»**, como en cualquier editor. Una edición sin cambios reales o que no
  pasa la validación no deja versiones basura.
- **Restaurar no borra historia.** Antes de volver a una versión se toma una foto del estado actual, así que
  la propia restauración se puede deshacer y nada se pierde.
- **Límite de 20 versiones por paciente** (las más recientes), para que la memoria no crezca sin fin.
- **Vive en memoria, como el historial de notificaciones**: se reinicia con el servidor. Guardarlo en la base de
  datos exigiría serializar las fotos (p. ej. a JSON) y crear una tabla nueva; no se hizo para no cambiar el
  esquema de tu `shce_local.db`. El cuidador usa un cerrojo porque Flask puede atender varias peticiones a la vez.
- **Permisos** (Proxy): editar, deshacer, rehacer y restaurar son de administrador y médico; **consultar** las
  versiones es de todos los roles, incluida enfermería.

**Dónde se usa en el código:**
- `app.py` → rutas `paciente_editar()`, `paciente_versiones()`, `paciente_deshacer()`, `paciente_rehacer()` y
  `paciente_restaurar()`: son la capa web de las operaciones de la fachada.
- `fachada.py` → sección «Edición con historial de versiones (Memento)»; `singleton.py` →
  `actualizar_historia_clinica()` (el `UPDATE` de solo los campos clínicos); `proxies.py` → `PERMISOS`.
- `templates/pacientes.html` → enlaces «Editar historia» (solo médico/administrador) y «Versiones»;
  `templates/paciente_editar.html` y `templates/paciente_versiones.html` son las pantallas nuevas.

Probar el módulo sin Flask ni base de datos: `python3 memento.py`.

## ¿Dónde está el patrón Observer?

En `observador.py`. Es un patrón de **comportamiento** que resuelve una necesidad concreta: **enterarse de los
cambios de algo sin tener que ir a mirarlo todo el tiempo**. Un objeto («sujeto») mantiene una lista de
interesados («observadores») y los avisa automáticamente cuando cambia, sin saber quiénes son ni qué hacen con el aviso.

El caso de uso: una historia clínica la pueden tocar varias personas. Quien la sigue de cerca (el médico responsable, un
jefe de servicio) necesita enterarse cuando otro la edita, deshace un cambio o la pasa a «Atendida». Con Observer, cada
usuario puede **suscribirse** a las historias que le interesan («☆ Seguir») y recibir un aviso en su bandeja (🔔 Avisos).

- **`Observador`** es la **interfaz**: todo el que quiera enterarse implementa `actualizar(cambio)`.
- **`Sujeto`** es la base de lo observable: `suscribir`, `cancelar` y `notificar_observadores`.
- **`PacienteObservable`** es el **sujeto concreto**: uno por historia seguida.
- **`BandejaAvisos`** es el **observador concreto**: la bandeja de avisos de un usuario.
- **`CambioHistoria`** es el evento que viaja: qué cambió, quién lo hizo y cuándo (inmutable).
- **`ServicioSeguimiento`** guarda los sujetos y las bandejas y los conecta.

**Qué hace el back:** al editar, deshacer, rehacer, restaurar una versión o cambiar el estado, la fachada publica un
`CambioHistoria`; el sujeto de esa historia lo reparte a las bandejas de quienes la siguen. **Qué hace el front:** la lista
de pacientes muestra «☆ Seguir» / «★ Siguiendo», la barra superior muestra el contador «🔔 Avisos (N)» en todas las páginas
y `/avisos` lista los cambios con un botón para marcarlos como leídos.

Decisiones de diseño a tener en cuenta:
- **Observer y Mediator no son lo mismo.** El Mediator (`mediador.py`) coordina colaboradores **internos y fijos** del
  sistema, cableados una sola vez al arrancar. El Observer maneja suscripciones **dinámicas elegidas por los usuarios** en
  tiempo de ejecución: cada uno decide a qué historias suscribirse y cuándo dejar de hacerlo.
- **Un observador roto no arruina a los demás.** `notificar_observadores` aísla cada aviso: si una bandeja falla, las otras
  igual lo reciben y la edición clínica (que ya se guardó) no se deshace. Los fallos se devuelven, no se ocultan.
- **El autor no se avisa a sí mismo**, y lo que falla o se bloquea (edición sin cambios, historia no editable, acción de
  estado inválida) **no genera avisos**: solo se avisa de cambios que de verdad ocurrieron.
- **Dejar de seguir** detiene los avisos futuros pero conserva los ya recibidos. Cada bandeja guarda como máximo 100 avisos.
- **Vive en memoria**, como el historial de notificaciones y el de versiones: las suscripciones y avisos se reinician con el
  servidor. Guardarlos en la base de datos exigiría tablas nuevas.
- **Permisos:** seguir y leer avisos es de todos los roles, incluida enfermería.

**Dónde se usa en el código:** `fachada.py` → sección «Seguimiento de historias y avisos (Observer)» y el método `_publicar()`;
`app.py` → rutas `paciente_seguir`, `paciente_dejar_de_seguir`, `avisos`, `avisos_leer` y el *context processor* `_inyectar_avisos`;
`templates/_topbar.html`, `templates/pacientes.html` y `templates/avisos.html`. Probar sin Flask: `python3 observador.py`.

## ¿Dónde está el patrón State?

En `estados.py`. Es un patrón de **comportamiento** en el que **un objeto cambia su comportamiento cuando cambia su estado
interno**, delegando en un objeto-estado distinto por cada estado, en lugar de llenar el código de `if`.

El caso de uso: una historia clínica tiene un **ciclo de vida**, y lo que se puede hacer con ella depende de en qué punto está.

```
Registrada ──iniciar_atencion──▶ En atención ──dar_alta──▶ Atendida ──cerrar──▶ Cerrada
                                     ▲                         │                    │
                                     └──────── reabrir ────────┴────── reabrir ─────┘
```

| Estado | ¿Se puede editar? | Acciones que ofrece |
|---|---|---|
| Registrada | Sí | iniciar atención |
| En atención | Sí | dar de alta |
| Atendida | **No** | cerrar, reabrir |
| Cerrada | **No** | reabrir |

- **`CicloVidaHistoria`** es el **contexto**: guarda el estado actual y le delega todo. No contiene ningún `if estado == ...`.
- **`EstadoHistoria`** es la **interfaz del estado**: `puede_editar()`, las `acciones` que ofrece y las transiciones.
- **`Registrada`, `EnAtencion`, `Atendida` y `Cerrada`** son los **estados concretos**; cada uno sabe a cuál pasar.

**Qué hace el back:** la fachada lee el estado guardado en la base de datos, se lo da al contexto, ejecuta la acción y guarda el
estado resultante. Además, mientras la historia esté Atendida o Cerrada, **rechaza** editar, deshacer, rehacer y restaurar
versiones. **Qué hace el front:** muestra una insignia con el estado en cada historia, solo ofrece los botones de las acciones
que ese estado permite (para administrador y médico), y cambia «✎ Editar historia» por «🔒 No editable» cuando corresponde.

Decisiones de diseño a tener en cuenta:
- **Las transiciones las decide el estado**, no una tabla de reglas en el contexto: el estado actual le dice al contexto a cuál pasar.
- **Lista blanca de acciones.** El contexto solo ejecuta nombres que el estado actual ofrece, así que un texto arbitrario que
  llegue desde la URL no puede invocar otro método. Pedir una acción no permitida lanza un error claro.
- **Los estados no guardan datos**, solo comportamiento, así que se comparten: hay una sola instancia de cada uno.
- **El estado se guarda en la base de datos** (columna `estado_atencion` de `pacientes`), a diferencia de las versiones o los
  avisos, porque es un dato clínico y debe sobrevivir a reinicios. Se agrega con la **migración automática** que el proyecto ya
  tenía: al primer arranque tu `shce_local.db` recibe la columna y todas las historias existentes quedan «Registrada»
  (editables), así que nada cambia para ellas. La migración se probó sobre una copia de una base real y es idempotente.
- **El estado no conoce roles**: quién puede cambiarlo lo decide el Proxy de protección (administrador y médico).
- **State y Memento conviven:** el estado decide *si* se puede editar; el Memento permite *deshacer* lo editado. Ver las
  versiones sigue siendo posible aunque la historia esté cerrada.
- **State y Observer colaboran:** cada cambio de estado publica un aviso a los seguidores («En atención → Atendida»).

**Dónde se usa en el código:** `fachada.py` → `cambiar_estado()`, `_paciente_editable()` y `_info_estado()`; `singleton.py` →
`actualizar_estado_paciente()` y la migración; `app.py` → ruta `paciente_estado`; `templates/pacientes.html`,
`templates/paciente_versiones.html` y la clase `.badge-estado` de `static/css/style.css`. Probar sin Flask: `python3 estados.py`.

## ¿Dónde está el patrón Visitor?

En `visitantes.py`. Es el sexto patrón de **comportamiento** (junto con Iterator, Mediator, Memento,
Observer y State) y resuelve un problema distinto a los anteriores: **agregar operaciones nuevas a una
estructura de objetos sin modificar las clases de sus elementos**.

El caso de uso: el árbol del Composite tiene solo dos tipos de nodo, y no van a cambiar (la historia suelta y
la carpeta). Lo que sí crece son las preguntas que el equipo clínico le hace al árbol: «¿cuántas historias hay por
tipo, estado y médico?», «¿cuáles tienen datos sin completar?», «¿qué controles ya vencieron?». Sin Visitor,
cada pregunta sería un método más en `ComponenteClinico` y, por tanto, uno en la hoja y otro en el grupo. Con
Visitor, cada pregunta es una **clase** y los nodos solo aprenden una vez a aceptar visitantes:

```python
resultado = raiz.aceptar(VisitanteEstadisticas()).resultado()
```

El truco se llama **doble despacho**: el nodo no sabe qué visitante recibe y el visitante no sabe qué tipo de
nodo le toca, así que se resuelve en dos saltos. Primero se elige según el tipo del nodo (`aceptar`) y luego según el
tipo del visitante (`visitar_historia`, `entrar_grupo`, `salir_grupo`).

- **`Visitante`** es la **interfaz del visitante**: `visitar_historia(hoja)` (obligatorio), `entrar_grupo(grupo)` y
  `salir_grupo(grupo)` (ganchos opcionales que por defecto no hacen nada) y `resultado()`.
- **`ElementoVisitable`** es la **interfaz del elemento**: define `aceptar(visitante)`. `ComponenteClinico` (el
  nodo del Composite) la implementa.
- **`HistoriaClinicaHoja.aceptar`** llama a `visitar_historia`; **`GrupoClinico.aceptar`** llama a `entrar_grupo`,
  acepta a cada hijo (hoja o grupo, sin distinguirlos) y llama a `salir_grupo`.
- **Visitantes concretos:**

| Visitante | Qué averigua | Ganchos de carpeta |
|---|---|---|
| `VisitanteEstadisticas` | historias por tipo de atención, estado, médico y (en urgencias) prioridad | no los usa |
| `VisitanteCompletitud` | historias con motivo, diagnóstico o tratamiento vacíos, urgencias sin prioridad y controles sin fecha válida, con la carpeta de cada una | sí: lleva la ruta |
| `VisitanteControles` | próximos controles vencidos, de los siguientes 7 días o programados más adelante | sí: lleva la ruta |

`VisitanteCompletitud` y `VisitanteControles` heredan de `VisitanteConRuta`, que apila el nombre de la carpeta al
entrar y lo saca al salir para poder decir, p. ej., «Todas las historias clínicas › Registrado por admin › Control».

**Qué hace el back:** `FachadaSHCE.generar_reporte(agrupacion, nodo_clave)` arma el árbol, elige el nodo (la raíz o
una carpeta) y lo recorre con los tres visitantes, uno nuevo por cada recorrido. **Qué hace el front:** la
página **Reportes** de la barra superior muestra las tres tarjetas; se puede cambiar la agrupación y limitar el
análisis a una carpeta.

Decisiones de diseño a tener en cuenta:
- **El recorrido lo hace la estructura, no el visitante.** Por eso `GrupoClinico.aceptar` es recursivo (la
  profundidad la fija `_NIVELES`, hoy 3). No se usó el Iterator porque los visitantes con ruta necesitan el aviso de
  *salida* de cada carpeta, y un recorrido lineal de `(nivel, nodo)` no lo entrega.
- **Un visitante por recorrido.** Guarda estado (contadores, hallazgos, la ruta actual), así que **no** es un peso
  ligero: se crea uno nuevo en cada reporte y se descarta. Dos recorridos a la vez nunca se mezclan.
- **Solo lectura.** Ningún visitante modifica el árbol ni la base de datos. Visitor permitiría operaciones que
  cambian cosas, pero son reportes y es más seguro que no puedan alterar historias clínicas.
- **Sin dependencia circular.** `visitantes.py` no importa `estructura_clinica`: los visitantes solo usan `hoja.paciente`,
  `hoja.nombre` y `grupo.nombre`. Es el Composite quien importa a `visitantes.py`.
- **El costo conocido del patrón:** agregar un nuevo *tipo de nodo* obligaría a tocar todos los visitantes. Compensa porque
  aquí lo estable son hojas y carpetas, y lo que cambia son los reportes.
- **Lo que ya existía no se migró.** `exportar`, `notificar` y `contar_historias` siguen siendo métodos del Composite:
  ya funcionan apoyados en Factory Method, Bridge y Decorator, y llevarlos a visitantes sería un refactor sin
  beneficio por ahora. Visitor se usa para lo **nuevo**.
- **`VisitanteCompletitud` no reutiliza el validador del Abstract Factory** porque sus mensajes están redactados para
  quien llena el formulario («debes indicar...»), no para quien lee un reporte. La regla de «urgencias exige prioridad»
  y «control exige fecha» queda, por tanto, escrita en dos sitios.
- **`VisitanteControles` ignora las historias Cerradas** (archivadas, nada pendiente) pero no las Atendidas, cuyo control
  futuro sigue en pie. Usa la fecha del servidor; `generar_reporte(..., hoy=date(...))` permite fijarla para probar.
- **No hay caché.** El reporte se recalcula en cada visita a partir de los pacientes de la base de datos: es proporcional
  al número de historias, suficiente para este prototipo.
- **Permisos:** ver reportes es de todos los roles (administrador, médico y enfermería), como ya lo es ver la
  lista de pacientes y la estructura.

**Dónde se usa en el código:**
- `estructura_clinica.py` → `ComponenteClinico` hereda de `ElementoVisitable`; `HistoriaClinicaHoja.aceptar()` y
  `GrupoClinico.aceptar()`.
- `fachada.py` → `generar_reporte()`; el cálculo de las carpetas para el `<select>` se extrajo a
  `_carpetas_para_selector()`, que ahora comparten `consultar_estructura()` y este método.
- `proxies.py` → `PERMISOS`: la operación nueva `generar_reporte` tiene su política (el Proxy de protección deniega toda
  operación que no figure ahí).
- `app.py` → ruta `reportes()` (`/reportes?agrupar=...&nodo=...`).
- `templates/reportes.html`, `templates/_topbar.html` (enlace **Reportes**) y la sección «Reportes» de `static/css/style.css`.

Ventaja práctica: un reporte nuevo (p. ej. «historias sin seguidores» o «urgencias abiertas hace más de un día») es una clase
más en `visitantes.py`, una línea en `generar_reporte()` y su tarjeta en la plantilla; `HistoriaClinicaHoja`,
`GrupoClinico` y los demás visitantes no se tocan.

Probar el módulo sin Flask ni base de datos: `python3 visitantes.py`.

## ¿Dónde está el patrón Command?

En `comandos.py`. Es un patrón de **comportamiento** que convierte una **petición en un objeto**: una acción deja de ser
«una llamada que se ejecuta y se olvida» y pasa a ser algo que se puede guardar, deshacer, rehacer, agrupar y listar.

El caso de uso: cambiar el estado de una historia (iniciar atención, dar de alta, cerrar, reabrir) era una llamada directa que no
dejaba rastro: un «cerrar» equivocado no se podía revertir, y aplicar la misma acción a toda una carpeta no tenía garantías. Con Command
cada cambio es un objeto que sabe ejecutarse **y** deshacerse, y un historial por usuario permite deshacer y rehacer.

- **`Comando`** es la **interfaz**: `ejecutar()`, `deshacer()` y `rehacer()`.
- **`ComandoCambiarEstado`** es el **comando concreto**: guarda el estado anterior y el nuevo. Quién decide a qué estado se pasa sigue
  siendo el patrón State; el comando solo lo ejecuta y recuerda cómo volver.
- **`ComandoMacro`** es un comando que contiene otros comandos y los trata como uno solo.
- **`HistorialComandos`** es el **invocador**: ejecuta los comandos y guarda, por usuario, las pilas de deshacer y rehacer.
- **El receptor** es el estado de la historia (la base de datos del Singleton y el ciclo de vida del State). **El cliente** es la fachada.

**Qué hace el back:** `cambiar_estado()` (una historia) y `cambiar_estado_nodo()` (una carpeta del Composite) crean el comando y lo pasan por
el historial; la fachada avisa a los seguidores (Observer) de cada historia afectada, también al deshacer o rehacer. **Qué hace el front:**
en **Estructura**, médicos y administradores ven el formulario «Cambiar el estado de toda una carpeta» y el historial de acciones con
los botones «↶ Deshacer» y «↷ Rehacer». Los cambios hechos desde la lista de pacientes también quedan en ese historial.

Decisiones de diseño a tener en cuenta:
- **Deshacer no pisa cambios ajenos.** Antes de deshacer, el comando comprueba que la historia siga en el estado que él dejó; si alguien
  la cambió después, se niega con un mensaje y no toca nada (lo mismo al rehacer).
- **El macro es todo o nada.** Si un comando hijo falla a mitad, los que ya se ejecutaron se deshacen y el error se propaga. Las historias
  cuyo estado no ofrece la acción no entran al macro: se omiten y se informa cuántas.
- **Historial por usuario, en memoria.** Cada uno deshace sus propias acciones (máximo 20) y se reinicia con el servidor, como las versiones
  del Memento y los avisos del Observer.
- **Un comando que ya no se puede deshacer se descarta del historial**; si se conservara, bloquearía para siempre a los que están debajo.
- **Command no reemplaza a Memento.** Memento restaura el *contenido clínico* de una historia (ediciones); Command revierte *acciones de ciclo
  de vida*. Son historiales independientes.
- **Los comandos no conocen roles ni avisos:** exponen `cambios` y es la fachada quien avisa. Los permisos los decide el Proxy (solo administrador
  y médico; todos pueden ver su propio historial).

**Dónde se usa en el código:** `fachada.py` → `cambiar_estado()` (ahora ejecuta un comando), `cambiar_estado_nodo()`, `deshacer_comando()`,
`rehacer_comando()`, `comandos_recientes()` e `_invocar()`; `proxies.py` → `PERMISOS`; `app.py` → rutas `estructura_estado`, `comando_deshacer`
y `comando_rehacer`; `templates/estructura.html`. Probar sin Flask ni base de datos: `python3 comandos.py`.

## ¿Dónde está el patrón Strategy?

En `estrategias.py`. Es un patrón de **comportamiento** que define una **familia de algoritmos intercambiables**, encapsula cada uno en su
clase y deja elegir cuál usar en tiempo de ejecución sin que quien los usa cambie.

El caso de uso: el listado de pacientes salía siempre «más reciente primero». El equipo necesita verlo de otras maneras según el momento
(alfabético para buscar a alguien, urgencias graves primero en un turno, o por el próximo control más cercano). Sin Strategy habría un
`if orden == "nombre": ... elif ...` en la fachada, y cada criterio nuevo obligaría a editarlo.

- **`EstrategiaOrden`** es la **interfaz**: `clave_orden(paciente)`.
- **Estrategias concretas:** `OrdenRecientes`, `OrdenNombre`, `OrdenUrgencia` (alta, media, baja, sin prioridad y luego el resto) y
  `OrdenControl` (próximo control más cercano; sin fecha, al final).
- **`OrdenadorPacientes`** es el **contexto**: guarda una estrategia y le delega. No tiene ningún `if orden == ...`.

**Qué hace el back:** `listar_pacientes_enriquecidos(orden)` pide la estrategia al contexto y ordena. **Qué hace el front:** la página
**Pacientes** muestra los botones «Ordenar» (`/pacientes?orden=nombre`); una clave desconocida cae en el orden por defecto en vez de dar error.

Decisiones de diseño a tener en cuenta:
- **La estrategia solo decide la clave de orden;** el contexto hace el `sorted` y devuelve una lista nueva (la original no se modifica).
- **Las estrategias no tienen estado,** así que se comparten: una sola instancia de cada una (`ESTRATEGIAS`). `obtener_estrategia()` es solo el
  diccionario que traduce el texto de la URL; el patrón está en la jerarquía de clases.
- **Todas desempatan por «más reciente primero»,** para que el orden sea estable.
- **Strategy y State se parecen en la forma pero no en la intención:** aquí quien usa el objeto elige el algoritmo desde fuera; en State el propio
  objeto cambia de estado por sí mismo.
- Ordenar es lectura pura: lo pueden usar todos los roles, incluida enfermería.

**Dónde se usa en el código:** `fachada.py` → `listar_pacientes_enriquecidos(orden)`, `normalizar_orden()` y el catálogo `ordenes_disponibles`;
`proxies.py` → `PERMISOS`; `app.py` → ruta `pacientes()`; `templates/pacientes.html`. Ventaja práctica: un criterio nuevo (p. ej. «por edad») es una
clase más en `estrategias.py` y una entrada en `ESTRATEGIAS`; ninguna ruta, plantilla ni la fachada se tocan. Probar sin Flask: `python3 estrategias.py`.

## ¿Dónde está el patrón Template Method?

En `procesos_alta.py`. Es un patrón de **comportamiento** en el que una clase base define el **esqueleto de un algoritmo** en un método (el
«método plantilla») y deja que las subclases rellenen **solo los pasos que varían**, sin poder cambiar el orden general.

El caso de uso: dar de alta a un paciente sigue siempre la misma secuencia, venga de donde venga: armar los datos de la historia, comprobar
que el documento no exista, validar según el tipo de atención (Abstract Factory), guardar (Singleton) y avisar del alta (Mediator). El formulario
manual arma los datos con el Builder; la importación del sistema externo los obtiene con el Adapter; **todo lo demás es idéntico**. Antes, la
fachada tenía un método auxiliar al que cada alta llegaba después de hacer a mano su primer paso, y la secuencia común dependía de que cada
llamador se acordara de usarlo. Ahora la secuencia vive en un único método.

- **`ProcesoAlta`** es la **clase abstracta**; su método **`ejecutar()`** es el **método plantilla** (la secuencia fija).
- **Paso abstracto (obligatorio):** `armar_datos()`. Cada alta lo escribe a su manera.
- **Pasos comunes (ya escritos):** `verificar_documento()`, `validar_tipo()` y `guardar()`.
- **Ganchos (opcionales, con comportamiento por defecto):** `entrada_validador()` (qué recibe el validador) y `despues_de_guardar()` (por defecto,
  avisa del alta).
- **`AltaManual`** arma los datos con el Builder y sobrescribe el gancho `entrada_validador` para que el validador lea el formulario original.
  **`AltaImportada`** obtiene los datos con el Adapter (a través del caché del Proxy).

**Qué hace el back:** `registrar_paciente()` e `importar_desde_externo()` de la fachada eligen la clase concreta y llaman a `ejecutar()`;
`_dar_de_alta()` traduce el resultado al `ResultadoOperacion` de siempre y `_avisar_alta()` conecta el aviso con el Mediator. **Qué hace el front:**
nada cambia: el formulario, la importación y sus mensajes funcionan igual; el patrón es un refactor del back.

Decisiones de diseño a tener en cuenta:
- **El método plantilla no se sobrescribe.** Python no tiene `final`, así que `__init_subclass__` lo hace cumplir: una subclase que defina
  `ejecutar` falla al declararse con un `TypeError`, no en producción.
- **Paso abstracto vs. gancho.** El paso abstracto es obligatorio (sin él no hay alta; Python impide instanciar la clase sin él); el gancho
  tiene una versión por defecto razonable y solo se sobrescribe si hace falta.
- **Una tercera vía de alta** (p. ej. desde un archivo CSV) solo tiene que escribir `armar_datos()`: validación, guardado y aviso los hereda.
- **El módulo no importa `fachada.py`:** devuelve su propio `ResultadoAlta` y recibe el aviso del alta como un callback.
- **Los errores de validación son un resultado, no una excepción** (como en toda la fachada). Los de la fuente de datos (p. ej. un código externo
  inexistente) sí se propagan como excepción desde `armar_datos()`.
- **Template Method no es Strategy.** Los dos varían un algoritmo, pero Strategy cambia el algoritmo *entero* por composición (se entrega
  otro objeto); Template Method fija el esqueleto y cambia *pasos sueltos* por herencia.
- **El comportamiento no cambió:** el orden de los errores (datos básicos → documento repetido → regla del tipo) y la red de seguridad contra
  documentos duplicados concurrentes son los mismos de antes.

**Dónde se usa en el código:** `fachada.py` → `registrar_paciente()`, `importar_desde_externo()`, `_dar_de_alta()` y `_avisar_alta()` (que reemplazan
al antiguo `_validar_y_guardar()`); `app.py` y las plantillas no cambian. Ventaja práctica: cambiar una regla común del alta (p. ej. exigir un
paso más antes de guardar) se hace en **un solo lugar** y vale para todas las vías. Probar sin Flask ni base de datos: `python3 procesos_alta.py`.

## Cómo colaboran los patrones

Un flujo completo, de principio a fin, usando los veintiún patrones:

1. **Singleton** (`singleton.py`) garantiza que solo hay una conexión a la base de datos.
2. **Adapter** (`adaptadores.py`) traduce una historia que llega del sistema externo a nuestro formato estándar.
3. **Builder** (`constructor_historia.py`) arma los datos de una historia clínica nueva, paso a paso (el propio Adapter lo usa por dentro).
4. **Abstract Factory** (`fabricas.py`) valida esos datos según el tipo de atención, y luego calcula la etiqueta/color con la que se muestran.
5. **Bridge** (`notificaciones.py`) notifica al equipo clínico, combinando el tipo de notificación con el canal de envío, automáticamente si el tipo de atención lo amerita.
6. **Prototype** (`prototipos.py`) permite clonar esa historia como punto de partida de la siguiente consulta del mismo paciente.
7. **Factory Method** (`exportadores.py`) genera el PDF/TXT/CSV cuando el usuario quiere descargar cualquiera de esas historias.
8. **Composite** (`estructura_clinica.py`) organiza todas las historias en carpetas y permite aplicar los pasos 5 y 7 (notificar y exportar) a una carpeta completa con la misma llamada que se usa para una sola historia.
9. **Decorator** (`decoradores.py`) envuelve al exportador del paso 7 para anonimizar, sellar con SHA-256 y auditar (guardando en la BD del paso 1), sea una historia suelta o toda una carpeta del paso 8.
10. **Facade** (`fachada.py`) coordina todos los pasos anteriores detrás de una sola interfaz: las rutas de Flask piden «registrar este paciente» o «exportar esta carpeta» sin saber cuáles de los nueve patrones intervienen ni en qué orden.
11. **Flyweight** (`peso_ligero.py`) actúa por debajo de los pasos 4, 5 y 7: los validadores, formateadores, canales de envío y estilos del PDF que esos patrones necesitan en cada operación son siempre los mismos objetos compartidos, no copias nuevas. Ningún otro paso se entera.
12. **Proxy** (`proxies.py`) vigila los dos extremos: por delante de la fachada (paso 10) comprueba el rol de quien llama antes de dejar pasar cada operación, y por delante del sistema externo (paso 2) responde las consultas repetidas desde su caché, sin que el Adapter lo note.
13. **Iterator** (`iteradores.py`) da a todas esas colecciones un modo uniforme de recorrerse: el árbol del paso 8 (en profundidad, en anchura o solo hojas), los registros del paso 2 (uno por vez, a través del caché del paso 12) y el historial de notificaciones del paso 5 (con filtros).
14. **Mediator** (`mediador.py`) coordina las reacciones en cadena sin que los participantes se conozcan: cuando la fachada (paso 10) avisa de un alta, el mediador activa la notificación automática (paso 5) y esta, a su vez, avisa para que el historial la guarde; cuando el proxy del paso 12 niega un acceso, otro colega lo deja en la bitácora del paso 1.
15. **Memento** (`memento.py`) hace reversibles las ediciones: antes de que la fachada (paso 10) cambie una historia, el originador toma una instantánea inmutable de su estado, que el cuidador guarda sin mirar dentro; el Builder (paso 4) y el validador de la fábrica (paso 3) aplican las mismas reglas del alta, el Proxy (paso 12) decide quién puede editar o solo consultar versiones, y deshacer, rehacer o restaurar devuelven la historia a cualquiera de esos estados.
16. **Observer** (`observador.py`) avisa de los cambios a quien los sigue: cuando la fachada (paso 10) edita, deshace, rehace, restaura o cambia el estado de una historia, publica un cambio y el sujeto de esa historia lo reparte a las bandejas de sus seguidores, que el Proxy (paso 12) deja leer a todos los roles.
17. **State** (`estados.py`) gobierna el ciclo de vida de la historia: la fachada lee el estado guardado por el Singleton (paso 1), el estado decide si se puede editar (y por tanto si el Memento del paso 15 puede actuar) y a cuál pasar con cada acción, y cada transición se anuncia por el Observer del paso 16.
18. **Visitor** (`visitantes.py`) hace preguntas nuevas al árbol del paso 8 sin modificar sus nodos: la fachada (paso 10) arma el árbol con los pacientes que entrega el Singleton (paso 1) y lo recorre con tres visitantes que leen el estado del paso 17 (para contar historias por estado y descartar las cerradas de la agenda de controles) y el tipo de atención del paso 4, y el Proxy (paso 12) deja ver los reportes a todos los roles.
19. **Command** (`comandos.py`) convierte los cambios de estado del paso 17 en objetos reversibles: la fachada (paso 10) crea el comando, el State decide la transición, el Singleton (paso 1) la guarda, el historial permite deshacer y rehacer, el macro aplica una acción a toda una carpeta del Composite (paso 8) como una sola operación atómica, y cada cambio se anuncia por el Observer (paso 16).
20. **Strategy** (`estrategias.py`) decide en qué orden se muestra el listado de pacientes que la fachada (paso 10) arma con el Singleton (paso 1), el formateador del Abstract Factory (paso 4) y el estado del paso 17: el criterio es un objeto intercambiable, y el Proxy (paso 12) lo deja usar a todos los roles.
21. **Template Method** (`procesos_alta.py`) fija la secuencia de todo alta de paciente: la clase base ejecuta siempre los mismos pasos (comprobar el documento en el Singleton del paso 1, validar con el Abstract Factory del paso 4, guardar y avisar al Mediator del paso 14), y cada vía solo escribe cómo arma los datos: el formulario con el Builder (paso 3) o el sistema externo con el Adapter (paso 2, con la caché del Proxy del paso 12). La fachada (paso 10) elige la subclase.

## Siguientes pasos sugeridos

- Migrar `shce_local.db` a Postgres/MySQL cuando pase de prototipo local a producción.
- Agregar expiración de sesión y bloqueo tras N intentos fallidos.
- Ajustar la política de `PERMISOS` (`proxies.py`) a las reglas reales del hospital, y ocultar en
  las plantillas los botones que el rol no puede usar (hoy se ven y el proxy los niega con un mensaje).
- Validar el rol en el formulario de registro: hoy cualquiera puede registrarse como
  «administrador» (o con un rol inventado, que el proxy tratará como sin permisos).
- Guardar el historial de comandos en la base de datos (hoy vive en memoria) para que sobreviva a los reinicios.
- Exportar los reportes de `/reportes` (PDF o CSV) como un visitante más que escriba el archivo, reutilizando el Factory Method.
- Permitir editar o dar de baja (no borrar, por trazabilidad) una historia clínica.
- Servir la app con HTTPS y una `SECRET_KEY` real (variable de entorno) antes de exponerla fuera de tu máquina.

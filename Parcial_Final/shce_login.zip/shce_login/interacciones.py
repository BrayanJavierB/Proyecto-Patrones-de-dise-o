"""
interacciones.py
----------------
Alertas de INTERACCIONES MEDICAMENTOSAS (Objetivo 3).

Compara los medicamentos que aparecen en el TRATAMIENTO de un paciente contra una
base predefinida de interacciones (`INTERACCIONES`). Cómo funciona:

  1. Se normaliza el texto del tratamiento (minúsculas, sin tildes).
  2. Se buscan los medicamentos conocidos por su nombre o sus alias comerciales
     (`MEDICAMENTOS`), como palabras completas: «advil» cuenta como ibuprofeno.
  3. Cada par de medicamentos detectados se busca en `INTERACCIONES`.

Es una base DIDÁCTICA, no un sistema clínico: cubre pocos fármacos y no considera
dosis, vías ni la situación del paciente. Una alerta es una señal para que el
médico lo revise, nunca una orden. Un medicamento que no esté en la base no genera
alerta (que no haya alerta NO significa que no exista interacción).
"""

import re
import unicodedata

#: nombre canónico -> nombres con los que puede aparecer escrito en un tratamiento
MEDICAMENTOS = {
    "aspirina": ("aspirina", "acido acetilsalicilico", "asa"),
    "ibuprofeno": ("ibuprofeno", "advil", "motrin"),
    "warfarina": ("warfarina", "coumadin"),
    "clopidogrel": ("clopidogrel", "plavix"),
    "omeprazol": ("omeprazol", "prilosec"),
    "enalapril": ("enalapril",),
    "losartan": ("losartan", "cozaar"),
    "espironolactona": ("espironolactona", "aldactone"),
    "potasio": ("cloruro de potasio", "suplemento de potasio", "potasio"),
    "sildenafil": ("sildenafil", "viagra"),
    "nitroglicerina": ("nitroglicerina", "trinitrina"),
    "tramadol": ("tramadol",),
    "fluoxetina": ("fluoxetina", "prozac"),
    "sertralina": ("sertralina", "zoloft"),
    "simvastatina": ("simvastatina",),
    "atorvastatina": ("atorvastatina", "lipitor"),
    "claritromicina": ("claritromicina", "biaxin"),
    "amiodarona": ("amiodarona",),
    "digoxina": ("digoxina", "lanoxin"),
    "diazepam": ("diazepam", "valium"),
    "morfina": ("morfina",),
    "litio": ("litio", "carbonato de litio"),
    "metronidazol": ("metronidazol", "flagyl"),
    "ciprofloxacino": ("ciprofloxacino", "cipro"),
    "metotrexato": ("metotrexato",),
    "trimetoprima": ("trimetoprima", "trimetoprim", "cotrimoxazol"),
    "levotiroxina": ("levotiroxina", "synthroid"),
    "calcio": ("carbonato de calcio", "suplemento de calcio", "calcio"),
}

#: (medicamento A, medicamento B, gravedad, qué puede pasar, recomendación)
INTERACCIONES = [
    ("warfarina", "aspirina", "alta", "Riesgo elevado de hemorragia.", "Evitar la combinación o vigilar de cerca el INR."),
    ("warfarina", "ibuprofeno", "alta", "Mayor riesgo de sangrado digestivo y de otro tipo.", "Preferir otro analgésico (p. ej. paracetamol)."),
    ("warfarina", "metronidazol", "alta", "Potencia el efecto anticoagulante.", "Controlar el INR y ajustar la dosis."),
    ("warfarina", "ciprofloxacino", "moderada", "Puede aumentar el efecto anticoagulante.", "Controlar el INR."),
    ("aspirina", "ibuprofeno", "moderada", "El ibuprofeno puede anular la protección cardiovascular de la aspirina.", "Separar las tomas o elegir otro analgésico."),
    ("aspirina", "clopidogrel", "moderada", "Mayor riesgo de sangrado.", "Usar solo si hay indicación clara y vigilar."),
    ("clopidogrel", "omeprazol", "moderada", "El omeprazol reduce la activación del clopidogrel.", "Considerar otro protector gástrico."),
    ("enalapril", "espironolactona", "alta", "Riesgo de hiperpotasemia (potasio alto).", "Controlar el potasio y la función renal."),
    ("enalapril", "potasio", "alta", "Riesgo de hiperpotasemia (potasio alto).", "Evitar suplementos salvo control de laboratorio."),
    ("losartan", "espironolactona", "alta", "Riesgo de hiperpotasemia (potasio alto).", "Controlar el potasio y la función renal."),
    ("losartan", "potasio", "alta", "Riesgo de hiperpotasemia (potasio alto).", "Evitar suplementos salvo control de laboratorio."),
    ("enalapril", "ibuprofeno", "moderada", "Reduce el efecto antihipertensivo y puede dañar el riñón.", "Evitar uso prolongado; vigilar la función renal."),
    ("sildenafil", "nitroglicerina", "alta", "Caída grave de la presión arterial.", "Contraindicada: no usar juntos."),
    ("tramadol", "fluoxetina", "alta", "Síndrome serotoninérgico y riesgo de convulsiones.", "Evitar la combinación."),
    ("tramadol", "sertralina", "alta", "Síndrome serotoninérgico y riesgo de convulsiones.", "Evitar la combinación."),
    ("fluoxetina", "sertralina", "alta", "Exceso de serotonina (síndrome serotoninérgico).", "No combinar dos antidepresivos sin supervisión especializada."),
    ("simvastatina", "claritromicina", "alta", "Riesgo de daño muscular grave (rabdomiólisis).", "Suspender la estatina durante el antibiótico."),
    ("simvastatina", "amiodarona", "moderada", "Mayor riesgo de daño muscular.", "Limitar la dosis de simvastatina."),
    ("atorvastatina", "claritromicina", "moderada", "Mayor riesgo de daño muscular.", "Vigilar síntomas o elegir otro antibiótico."),
    ("digoxina", "amiodarona", "alta", "Aumenta los niveles de digoxina (toxicidad).", "Reducir la dosis y medir niveles."),
    ("digoxina", "claritromicina", "alta", "Aumenta los niveles de digoxina (toxicidad).", "Medir niveles o elegir otro antibiótico."),
    ("diazepam", "tramadol", "alta", "Depresión respiratoria y sedación excesiva.", "Evitar o usar la dosis mínima con vigilancia."),
    ("diazepam", "morfina", "alta", "Depresión respiratoria y sedación excesiva.", "Evitar o usar la dosis mínima con vigilancia."),
    ("litio", "ibuprofeno", "alta", "Puede elevar el litio en sangre hasta niveles tóxicos.", "Evitar AINE o medir litemia."),
    ("metotrexato", "trimetoprima", "alta", "Toxicidad grave en la médula ósea.", "Evitar la combinación."),
    ("levotiroxina", "calcio", "leve", "El calcio disminuye la absorción de la levotiroxina.", "Separar las tomas al menos 4 horas."),
]

_ORDEN_GRAVEDAD = {"alta": 0, "moderada": 1, "leve": 2}


def _normalizar(texto) -> str:
    sin_tildes = unicodedata.normalize("NFD", str(texto or "").lower())
    return "".join(c for c in sin_tildes if unicodedata.category(c) != "Mn")


def detectar_medicamentos(tratamiento) -> list:
    """Nombres canónicos de los medicamentos conocidos que aparecen en el texto del tratamiento."""
    texto = _normalizar(tratamiento)
    return sorted(
        nombre for nombre, alias in MEDICAMENTOS.items()
        if any(re.search(rf"(?<![a-z]){re.escape(a)}s?(?![a-z])", texto) for a in alias)
    )


def buscar_interacciones(tratamiento) -> list:
    """
    Interacciones entre los medicamentos del tratamiento, de más a menos grave:
    [{"medicamentos": ("warfarina", "aspirina"), "gravedad": "alta", "descripcion": ..., "recomendacion": ...}]
    """
    presentes = set(detectar_medicamentos(tratamiento))
    encontradas = [
        {"medicamentos": (a, b), "gravedad": gravedad, "descripcion": que, "recomendacion": hacer}
        for a, b, gravedad, que, hacer in INTERACCIONES if a in presentes and b in presentes
    ]
    return sorted(encontradas, key=lambda i: _ORDEN_GRAVEDAD[i["gravedad"]])


if __name__ == "__main__":
    casos = [
        "Warfarina 5 mg diaria y Advil si hay dolor",
        "Ácido acetilsalicílico + clopidogrel + omeprazol",
        "Enalapril 10 mg, cloruro de potasio y espironolactona",
        "Paracetamol 500 mg cada 8 horas",
        "Tomar aspirinas",
    ]
    for caso in casos:
        print(f"- {caso!r}")
        for i in buscar_interacciones(caso):
            print(f"    [{i['gravedad'].upper()}] {' + '.join(i['medicamentos'])}: {i['descripcion']}")
        if not buscar_interacciones(caso):
            print("    (sin interacciones conocidas)")

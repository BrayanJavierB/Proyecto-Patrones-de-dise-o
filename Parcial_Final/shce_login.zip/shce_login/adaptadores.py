"""
adaptadores.py
----------------
Implementación del patrón de diseño ADAPTER (estructural), usado para
integrar el SHCE con un "Sistema Externo de Historias" (SEH): el software
de otra institución con el que un paciente puede llegar remitido, y que
guarda sus datos con un formato completamente distinto al nuestro.

¿Por qué Adapter aquí?
----------------------
El sistema externo (SistemaExternoHistorias) no es nuestro: no podemos
(ni debemos) modificarlo para que "hable" el formato de SHCE. Su
interfaz es incompatible con la que usa el resto del proyecto:

  Campo SHCE            Campo del sistema externo
  ---------------------- --------------------------------
  nombre_completo        "nombre" + "apellido" (separados)
  documento              "id_doc"
  fecha_nacimiento       "nacimiento"      (formato DD/MM/AAAA)
  motivo_consulta        "motivo"
  diagnostico            "dx"
  tratamiento            "rx"
  notas                  "obs"
  tipo_atencion          "tipo"            (código "1"/"2"/"3")
  prioridad              "nivel_urgencia"  (letra "A"/"M"/"B")
  fecha_proximo_control  "prox_control"    (formato DD/MM/AAAA)

En vez de que las rutas de Flask aprendan ESTE formato ajeno (y lo
vuelvan a aprender cada vez que se integre un sistema externo distinto),
el Adapter traduce de un formato al otro una sola vez, exponiendo la
MISMA interfaz que ya espera el resto de SHCE.

Estructura del patrón en este archivo:
  Target (interfaz esperada)      -> FuenteHistoriaClinica.obtener_historia_estandar()
  Adaptee (interfaz incompatible) -> SistemaExternoHistorias.consultar_registro()
  Adapter (objeto adaptador)      -> AdaptadorSistemaExterno

(El patrón PROXY de proxies.py reutiliza la interfaz `RegistrosExternos`
definida aquí: un proxy y el sistema real son intercambiables para el Adapter.)
"""

from abc import ABC, abstractmethod

# Reutilizamos el patrón Builder ya existente: el Adapter no arma el
# diccionario final "a mano", se lo delega al mismo Constructor que usa
# el formulario web, así el resultado tiene EXACTAMENTE la misma forma
# sin importar de dónde vinieron los datos originales.
from constructor_historia import ConstructorHistoriaClinica


# =====================================================================
# TARGET: la interfaz que el resto de SHCE ya espera
# =====================================================================
class FuenteHistoriaClinica(ABC):
    """
    Interfaz que las rutas de Flask esperan de CUALQUIER fuente de
    historias clínicas (el formulario web, un archivo, un sistema
    externo...). Mientras algo la implemente, puede usarse de forma
    intercambiable sin que app.py necesite saber de dónde vino el dato.
    """

    @abstractmethod
    def obtener_historia_estandar(self) -> dict:
        """
        Debe devolver un diccionario con las claves estándar de SHCE
        (nombre_completo, documento, fecha_nacimiento, motivo_consulta,
        diagnostico, tratamiento, notas, tipo_atencion, prioridad,
        fecha_proximo_control) — la misma forma que entrega
        ConstructorHistoriaClinica.construir().
        """
        raise NotImplementedError


# =====================================================================
# SUJETO: lo que el Adapter (y el Proxy) esperan de un sistema externo
# =====================================================================
class RegistrosExternos(ABC):
    """
    Interfaz del sistema externo tal como lo ve SHCE: listar códigos y
    consultar un registro (en el formato crudo del tercero). La implementan
    el sistema real (SistemaExternoHistorias) y su proxy
    (ProxySistemaExterno, en proxies.py), por eso el Adapter y la fachada
    pueden usar cualquiera de los dos sin enterarse.
    """

    @abstractmethod
    def listar_codigos_disponibles(self) -> list:
        raise NotImplementedError

    @abstractmethod
    def consultar_registro(self, codigo_externo: str) -> dict:
        raise NotImplementedError


# =====================================================================
# ADAPTEE: el sistema externo, con una interfaz incompatible
# =====================================================================
class SistemaExternoHistorias(RegistrosExternos):
    """
    Simula el software de OTRA institución con la que el SHCE necesita
    integrarse (un sistema legado / de terceros). Representa código que
    no controlamos: su interfaz (consultar_registro) y su formato de
    datos son los suyos, no los de SHCE, y no se pueden cambiar.
    """

    # "Base de datos" simulada del sistema externo, con su propio formato.
    _REGISTROS = {
        "EXT-001": {
            "nombre": "Luisa", "apellido": "Cárdenas Ortiz",
            "id_doc": "1030405060", "nacimiento": "14/03/1988",
            "motivo": "Control de hipertensión",
            "dx": "Hipertensión arterial controlada",
            "rx": "Losartán 50mg cada 24h",
            "obs": "Paciente remitido de otra IPS, historial migrado.",
            "tipo": "3", "prox_control": "20/11/2026",
        },
        "EXT-002": {
            "nombre": "Miguel", "apellido": "Santos Vega",
            "id_doc": "1077889900", "nacimiento": "02/07/1979",
            "motivo": "Trauma en miembro inferior",
            "dx": "Fractura cerrada de tibia",
            "rx": "Inmovilización y analgesia",
            "obs": "Remitido desde urgencias de otra institución.",
            "tipo": "2", "nivel_urgencia": "A",
        },
        "EXT-003": {
            "nombre": "Daniela", "apellido": "Rojas Peña",
            "id_doc": "1090001122", "nacimiento": "25/12/1995",
            "motivo": "Chequeo anual",
            "dx": "Paciente sana, sin hallazgos",
            "rx": "Ninguno",
            "obs": "",
            "tipo": "1",
        },
    }

    def listar_codigos_disponibles(self) -> list:
        """Simula una consulta al sistema externo pidiendo qué historias tiene disponibles."""
        return list(self._REGISTROS.keys())

    def consultar_registro(self, codigo_externo: str) -> dict:
        """
        Método REAL del sistema externo (interfaz incompatible con SHCE):
        devuelve un diccionario con SUS propios nombres de campo, sus
        propios formatos de fecha y sus propios códigos. SHCE no puede
        usar esto directamente sin traducirlo primero.
        """
        registro = self._REGISTROS.get(codigo_externo)
        if registro is None:
            raise ValueError(f"El sistema externo no tiene el código {codigo_externo}")
        return dict(registro)  # copia, para no exponer el diccionario interno


# =====================================================================
# ADAPTER
# =====================================================================
class AdaptadorSistemaExterno(FuenteHistoriaClinica):
    """
    Envuelve un SistemaExternoHistorias (composición, no herencia) y
    expone la interfaz que SHCE necesita (FuenteHistoriaClinica),
    traduciendo por dentro cada diferencia de formato.
    """

    #: código externo -> tipo_atencion de SHCE
    _TIPOS_ATENCION = {"1": "consulta_general", "2": "urgencias", "3": "control"}

    #: letra externa -> prioridad de SHCE
    _PRIORIDADES = {"A": "alta", "M": "media", "B": "baja"}

    def __init__(self, sistema_externo: RegistrosExternos, codigo_externo: str):
        self._sistema_externo = sistema_externo
        self._codigo_externo = codigo_externo

    @staticmethod
    def _fecha_a_formato_shce(fecha_ddmmaaaa: str) -> str:
        """Convierte 'DD/MM/AAAA' (formato del sistema externo) a 'AAAA-MM-DD' (formato SHCE)."""
        if not fecha_ddmmaaaa:
            return ""
        dia, mes, anio = fecha_ddmmaaaa.split("/")
        return f"{anio}-{mes}-{dia}"

    def obtener_historia_estandar(self) -> dict:
        """
        EL MÉTODO DEL PATRÓN: llama a la interfaz incompatible del
        sistema externo (consultar_registro) y traduce su resultado al
        formato que el resto de SHCE ya entiende, delegando el armado
        final en el Builder (ConstructorHistoriaClinica).
        """
        crudo = self._sistema_externo.consultar_registro(self._codigo_externo)

        tipo_atencion = self._TIPOS_ATENCION.get(crudo.get("tipo"), "consulta_general")

        prioridad = None
        if tipo_atencion == "urgencias":
            prioridad = self._PRIORIDADES.get(crudo.get("nivel_urgencia"))

        fecha_proximo_control = None
        if tipo_atencion == "control":
            fecha_proximo_control = self._fecha_a_formato_shce(crudo.get("prox_control", "")) or None

        nombre_completo = f"{crudo.get('nombre', '')} {crudo.get('apellido', '')}".strip()

        return (
            ConstructorHistoriaClinica()
            .con_datos_personales(
                nombre_completo=nombre_completo,
                documento=crudo.get("id_doc", ""),
                fecha_nacimiento=self._fecha_a_formato_shce(crudo.get("nacimiento", "")),
            )
            .con_motivo_consulta(crudo.get("motivo", ""))
            .con_diagnostico(crudo.get("dx", ""))
            .con_tratamiento(crudo.get("rx", ""))
            .con_notas(crudo.get("obs", ""))
            .con_tipo_atencion(
                tipo_atencion,
                prioridad=prioridad,
                fecha_proximo_control=fecha_proximo_control,
            )
            .construir()
        )


if __name__ == "__main__":
    # Demostración: por cada código del sistema externo, mostramos el
    # dato CRUDO (formato ajeno) contra el dato YA ADAPTADO (formato SHCE).
    sistema_externo = SistemaExternoHistorias()

    for codigo in sistema_externo.listar_codigos_disponibles():
        crudo = sistema_externo.consultar_registro(codigo)
        adaptador = AdaptadorSistemaExterno(sistema_externo, codigo)
        adaptado = adaptador.obtener_historia_estandar()

        print(f"\n[{codigo}] CRUDO (sistema externo)  -> {crudo}")
        print(f"[{codigo}] ADAPTADO (formato SHCE)    -> {adaptado}")

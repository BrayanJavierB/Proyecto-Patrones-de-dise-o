"""
memento.py
----------
Implementación del patrón de diseño MEMENTO (comportamiento): capturar el
estado interno de un objeto en una "instantánea" para poder devolverlo a ese
estado más adelante, SIN romper su encapsulación (nadie de afuera ve ni toca
los detalles internos de la instantánea).

¿Por qué Memento aquí?
----------------------
Hasta ahora las historias clínicas solo se podían CREAR: una vez guardadas, no
había forma de corregirlas. Pero un sistema clínico que permite editar tiene
que permitir también equivocarse: un diagnóstico mal escrito, un tratamiento
cambiado por error, una edición hecha en la historia equivocada. Sin red de
seguridad, un error es un dato perdido.

Con Memento, antes de cada cambio se toma una instantánea del estado anterior.
Con esas instantáneas se puede DESHACER la última edición, REHACERLA, o
RESTAURAR cualquier versión anterior, sin que la lógica de edición tenga que
saber cómo se guarda ni se compara cada versión.

Estructura del patrón en este archivo:
  Originator  -> HistoriaClinicaEditable: el objeto cuyo estado se captura.
                 Es el ÚNICO que sabe crear instantáneas y restaurarse desde ellas.
  Memento     -> MementoHistoria: la instantánea. Es inmutable. Hacia afuera solo
                 muestra metadatos (quién, cuándo, por qué, un resumen); su
                 contenido solo lo puede leer el originador al que pertenece.
  Caretaker   -> HistorialVersiones: guarda y entrega instantáneas (pilas de
                 deshacer/rehacer por paciente). NUNCA mira dentro de ellas.
  Cliente     -> la fachada (fachada.py), que coordina originador y cuidador.

El recorrido de una edición con deshacer:

    editar:    foto(estado actual) ──▶ cuidador.guardar   ;  originador cambia ;  BD se actualiza
    deshacer:  foto(estado actual) ──▶ cuidador.deshacer ──▶ devuelve la foto previa
               originador.restaurar(foto previa)  ;  BD se actualiza
               (la foto del estado "deshecho" queda en la pila de rehacer)

Decisiones de diseño:
  - ENCAPSULACIÓN: el cuidador solo ve la interfaz "angosta" del memento (autor,
    motivo, momento, resumen). El estado vive en un atributo privado del memento
    y solo se entrega a un originador que sea de la MISMA historia: restaurar la
    instantánea del paciente 3 en el paciente 5 lanza ValueError.
    (Python no tiene "friend" ni privado real: es protección por convención y
    por verificación, suficiente para evitar errores, no para detener a alguien
    que decida saltársela a propósito.)
  - INMUTABILIDAD: el memento copia el estado al crearse (copia profunda) y lo
    guarda en un MappingProxyType de solo lectura; además prohíbe asignar
    atributos. Cambiar la historia después NO altera instantáneas ya tomadas.
  - LA IDENTIDAD NO SE EDITA: nombre, documento y fecha de nacimiento identifican
    al paciente y no forman parte del estado que se captura. Solo se versionan los
    campos clínicos (CAMPOS_CLINICOS).
  - REDO SE INVALIDA CON UN CAMBIO NUEVO: si se deshace y luego se edita de nuevo,
    el "futuro" que quedaba para rehacer se descarta (como en cualquier editor).
  - RESTAURAR NO BORRA HISTORIA: restaurar una versión toma una foto del estado
    actual antes de volver, así que la restauración misma también se puede deshacer
    y nada se pierde.
  - LÍMITE: cada paciente conserva como máximo `limite` versiones (las más recientes)
    para que la memoria no crezca sin fin.
  - EN MEMORIA: igual que el historial de notificaciones, el historial de versiones
    vive en la memoria del servidor y se reinicia con él. Guardarlo en la base de datos
    exigiría serializar las instantáneas (p. ej. a JSON) y una tabla nueva; no se hizo
    aquí para no cambiar el esquema de tu base de datos.
  - CONCURRENCIA: el cuidador protege sus pilas con un cerrojo (el servidor de Flask
    puede atender varias peticiones a la vez).
"""

import copy
import threading
from datetime import datetime
from types import MappingProxyType

from fabricas import TIPOS_ATENCION    # para mostrar el tipo de atención con su nombre legible

# Los únicos campos que se editan y se versionan. La identidad del paciente queda fuera.
CAMPOS_CLINICOS = (
    "motivo_consulta", "diagnostico", "tratamiento", "notas",
    "tipo_atencion", "prioridad", "fecha_proximo_control",
)


# =====================================================================
# EL MEMENTO: la instantánea inmutable
# =====================================================================
class MementoHistoria:
    """
    Instantánea del estado clínico de UNA historia en un momento dado.

    Interfaz "angosta" (lo que ve el cuidador y la interfaz de usuario):
    `autor`, `motivo`, `momento` y `resumen`.
    Interfaz "ancha" (solo para el originador): `_leer_estado`.

    No se construye directamente: la crea `HistoriaClinicaEditable.crear_memento`.
    """

    __slots__ = ("_paciente_id", "_estado", "_autor", "_motivo", "_momento", "_resumen")

    def __init__(self, paciente_id, estado: dict, autor: str, motivo: str, resumen: str):
        object.__setattr__(self, "_paciente_id", paciente_id)
        object.__setattr__(self, "_estado", MappingProxyType(copy.deepcopy(dict(estado))))
        object.__setattr__(self, "_autor", autor)
        object.__setattr__(self, "_motivo", motivo)
        object.__setattr__(self, "_momento", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        object.__setattr__(self, "_resumen", resumen)

    def __setattr__(self, nombre, valor):
        raise AttributeError("Un memento es inmutable: no se puede modificar una instantánea ya tomada.")

    def __delattr__(self, nombre):
        raise AttributeError("Un memento es inmutable: no se puede modificar una instantánea ya tomada.")

    # ---- interfaz angosta ----
    @property
    def autor(self) -> str:
        return self._autor

    @property
    def motivo(self) -> str:
        return self._motivo

    @property
    def momento(self) -> str:
        return self._momento

    @property
    def resumen(self) -> str:
        return self._resumen

    # ---- interfaz ancha: solo para el originador de ESTA historia ----
    def _leer_estado(self, originador) -> dict:
        if not isinstance(originador, HistoriaClinicaEditable) or originador.paciente_id != self._paciente_id:
            raise ValueError("Esta instantánea no pertenece a esta historia clínica.")
        return copy.deepcopy(dict(self._estado))


# =====================================================================
# EL ORIGINADOR: la historia que se puede editar y restaurar
# =====================================================================
class HistoriaClinicaEditable:
    """
    La parte editable de la historia de un paciente. Sabe tomarse una instantánea
    de sí misma (`crear_memento`) y volver a un estado anterior (`restaurar`).
    No sabe dónde se guardan las instantáneas ni cuántas hay.
    """

    def __init__(self, paciente: dict):
        self._id = paciente["id"]
        self._identidad = {c: paciente.get(c) for c in ("nombre_completo", "documento", "fecha_nacimiento")}
        self._clinicos = {c: paciente.get(c) for c in CAMPOS_CLINICOS}

    @property
    def paciente_id(self):
        return self._id

    @property
    def identidad(self) -> dict:
        """Nombre, documento y fecha de nacimiento: solo lectura, no se versionan."""
        return dict(self._identidad)

    @property
    def datos_clinicos(self) -> dict:
        """Copia de los campos clínicos actuales."""
        return dict(self._clinicos)

    def establecer(self, datos: dict) -> None:
        """Aplica nuevos valores a campos clínicos. Rechaza cualquier campo que no lo sea."""
        desconocidos = set(datos) - set(CAMPOS_CLINICOS)
        if desconocidos:
            raise ValueError(f"Campos no editables: {sorted(desconocidos)}. Solo se editan {list(CAMPOS_CLINICOS)}.")
        self._clinicos.update(datos)

    def crear_memento(self, autor: str, motivo: str) -> MementoHistoria:
        """Toma una instantánea del estado clínico ACTUAL."""
        return MementoHistoria(self._id, self._clinicos, autor, motivo, self._resumen())

    def restaurar(self, memento: MementoHistoria) -> None:
        """Vuelve al estado de la instantánea. Falla si pertenece a otra historia."""
        self._clinicos = memento._leer_estado(self)

    def _resumen(self) -> str:
        etiqueta = dict(TIPOS_ATENCION).get(self._clinicos.get("tipo_atencion"), self._clinicos.get("tipo_atencion"))
        diagnostico = (self._clinicos.get("diagnostico") or "").strip()
        if len(diagnostico) > 40:
            diagnostico = diagnostico[:37] + "…"
        return f"{etiqueta} · Diagnóstico: {diagnostico or 'sin especificar'}"


# =====================================================================
# EL CUIDADOR: guarda las instantáneas sin mirar dentro
# =====================================================================
class HistorialVersiones:
    """
    Guarda, por paciente, la pila de instantáneas para DESHACER y la de REHACER.
    Cada instantánea recibe un número de versión estable (v1, v2...) por paciente.
    Solo usa la interfaz angosta de los mementos: jamás lee su estado.
    """

    def __init__(self, limite: int = 20):
        self._limite = limite
        self._pilas = {}        # paciente_id -> {"deshacer": [(version, memento)], "rehacer": [...]}
        self._contador = {}     # paciente_id -> último número de versión asignado
        self._cerrojo = threading.RLock()

    def guardar(self, paciente_id, memento: MementoHistoria) -> None:
        """Registra la instantánea de un estado ANTERIOR a un cambio nuevo. Descarta el rehacer."""
        with self._cerrojo:
            pilas = self._pilas_de(paciente_id)
            pilas["deshacer"].append((self._numerar(paciente_id), memento))
            pilas["rehacer"].clear()
            del pilas["deshacer"][:-self._limite]

    def deshacer(self, paciente_id, actual: MementoHistoria):
        """
        Entrega la instantánea previa más reciente (o None si no hay) y guarda
        `actual` —el estado que se abandona— en la pila de rehacer.
        """
        with self._cerrojo:
            pilas = self._pilas_de(paciente_id)
            if not pilas["deshacer"]:
                return None
            _version, previo = pilas["deshacer"].pop()
            pilas["rehacer"].append((self._numerar(paciente_id), actual))
            return previo

    def rehacer(self, paciente_id, actual: MementoHistoria):
        """Contraparte de `deshacer`: entrega el estado deshecho (o None) y guarda `actual` para deshacer."""
        with self._cerrojo:
            pilas = self._pilas_de(paciente_id)
            if not pilas["rehacer"]:
                return None
            _version, siguiente = pilas["rehacer"].pop()
            pilas["deshacer"].append((self._numerar(paciente_id), actual))
            del pilas["deshacer"][:-self._limite]
            return siguiente

    def buscar(self, paciente_id, version: int):
        """La instantánea de una versión concreta de la pila de deshacer, o None."""
        with self._cerrojo:
            for numero, memento in self._pilas_de(paciente_id)["deshacer"]:
                if numero == version:
                    return memento
            return None

    def versiones(self, paciente_id) -> list:
        """Las versiones disponibles, la más reciente primero, solo con metadatos."""
        with self._cerrojo:
            return [
                {"version": numero, "autor": m.autor, "motivo": m.motivo, "momento": m.momento, "resumen": m.resumen}
                for numero, m in reversed(self._pilas_de(paciente_id)["deshacer"])
            ]

    def puede_deshacer(self, paciente_id) -> bool:
        with self._cerrojo:
            return bool(self._pilas_de(paciente_id)["deshacer"])

    def puede_rehacer(self, paciente_id) -> bool:
        with self._cerrojo:
            return bool(self._pilas_de(paciente_id)["rehacer"])

    def _pilas_de(self, paciente_id) -> dict:
        return self._pilas.setdefault(paciente_id, {"deshacer": [], "rehacer": []})

    def _numerar(self, paciente_id) -> int:
        self._contador[paciente_id] = self._contador.get(paciente_id, 0) + 1
        return self._contador[paciente_id]


if __name__ == "__main__":
    # Demostración sin Flask ni base de datos.
    paciente = {"id": 7, "nombre_completo": "Ana Ruiz", "documento": "1001", "fecha_nacimiento": "1990-01-01",
                "motivo_consulta": "Tos", "diagnostico": "Resfriado común", "tratamiento": "Reposo",
                "notas": "", "tipo_atencion": "consulta_general", "prioridad": None, "fecha_proximo_control": None}
    historia, cuidador = HistoriaClinicaEditable(paciente), HistorialVersiones()
    ver = lambda: print("   diagnóstico:", historia.datos_clinicos["diagnostico"], "|", historia.datos_clinicos["tratamiento"])

    print("1) Estado inicial"); ver()
    for dx, tx in (("Bronquitis", "Antibiótico"), ("Neumonía", "Hospitalización")):
        cuidador.guardar(7, historia.crear_memento("dra.lopez", "Antes de la edición"))
        historia.establecer({"diagnostico": dx, "tratamiento": tx})
    print("2) Dos ediciones hechas"); ver()
    print("   Versiones guardadas:", [(v["version"], v["resumen"]) for v in cuidador.versiones(7)])

    historia.restaurar(cuidador.deshacer(7, historia.crear_memento("dra.lopez", "Antes de deshacer")))
    print("3) Deshacer una vez"); ver()
    historia.restaurar(cuidador.rehacer(7, historia.crear_memento("dra.lopez", "Antes de rehacer")))
    print("4) Rehacer"); ver()

    historia.restaurar(cuidador.buscar(7, 1))
    print("5) Restaurar la versión 1 (la original)"); ver()

    foto = historia.crear_memento("x", "prueba")
    print("6) El memento es inmutable y está encapsulado:")
    for intento in (lambda: setattr(foto, "autor", "otro"), lambda: foto._leer_estado(HistoriaClinicaEditable({**paciente, "id": 8}))):
        try:
            intento()
        except (AttributeError, ValueError) as error:
            print("   ", type(error).__name__ + ":", str(error))

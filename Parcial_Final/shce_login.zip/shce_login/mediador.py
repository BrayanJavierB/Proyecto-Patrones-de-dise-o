"""
mediador.py
-----------
Implementación del patrón de diseño MEDIATOR (comportamiento): un objeto
central que coordina la comunicación entre varios objetos ("colegas"), de
modo que ninguno de ellos tenga que conocer a los demás.

¿Por qué Mediator aquí?
-----------------------
Cuando ocurre algo en el SHCE, suele haber varias reacciones en cadena:

  - Se registra un paciente de Urgencias o de Control  ->  hay que enviarle
    una notificación automática  ->  y esa notificación debe quedar anotada
    en el historial.
  - El proxy de protección niega un acceso  ->  hay que dejarlo en la bitácora
    de denegaciones.

Antes, la fachada cablea esas reacciones a mano: llamaba directamente al
código de la notificación automática, que a su vez escribía directamente en
la lista del historial (una lista que se manipulaba desde TRES sitios
distintos), y reenviaba la denegación directamente a la base de datos. Cada
nueva reacción ("¿y si además avisamos al médico?") obligaba a editar a
quien origina el hecho, y todos conocían los detalles de todos.

Con Mediator, quien origina un hecho solo AVISA de que ocurrió:

    mediador.notificar(self, Evento.PACIENTE_REGISTRADO, paciente=datos)

y es el mediador quien decide qué colegas deben enterarse. Los colegas no se
conocen entre sí: solo conocen al mediador. Agregar una reacción nueva es
escribir un colega nuevo y suscribirlo a un evento; no se toca a nadie más.

Estructura del patrón en este archivo:
  Mediator (interfaz)     -> Mediador
  ConcreteMediator        -> MediadorClinico (tabla evento -> colegas suscritos)
  Colleague (base)        -> Colega
  ConcreteColleague       -> NotificadorAutomatico, HistorialNotificaciones,
                             AuditoriaDenegaciones
  Cliente / emisor        -> la fachada (fachada.py), que arma el mediador y
                             avisa de los hechos; también lo hacen los propios
                             colegas (el notificador avisa de cada envío)

El recorrido de un alta de Urgencias, paso a paso:

    fachada ──(paciente_registrado)──▶ MEDIADOR ──▶ NotificadorAutomatico
                                          ▲                    │ arma la notificación (Bridge)
                                          │                    ▼
                                          └──(notificacion_enviada)──┘
                                          │
                                          └──▶ HistorialNotificaciones (la guarda)

Observa que NotificadorAutomatico no sabe que existe un historial, y el
historial no sabe que existe el notificador: solo comparten el evento.

Decisiones de diseño:
  - EVENTOS CON NOMBRE, VALIDADOS: los eventos son constantes de `Evento`.
    Avisar de un evento que no existe lanza ValueError: un error de escritura
    ("paciente_registrdo") falla de inmediato en lugar de no hacer nada en
    silencio.
  - EL EMISOR NO SE ENTERA DE SU PROPIO AVISO: el mediador no le devuelve el
    evento a quien lo originó, así que un colega puede reaccionar a un evento y
    emitir otro distinto sin riesgo de bucles consigo mismo.
  - ORDEN PREDECIBLE: los colegas reciben cada evento en el orden en que se
    suscribieron.
  - LOS ERRORES SE PROPAGAN: si un colega falla, la excepción llega a quien
    avisó. El mediador coordina, no oculta problemas.
  - RASTRO DE EVENTOS: el mediador guarda los últimos eventos procesados
    (`eventos_recientes()`), útil para entender y depurar la cadena de reacciones.
  - Los datos viajan como argumentos con nombre (`paciente=...`, `resultado=...`).
    El nombre `evento` está reservado para el tipo de evento, por eso la
    denegación viaja como `intento=...`.
"""

from abc import ABC, abstractmethod
from collections import deque

from iteradores import IteradorHistorial          # Iterator: el historial se recorre con filtros
from notificaciones import construir_notificacion  # Bridge: tipo de notificación x canal


# =====================================================================
# LOS EVENTOS que circulan por el mediador
# =====================================================================
class Evento:
    """Catálogo de eventos. Se usan siempre por su constante, nunca como texto suelto."""

    PACIENTE_REGISTRADO = "paciente_registrado"      # datos: paciente (dict con la historia guardada)
    NOTIFICACION_ENVIADA = "notificacion_enviada"    # datos: resultado (dict del envío, ya con paciente_nombre)
    ACCESO_DENEGADO = "acceso_denegado"              # datos: intento (dict: usuario, rol, operacion, motivo)

    TODOS = frozenset({PACIENTE_REGISTRADO, NOTIFICACION_ENVIADA, ACCESO_DENEGADO})


# =====================================================================
# INTERFAZ DEL MEDIADOR
# =====================================================================
class Mediador(ABC):
    """Contrato que ven los colegas: solo saben avisar al mediador de que algo ocurrió."""

    @abstractmethod
    def notificar(self, emisor, evento: str, **datos) -> None:
        """`emisor` avisa de que ocurrió `evento`, acompañado de `datos`."""
        raise NotImplementedError


# =====================================================================
# LOS COLEGAS
# =====================================================================
class Colega:
    """
    Base de los colegas. Un colega solo conoce a su mediador: no guarda
    referencias a ningún otro colega.
      - `recibir` es lo que el mediador invoca cuando ocurre un evento al
        que el colega está suscrito.
      - `_avisar` es lo que el colega usa para comunicar un hecho propio.
    """

    def __init__(self):
        self._mediador = None

    def asignar_mediador(self, mediador: Mediador) -> None:
        self._mediador = mediador

    def recibir(self, evento: str, **datos) -> None:
        """Reacciona a un evento. Cada colega concreto sobrescribe este método."""
        raise NotImplementedError

    def _avisar(self, evento: str, **datos) -> None:
        if self._mediador is None:
            raise RuntimeError(
                f"{type(self).__name__} no tiene mediador: regístralo antes con MediadorClinico.registrar()."
            )
        self._mediador.notificar(self, evento, **datos)


class NotificadorAutomatico(Colega):
    """
    Reacciona a PACIENTE_REGISTRADO: si el paciente es de Urgencias o de
    Control, arma la notificación correspondiente (Bridge, canal "consola") y
    AVISA de que fue enviada. Para "consulta_general" no hace nada: no es un
    caso urgente ni programado. No sabe qué se hace después con el envío.
    """

    _TIPO_POR_ATENCION = {"urgencias": "urgencia", "control": "control"}

    def recibir(self, evento: str, **datos) -> None:
        if evento != Evento.PACIENTE_REGISTRADO:
            return
        paciente = datos["paciente"]
        tipo = self._TIPO_POR_ATENCION.get(paciente.get("tipo_atencion"))
        if tipo is None:
            return

        resultado = construir_notificacion(tipo, "consola").enviar_para(paciente)
        resultado["paciente_nombre"] = paciente.get("nombre_completo", "")
        self._avisar(Evento.NOTIFICACION_ENVIADA, resultado=resultado)


class HistorialNotificaciones(Colega):
    """
    Reacciona a NOTIFICACION_ENVIADA guardando el envío (el más reciente
    primero). Es la ÚNICA puerta de entrada al historial: ya no hay otros
    sitios que lo modifiquen. Vive en memoria, por lo que se reinicia con el servidor.
    """

    def __init__(self):
        super().__init__()
        self._envios = []

    def recibir(self, evento: str, **datos) -> None:
        if evento == Evento.NOTIFICACION_ENVIADA:
            self._envios.insert(0, datos["resultado"])

    def ultimos(self, limite: int = 10, tipo_notificacion: str = None,
                canal: str = None, paciente: str = None) -> list:
        """Los últimos envíos que cumplan los filtros (Iterator: IteradorHistorial)."""
        return list(IteradorHistorial(self._envios, tipo_notificacion, canal, paciente, limite))


class AuditoriaDenegaciones(Colega):
    """
    Reacciona a ACCESO_DENEGADO dejando el intento en la bitácora de
    denegaciones de la base de datos (Singleton). Quien deniega el acceso (el
    proxy de protección) no sabe dónde ni cómo se guarda.
    """

    def __init__(self, db):
        super().__init__()
        self._db = db

    def recibir(self, evento: str, **datos) -> None:
        if evento == Evento.ACCESO_DENEGADO:
            self._db.registrar_denegacion(datos["intento"])


# =====================================================================
# EL MEDIADOR CONCRETO
# =====================================================================
class MediadorClinico(Mediador):
    """
    Guarda quién está suscrito a qué evento y reparte cada aviso solo a los
    colegas interesados, en orden de suscripción.
    """

    def __init__(self, memoria_eventos: int = 50):
        self._suscritos = {evento: [] for evento in Evento.TODOS}
        self._rastro = deque(maxlen=memoria_eventos)

    def registrar(self, colega: Colega, *eventos: str) -> Colega:
        """
        Conecta al colega con el mediador y lo suscribe a los eventos dados.
        Devuelve el colega para poder encadenar.
        """
        colega.asignar_mediador(self)
        for evento in eventos:
            self._exigir_evento_valido(evento)
            if colega not in self._suscritos[evento]:
                self._suscritos[evento].append(colega)
        return colega

    def notificar(self, emisor, evento: str, **datos) -> None:
        self._exigir_evento_valido(evento)
        destinatarios = [c for c in self._suscritos[evento] if c is not emisor]
        self._rastro.append((evento, type(emisor).__name__, [type(c).__name__ for c in destinatarios]))
        for colega in destinatarios:
            colega.recibir(evento, **datos)

    def eventos_recientes(self) -> list:
        """Los últimos eventos procesados, del más antiguo al más reciente: (evento, emisor, [receptores])."""
        return list(self._rastro)

    @staticmethod
    def _exigir_evento_valido(evento: str) -> None:
        if evento not in Evento.TODOS:
            raise ValueError(f"Evento desconocido: {evento!r}. Usa una constante de Evento: {sorted(Evento.TODOS)}.")


if __name__ == "__main__":
    # Demostración sin Flask y sin base de datos real.
    class BDDeMentira:
        def registrar_denegacion(self, intento):
            print("   [bitácora] guardado:", intento)

    mediador = MediadorClinico()
    historial = HistorialNotificaciones()
    mediador.registrar(historial, Evento.NOTIFICACION_ENVIADA)
    mediador.registrar(NotificadorAutomatico(), Evento.PACIENTE_REGISTRADO)
    mediador.registrar(AuditoriaDenegaciones(BDDeMentira()), Evento.ACCESO_DENEGADO)

    class Fachada:   # un emisor cualquiera
        pass

    fachada = Fachada()
    ana = {"nombre_completo": "Ana Ruiz", "documento": "1", "tipo_atencion": "urgencias", "prioridad": "alta"}
    luis = {"nombre_completo": "Luis Gómez", "documento": "2", "tipo_atencion": "consulta_general"}

    print("1) Se registra una URGENCIA: el mediador activa al notificador, que avisa del envío")
    mediador.notificar(fachada, Evento.PACIENTE_REGISTRADO, paciente=ana)
    print("   Historial:", [(e["tipo_notificacion"], e["paciente_nombre"]) for e in historial.ultimos()])

    print("2) Se registra una CONSULTA GENERAL: no se notifica nada")
    mediador.notificar(fachada, Evento.PACIENTE_REGISTRADO, paciente=luis)
    print("   Historial:", len(historial.ultimos()), "envío(s)")

    print("3) El proxy deniega un acceso: la auditoría lo guarda, sin que el proxy sepa cómo")
    mediador.notificar(fachada, Evento.ACCESO_DENEGADO,
                       intento={"usuario": "enf1", "rol": "enfermeria", "operacion": "registrar_paciente", "motivo": "rol"})

    print("4) Rastro del mediador (evento <- emisor, receptores):")
    for evento, emisor, receptores in mediador.eventos_recientes():
        print(f"   {evento:<22} <- {emisor:<22} -> {receptores}")

    print("5) Un evento mal escrito falla de inmediato:")
    try:
        mediador.notificar(fachada, "paciente_registrdo")
    except ValueError as error:
        print("   ValueError:", str(error)[:60] + "...")

"""
notificaciones.py
-------------------
Implementación del patrón de diseño BRIDGE (estructural), usado para
desacoplar el TIPO de notificación clínica (urgencia, recordatorio de
control, informativa...) del CANAL por el que se envía (consola/log,
email simulado, SMS simulado).

¿Por qué Bridge aquí?
----------------------
Sin Bridge, cada combinación de "tipo de notificación" x "canal de
envío" terminaría siendo una clase propia: NotificacionUrgenciaEmail,
NotificacionUrgenciaSMS, NotificacionControlEmail... Con 3 tipos y 3
canales ya serían 9 clases, y cada tipo o canal nuevo multiplicaría el
problema (explosión combinatoria de subclases).

Bridge separa las dos dimensiones en DOS jerarquías independientes,
conectadas por COMPOSICIÓN (un "puente"), no por herencia:

  Abstracción (QUÉ se notifica)        Implementador (CÓMO se envía)
  ------------------------------------ ----------------------------------
  Notificacion (abstracta)              CanalEnvio (abstracto)
    NotificacionUrgencia                  CanalConsola
    NotificacionControlProximo            CanalEmailSimulado
    NotificacionInformativa               CanalSMSSimulado

Cualquier tipo de notificación puede combinarse con cualquier canal en
tiempo de ejecución (3 tipos + 3 canales = 6 clases, no 3 x 3 = 9), y
agregar un tipo o un canal nuevo no toca el otro lado del puente.

Nota: este prototipo funciona 100% local, así que los canales de
email/SMS SIMULAN el envío (arman el mensaje final y lo devuelven en
vez de conectarse a un servidor SMTP o una pasarela SMS real).

Estructura del patrón en este archivo:
  Implementador (interfaz)  -> CanalEnvio
  Implementadores concretos -> CanalConsola, CanalEmailSimulado, CanalSMSSimulado
  Abstracción               -> Notificacion
  Abstracciones refinadas   -> NotificacionUrgencia, NotificacionControlProximo, NotificacionInformativa

Colaboración con FLYWEIGHT (peso_ligero.py)
-------------------------------------------
Los canales de envío (el lado "implementador" del puente) no guardan ningún
estado: el destinatario, el asunto y el cuerpo llegan por parámetro en cada
`enviar(...)`. Son, por tanto, PESOS LIGEROS: en vez de instanciar un canal
nuevo por cada notificación (notificar una carpeta de 200 historias creaba 200
canales idénticos), `construir_notificacion` los pide al pool y todas las
notificaciones comparten el mismo `CanalSMSSimulado`, `CanalEmailSimulado` o
`CanalConsola`. El puente no cambia: la abstracción sigue guardando una
referencia a «un canal»; ahora esa referencia apunta al mismo objeto para todas.
La abstracción (`Notificacion`) NO se comparte a propósito: es la parte que
más probablemente gane estado propio (p. ej. un usuario o una plantilla).
"""

from abc import ABC, abstractmethod
from datetime import datetime

from peso_ligero import PesoLigero, PESOS_LIGEROS


# =====================================================================
# IMPLEMENTADOR: el "cómo se envía"
# =====================================================================
class CanalEnvio(PesoLigero, ABC):
    """
    Interfaz que debe cumplir cualquier canal de envío. La Abstracción
    (Notificacion) solo conoce ESTA interfaz — nunca los detalles de
    cada canal concreto.

    Peso ligero: un canal no tiene estado intrínseco más allá de su nombre y
    su formato (iguales para todos); el destinatario y el mensaje son estado
    extrínseco y entran por parámetro en `enviar`. Por eso una sola instancia
    por canal sirve a todas las notificaciones.
    """

    #: nombre legible del canal, usado en la interfaz web
    nombre_canal: str = "Canal genérico"

    @abstractmethod
    def enviar(self, destinatario: str, asunto: str, cuerpo: str) -> dict:
        """
        Entrega el mensaje ya armado (asunto + cuerpo) por este canal.
        Devuelve un resultado con el mensaje final tal como quedó
        formateado para ESTE canal en particular.
        """
        raise NotImplementedError


class CanalConsola(CanalEnvio):
    """Simula escribir la notificación en la consola/log interno del sistema."""

    nombre_canal = "Consola / log interno"

    def enviar(self, destinatario: str, asunto: str, cuerpo: str) -> dict:
        mensaje = f"[LOG SHCE] Para: {destinatario} · {asunto}\n{cuerpo}"
        return {"canal": self.nombre_canal, "destino": destinatario, "mensaje_final": mensaje}


class CanalEmailSimulado(CanalEnvio):
    """Simula el armado de un correo, sin conectarse a un servidor SMTP real."""

    nombre_canal = "Email (simulado)"

    def enviar(self, destinatario: str, asunto: str, cuerpo: str) -> dict:
        mensaje = (
            f"De: shce-notificaciones@local\n"
            f"Para: {destinatario}\n"
            f"Asunto: {asunto}\n\n"
            f"{cuerpo}"
        )
        return {"canal": self.nombre_canal, "destino": destinatario, "mensaje_final": mensaje}


class CanalSMSSimulado(CanalEnvio):
    """Simula un SMS: mensaje corto, sin saltos de línea, truncado a 160 caracteres."""

    nombre_canal = "SMS (simulado)"

    def enviar(self, destinatario: str, asunto: str, cuerpo: str) -> dict:
        texto = f"{asunto}: {cuerpo}".replace("\n", " ")
        texto_sms = (texto[:157] + "...") if len(texto) > 160 else texto
        return {"canal": self.nombre_canal, "destino": destinatario, "mensaje_final": texto_sms}


# =====================================================================
# ABSTRACCIÓN: el "qué se notifica"
# =====================================================================
class Notificacion(ABC):
    """
    Abstracción del patrón Bridge. Guarda una REFERENCIA a un CanalEnvio
    (composición — este es "el puente") en vez de heredar de una clase
    por cada canal, así el TIPO de notificación y el CANAL pueden
    cambiar de forma completamente independiente.
    """

    def __init__(self, canal: CanalEnvio):
        self._canal = canal

    @abstractmethod
    def _construir_asunto(self, paciente: dict) -> str:
        raise NotImplementedError

    @abstractmethod
    def _construir_cuerpo(self, paciente: dict) -> str:
        raise NotImplementedError

    def enviar_para(self, paciente: dict) -> dict:
        """
        EL PUENTE EN ACCIÓN: esta clase arma el CONTENIDO (asunto +
        cuerpo) según el tipo de notificación, y delega el ENVÍO en sí
        al canal (self._canal.enviar(...)) — sin que ninguno de los dos
        lados necesite conocer los detalles del otro.
        """
        asunto = self._construir_asunto(paciente)
        cuerpo = self._construir_cuerpo(paciente)
        destinatario = f"equipo clínico (vía {paciente.get('registrado_por', 'personal')})"

        resultado = self._canal.enviar(destinatario, asunto, cuerpo)
        resultado["tipo_notificacion"] = getattr(self, "etiqueta_tipo", type(self).__name__)
        resultado["asunto"] = asunto
        resultado["cuerpo"] = cuerpo
        resultado["enviado_en"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return resultado


class NotificacionUrgencia(Notificacion):
    """Notificación disparada cuando se registra un paciente de Urgencias."""

    #: nombre legible, usado en la interfaz web (mismo estilo que color_css en fabricas.py)
    etiqueta_tipo = "Urgencia"

    def _construir_asunto(self, paciente: dict) -> str:
        return f"Urgencia registrada: {paciente.get('nombre_completo', '')}"

    def _construir_cuerpo(self, paciente: dict) -> str:
        prioridad = paciente.get("prioridad") or "sin definir"
        return (
            f"Paciente: {paciente.get('nombre_completo', '')} "
            f"(doc. {paciente.get('documento', '')})\n"
            f"Prioridad: {prioridad}\n"
            f"Motivo: {paciente.get('motivo_consulta') or 'no especificado'}"
        )


class NotificacionControlProximo(Notificacion):
    """Notificación recordatoria de la próxima fecha de control de un paciente."""

    etiqueta_tipo = "Recordatorio de control"

    def _construir_asunto(self, paciente: dict) -> str:
        return f"Recordatorio de control: {paciente.get('nombre_completo', '')}"

    def _construir_cuerpo(self, paciente: dict) -> str:
        fecha = paciente.get("fecha_proximo_control") or "sin programar"
        return (
            f"Paciente: {paciente.get('nombre_completo', '')} "
            f"(doc. {paciente.get('documento', '')})\n"
            f"Próximo control: {fecha}\n"
            f"Diagnóstico: {paciente.get('diagnostico') or 'no especificado'}"
        )


class NotificacionInformativa(Notificacion):
    """Notificación genérica, ej. confirmación de que se registró una historia clínica."""

    etiqueta_tipo = "Informativa"

    def _construir_asunto(self, paciente: dict) -> str:
        return f"Historia clínica registrada: {paciente.get('nombre_completo', '')}"

    def _construir_cuerpo(self, paciente: dict) -> str:
        return (
            f"Se registró una historia clínica para "
            f"{paciente.get('nombre_completo', '')} (doc. {paciente.get('documento', '')}).\n"
            f"Motivo: {paciente.get('motivo_consulta') or 'no especificado'}"
        )


# ---------------------------------------------------------------------
# Puntos de entrada cómodos (igual que obtener_creador/obtener_fabrica en
# los otros archivos): traducen los strings que llegan del formulario
# web a la clase concreta correspondiente. Esto NO es el patrón en sí,
# es solo el punto de entrada para que app.py no tenga que hacer if/elif.
# ---------------------------------------------------------------------
_TIPOS_NOTIFICACION = {
    "urgencia": NotificacionUrgencia,
    "control": NotificacionControlProximo,
    "informativa": NotificacionInformativa,
}

_CANALES_ENVIO = {
    "consola": CanalConsola,
    "email": CanalEmailSimulado,
    "sms": CanalSMSSimulado,
}

#: Para poblar los <select> del formulario, en el orden en que deben mostrarse.
TIPOS_NOTIFICACION_OPCIONES = [
    ("urgencia", "Urgencia"),
    ("control", "Recordatorio de control"),
    ("informativa", "Informativa"),
]
CANALES_ENVIO_OPCIONES = [
    ("consola", "Consola / log interno"),
    ("email", "Email (simulado)"),
    ("sms", "SMS (simulado)"),
]


def construir_notificacion(tipo: str, canal: str) -> Notificacion:
    """
    Arma el puente: crea la Abstracción concreta pedida (tipo) y la
    conecta con el Implementador concreto pedido (canal). Cualquiera de
    las 3 x 3 combinaciones es válida sin necesitar una clase nueva.
    """
    clase_notificacion = _TIPOS_NOTIFICACION.get(tipo, NotificacionInformativa)

    # Flyweight: el canal se pide al pool (siempre la misma instancia por
    # canal). La clave se normaliza antes: un canal inventado cae en "consola"
    # y no puede agregar entradas nuevas al pool.
    clave_canal = canal if canal in _CANALES_ENVIO else "consola"
    canal_compartido = PESOS_LIGEROS.obtener("canal_envio", clave_canal, _CANALES_ENVIO[clave_canal])
    return clase_notificacion(canal_compartido)


if __name__ == "__main__":
    # Demostración: el mismo paciente, notificado con las 9 combinaciones
    # posibles de tipo x canal, sin que exista una clase por combinación.
    paciente_demo = {
        "nombre_completo": "Sofía Ramírez", "documento": "1055667788",
        "motivo_consulta": "Dificultad respiratoria súbita",
        "diagnostico": "Crisis asmática moderada", "prioridad": "alta",
        "fecha_proximo_control": None, "registrado_por": "brayan",
    }

    for tipo, _ in TIPOS_NOTIFICACION_OPCIONES:
        for canal, _ in CANALES_ENVIO_OPCIONES:
            notificacion = construir_notificacion(tipo, canal)
            resultado = notificacion.enviar_para(paciente_demo)
            print(f"\n--- {tipo} x {canal} ---")
            print(resultado["mensaje_final"])

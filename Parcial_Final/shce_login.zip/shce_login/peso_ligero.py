"""
peso_ligero.py
---------------
Implementación del patrón de diseño FLYWEIGHT (Peso Ligero), el sexto patrón
ESTRUCTURAL del proyecto. Resuelve un problema distinto al de los demás:
no cómo crear, adaptar o extender un objeto, sino cómo evitar crear una y
otra vez objetos que son EXACTAMENTE iguales.

¿Por qué Flyweight aquí?
------------------------
Al revisar los patrones que ya existían, varios producen objetos que no
tienen ningún estado propio, y aun así se construían de nuevo en cada uso:

  - Abstract Factory (fabricas.py): `obtener_fabrica(tipo)` instanciaba una
    fábrica y, con ella, un validador y un formateador NUEVOS cada vez. Se
    llamaba una vez por paciente en el listado, una vez por hoja del árbol
    (Composite) y una vez por cada archivo exportado.
  - Bridge (notificaciones.py): `construir_notificacion(tipo, canal)`
    instanciaba un canal de envío nuevo por cada notificación. Notificar una
    carpeta de 200 historias creaba 200 canales idénticos.
  - Factory Method (exportadores.py): cada PDF reconstruía la hoja de estilos
    completa (cinco ParagraphStyle y sus colores) aunque siempre fuera igual.

Flyweight separa dos clases de estado:

  ESTADO INTRÍNSECO  -> lo que NO depende del contexto y por tanto se puede
                        compartir: el color del badge de "Urgencias", la regla
                        de validación de "Control", el formato de un SMS, la
                        tipografía del PDF. Vive DENTRO del peso ligero.
  ESTADO EXTRÍNSECO  -> lo que cambia en cada uso: el paciente, el formulario,
                        el destinatario. NUNCA se guarda en el peso ligero: el
                        cliente lo pasa como argumento en cada llamada
                        (`formateador.etiqueta(paciente)`).

Como el objeto compartido no guarda nada del contexto, cien clientes pueden
usar la misma instancia sin pisarse.

Estructura del patrón (qué es cada pieza en este proyecto):
  Flyweight (contrato)       -> PesoLigero (este archivo): impone la inmutabilidad
  Flyweights concretos       -> ValidadorAtencion y FormateadorAtencion con sus
                                subclases y las FabricaAtencion (fabricas.py),
                                CanalEnvio con sus subclases (notificaciones.py)
                                y EstilosPDF (exportadores.py)
  Fábrica de flyweights      -> FabricaPesosLigeros (este archivo): el pool
  Cliente (estado extrínseco)-> las rutas, la fachada, el Composite, los exportadores

Detalles de diseño a tener en cuenta
------------------------------------
  - **Los clientes no cambian.** `obtener_fabrica()`, `crear_formateador()`
    y `construir_notificacion()` conservan su firma: ahora devuelven la misma
    instancia en lugar de una nueva. Ninguna ruta, plantilla ni el Composite
    tuvo que tocarse.
  - **La inmutabilidad se hace cumplir, no se promete.** Un peso ligero
    modificado por un cliente cambiaría el comportamiento de TODOS los demás,
    así que `PesoLigero` bloquea la asignación de atributos y lanza un error
    claro en lugar de permitir un fallo silencioso a distancia.
  - **El pool está acotado a propósito.** Las claves se normalizan ANTES de
    llegar a la fábrica (un tipo de atención inventado cae en "consulta_general",
    un canal inventado en "consola"). Si no, cada valor basura que llegara
    desde un formulario crearía una entrada permanente en memoria.
  - **Es thread-safe.** Flask atiende varias peticiones a la vez; un candado
    garantiza que dos hilos nunca creen dos pesos ligeros para la misma clave.
  - **La fábrica es una instancia única de módulo, no un SingletonMeta.**
    Usar la metaclase de singleton.py obligaría a fabricas.py, notificaciones.py
    y exportadores.py (hoy independientes) a depender de ese módulo, que
    arrastra sqlite3, werkzeug y el Builder. Una instancia de módulo da la
    misma garantía de unicidad sin ese acoplamiento.
  - **Beneficio real, dicho con honestidad:** en este prototipo la mejora es
    de CANTIDAD DE OBJETOS (y por tanto de memoria y de trabajo para el
    recolector de basura), no de velocidad: construir uno de estos objetos
    cuesta microsegundos. El patrón se justifica por la escala (una carpeta con
    cientos de historias) y porque convierte "este objeto no tiene estado" de
    una suposición en una regla verificable.
"""

from threading import Lock


# =====================================================================
# CONTRATO: lo que debe cumplir cualquier peso ligero
# =====================================================================
class PesoLigero:
    """
    Mixin que marca a una clase como compartible e IMPONE que sea inmutable.

    Para ser un peso ligero válido una clase debe cumplir dos reglas:
      1. Todo su estado es INTRÍNSECO (igual para cualquier cliente).
      2. Los datos del contexto entran por parámetro, nunca se guardan.

    La regla 2 se vigila aquí: cualquier intento de asignar o borrar un
    atributo de una instancia lanza AttributeError. Las clases que sí tienen
    estado intrínseco (p. ej. EstilosPDF) lo fijan UNA vez, en su constructor,
    con `object.__setattr__` (la misma técnica que usan los dataclass frozen).
    """

    __slots__ = ()

    def __setattr__(self, nombre, valor):
        raise AttributeError(
            f"{type(self).__name__} es un peso ligero compartido y no se puede modificar "
            f"(intentaste asignar '{nombre}'). Si necesitas guardar datos del contexto, "
            f"pásalos como argumento de la operación en vez de guardarlos en el objeto."
        )

    def __delattr__(self, nombre):
        raise AttributeError(
            f"{type(self).__name__} es un peso ligero compartido y no se puede modificar "
            f"(intentaste borrar '{nombre}')."
        )


# =====================================================================
# FÁBRICA DE PESOS LIGEROS: el pool
# =====================================================================
class FabricaPesosLigeros:
    """
    Guarda los pesos ligeros ya creados y entrega siempre el mismo para la
    misma (categoría, clave). Si todavía no existe, lo construye UNA vez.

    Una `categoría` agrupa pesos de la misma familia ("canal_envio",
    "formateador_atencion"...) y permite separar las estadísticas. La `clave`
    identifica el peso dentro de su categoría ("sms", "urgencias"...).
    """

    def __init__(self):
        self._pool = {}                 # (categoria, clave) -> peso ligero
        self._solicitudes = {}          # categoria -> veces que se pidió algo
        self._lock = Lock()

    def obtener(self, categoria: str, clave: str, constructor):
        """
        Devuelve el peso ligero de (categoria, clave); lo crea con
        `constructor()` solo si es la primera vez que alguien lo pide.

        `constructor` es una función sin argumentos (normalmente la propia
        clase). Se ejecuta DENTRO del candado, así que dos hilos que lleguen
        a la vez nunca producen dos instancias; no debe hacer nada lento.
        """
        llave = (categoria, clave)
        with self._lock:
            self._solicitudes[categoria] = self._solicitudes.get(categoria, 0) + 1
            peso = self._pool.get(llave)
            if peso is None:
                peso = constructor()
                self._pool[llave] = peso
            return peso

    def estadisticas(self) -> dict:
        """
        Cuántas veces se pidió cada familia de objetos frente a cuántos
        objetos distintos hubo que crear de verdad. La diferencia es lo que
        el patrón se ahorró.
        """
        with self._lock:
            creados = {}
            for categoria, _clave in self._pool:
                creados[categoria] = creados.get(categoria, 0) + 1

            categorias = []
            for categoria in sorted(self._solicitudes):
                pedidos = self._solicitudes[categoria]
                nuevos = creados.get(categoria, 0)
                categorias.append({
                    "categoria": categoria,
                    "solicitudes": pedidos,
                    "creados": nuevos,
                    "reutilizados": pedidos - nuevos,
                })

        total_solicitudes = sum(c["solicitudes"] for c in categorias)
        total_creados = sum(c["creados"] for c in categorias)
        return {
            "categorias": categorias,
            "total_solicitudes": total_solicitudes,
            "total_creados": total_creados,
            "total_reutilizados": total_solicitudes - total_creados,
        }

    def reiniciar(self) -> None:
        """Vacía el pool y los contadores (útil en pruebas y demos; la app no lo necesita)."""
        with self._lock:
            self._pool.clear()
            self._solicitudes.clear()


#: La fábrica compartida por todo el proyecto (ver «La fábrica es una
#: instancia única de módulo» en el docstring de arriba).
PESOS_LIGEROS = FabricaPesosLigeros()


if __name__ == "__main__":
    # Demostración sin Flask. IMPORTANTE: cuando un archivo se ejecuta como
    # script, Python lo carga como el módulo "__main__"; si luego fabricas.py
    # hace `from peso_ligero import PESOS_LIGEROS` se carga UNA SEGUNDA COPIA
    # con su propio pool. Por eso aquí se importa el módulo por su nombre y se
    # lee SIEMPRE el pool de esa copia: es el que usan los demás archivos.
    import threading
    import peso_ligero

    from fabricas import obtener_fabrica
    from notificaciones import construir_notificacion
    from exportadores import obtener_estilos_pdf

    pool = peso_ligero.PESOS_LIGEROS
    pool.reiniciar()

    print("1) Misma petición, mismo objeto (en vez de uno nuevo cada vez):")
    a = obtener_fabrica("urgencias").crear_formateador()
    b = obtener_fabrica("urgencias").crear_formateador()
    print(f"   a is b -> {a is b}   ({type(a).__name__})")

    print("\n2) Estado intrínseco compartido, estado extrínseco por parámetro:")
    print(f"   color (intrínseco, de la clase) : {a.color_css}")
    print(f"   etiqueta de Ana  (extrínseco)   : {a.etiqueta({'prioridad': 'alta'})}")
    print(f"   etiqueta de Luis (extrínseco)   : {a.etiqueta({'prioridad': 'baja'})}   <- mismo objeto, otro paciente")

    print("\n3) La inmutabilidad se hace cumplir:")
    try:
        a.color_css = "badge-hackeado"
    except AttributeError as error:
        print(f"   AttributeError -> {error}")

    print("\n4) Un caso masivo: notificar 200 historias por SMS y pedir los estilos de 200 PDF:")
    pool.reiniciar()
    paciente = {"nombre_completo": "Ana Ruiz", "documento": "1", "registrado_por": "admin"}
    for _ in range(200):
        construir_notificacion("informativa", "sms").enviar_para(paciente)
        obtener_estilos_pdf()
        obtener_fabrica("urgencias").crear_formateador()
    resumen = pool.estadisticas()
    for fila in resumen["categorias"]:
        print(f"   {fila['categoria']:<22} pedidos={fila['solicitudes']:>4}  "
              f"creados={fila['creados']:>2}  reutilizados={fila['reutilizados']:>4}")
    print(f"   TOTAL: {resumen['total_solicitudes']} pedidos -> {resumen['total_creados']} objetos creados "
          f"(sin Flyweight serían {resumen['total_solicitudes']})")

    print("\n5) Claves inventadas NO hacen crecer el pool (está acotado):")
    # Primero se crean los dos valores por defecto a los que caen las claves
    # inválidas ("consulta_general" y "consola"); luego se lanzan 1000 claves
    # basura distintas y el tamaño del pool no se mueve.
    obtener_fabrica("consulta_general").crear_formateador()
    construir_notificacion("informativa", "consola")
    antes = pool.estadisticas()["total_creados"]
    for i in range(1000):
        obtener_fabrica(f"tipo-basura-{i}").crear_formateador()
        construir_notificacion("informativa", f"canal-basura-{i}")
    despues = pool.estadisticas()["total_creados"]
    print(f"   objetos en el pool antes={antes}, tras 1000 claves basura={despues}")

    print("\n6) Hilos pidiendo lo mismo a la vez comparten UN solo objeto:")
    pool.reiniciar()
    vistos = []

    def pedir():
        for _ in range(2000):
            vistos.append(id(obtener_fabrica("control").crear_formateador()))

    hilos = [threading.Thread(target=pedir) for _ in range(8)]
    for hilo in hilos:
        hilo.start()
    for hilo in hilos:
        hilo.join()
    print(f"   {len(vistos)} peticiones desde 8 hilos -> {len(set(vistos))} objeto distinto")

"""
singleton.py
------------
Implementación del patrón de diseño SINGLETON aplicado a la gestión
de la base de datos local del Sistema de Historias Clínicas Electrónicas (SHCE).

¿Por qué Singleton aquí?
En un sistema de historias clínicas, la conexión/gestor de la base de datos
de usuarios y credenciales debe ser ÚNICA en toda la aplicación:
  - Evita abrir múltiples conexiones simultáneas a SQLite.
  - Centraliza la validación de credenciales y el registro de auditoría
    (quién entró, cuándo, si tuvo éxito), algo obligatorio en software clínico.
  - Garantiza que, sin importar desde qué parte del código se pida el
    "administrador de base de datos", siempre se obtenga la misma instancia.
"""

# sqlite3: motor de base de datos embebido (no necesita servidor aparte),
# perfecto para que el proyecto funcione "de manera local" sin instalar nada extra.
import sqlite3

# Lock: nos permite evitar que dos hilos (peticiones simultáneas de Flask)
# creen la instancia del Singleton al mismo tiempo.
from threading import Lock

# Funciones de werkzeug (la misma librería que usa Flask por debajo) para
# convertir una contraseña en un "hash" seguro y luego poder compararla,
# sin guardar NUNCA la contraseña en texto plano en la base de datos.
from werkzeug.security import generate_password_hash, check_password_hash
import os
from seguridad import CifradorCampos   # cifrado en reposo de los datos sensibles (Objetivo 4)

#: Campos del paciente que se guardan CIFRADOS. `documento` no: la BD lo usa para evitar duplicados.
CAMPOS_CIFRADOS = ("nombre_completo", "fecha_nacimiento", "motivo_consulta", "diagnostico", "tratamiento", "notas")
MAX_INTENTOS_FALLIDOS = 5      # intentos de login fallidos seguidos antes de bloquear la cuenta
MINUTOS_BLOQUEO = 15

# El patrón Builder: lo usamos aquí solo para armar los datos de los
# pacientes de EJEMPLO de forma legible (ver _sembrar_usuarios_iniciales).
from constructor_historia import ConstructorHistoriaClinica, DirectorHistoriaClinica


class SingletonMeta(type):
    """
    Metaclase que implementa el patrón Singleton de forma thread-safe.

    Una "metaclase" es la clase que sabe CÓMO construir otras clases.
    Al usar esta metaclase, cualquier clase que la use como
    `metaclass=SingletonMeta` solo podrá tener UNA instancia viva durante
    toda la ejecución del programa, sin importar cuántas veces se escriba
    `MiClase()`.
    """

    # Diccionario "de clase" (compartido por todas las instancias de
    # SingletonMeta) que guarda, para cada clase que use este patrón,
    # cuál es su única instancia ya creada. Ejemplo: {DatabaseManager: <objeto>}
    _instances = {}

    # Candado usado para que, si dos peticiones llegan al mismo tiempo,
    # no se creen dos instancias por una condición de carrera.
    _lock = Lock()

    def __call__(cls, *args, **kwargs):
        """
        Este método se ejecuta automáticamente cada vez que alguien escribe
        `DatabaseManager()` en cualquier parte del código. Aquí es donde
        se decide: ¿creo una instancia nueva o devuelvo la que ya existe?
        """
        # Primer chequeo SIN bloqueo: si la instancia ya existe, esto es
        # rápido y evita entrar al Lock innecesariamente en el caso normal.
        if cls not in cls._instances:
            # Solo entra aquí la primera vez (o si dos hilos llegan a la
            # vez y ambos vieron que "no existía" en el chequeo anterior).
            with cls._lock:
                # Segundo chequeo DENTRO del bloqueo ("double-checked locking"):
                # por si otro hilo ya creó la instancia mientras esperábamos el Lock.
                if cls not in cls._instances:
                    # Aquí sí se construye el objeto de verdad, UNA sola vez.
                    instancia = super().__call__(*args, **kwargs)
                    cls._instances[cls] = instancia
        # A partir de aquí, siempre se devuelve la misma instancia guardada.
        return cls._instances[cls]


class DatabaseManager(metaclass=SingletonMeta):
    """
    Única instancia responsable de gestionar la conexión a la base de datos
    local (SQLite) y toda la lógica de autenticación del SHCE.

    Gracias a `metaclass=SingletonMeta`, sin importar cuántas veces se
    llame `DatabaseManager()` en app.py, en singleton.py o en cualquier
    otro archivo, siempre se obtiene el mismo objeto (misma conexión,
    mismos datos en memoria).
    """

    def __init__(self, db_path="shce_local.db"):
        # Ruta del archivo de base de datos local. Al ser SQLite, es solo
        # un archivo en disco: no requiere instalar un servidor de BD aparte.
        self.db_path = db_path

        # Abrimos la conexión UNA sola vez (porque __init__ solo se ejecuta
        # la primera vez, gracias al Singleton).
        # check_same_thread=False -> permite que Flask use esta misma
        # conexión desde distintos hilos de petición.
        self._connection = sqlite3.connect(self.db_path, check_same_thread=False)

        # row_factory = sqlite3.Row hace que cada fila se pueda leer como
        # diccionario (fila["usuario"]) en vez de por posición (fila[0]).
        self._connection.row_factory = sqlite3.Row

        # Cifrado en reposo: la clave sale de SHCE_CLAVE_CIFRADO o de clave_cifrado.key junto a la BD.
        self._cifrador = CifradorCampos.para_directorio(os.path.dirname(os.path.abspath(db_path)))

        # Preparamos las tablas si es la primera vez que se corre el proyecto.
        self._crear_tablas()

        # Sembramos usuarios de ejemplo si la tabla de usuarios está vacía.
        self._sembrar_usuarios_iniciales()

        # Si la BD venía de una versión sin cifrado, se cifran las filas existentes (una sola vez).
        self._cifrar_datos_existentes()

        print(f"[DatabaseManager] Instancia única inicializada -> {db_path}")

    # ---------------------------------------------------------------
    # Estructura de datos
    # ---------------------------------------------------------------
    def _crear_tablas(self):
        """Crea las tablas de la base de datos si todavía no existen."""
        cursor = self._connection.cursor()

        # Tabla de usuarios: aquí vive cada persona que puede iniciar sesión.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,   -- identificador único autogenerado
                nombre_completo TEXT NOT NULL,          -- nombre que se muestra en pantalla
                usuario TEXT UNIQUE NOT NULL,            -- nombre de usuario para iniciar sesión (no se repite)
                password_hash TEXT NOT NULL,             -- contraseña YA convertida a hash, nunca en texto plano
                rol TEXT NOT NULL DEFAULT 'medico',      -- rol dentro del sistema (medico, enfermeria, administracion...)
                activo INTEGER NOT NULL DEFAULT 1,       -- 1 = puede iniciar sesión, 0 = cuenta deshabilitada
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de auditoría: registra cada intento de inicio de sesión
        # (exitoso o fallido). Esto suele ser un requisito legal en
        # software de historias clínicas, para poder rastrear accesos.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bitacora_accesos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,
                exito INTEGER NOT NULL,       -- 1 = login correcto, 0 = login fallido
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de auditoría de exportaciones: la llena el decorador
        # ExportadorConAuditoria (decoradores.py) cada vez que alguien
        # exporta una historia clínica, sea suelta o desde una carpeta.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bitacora_exportaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,        -- quién exportó
                paciente_id INTEGER,          -- qué historia (id interno)
                documento TEXT,               -- documento REAL del paciente exportado
                formato TEXT NOT NULL,        -- pdf / txt / csv
                opciones TEXT,                -- decoradores aplicados, ej. "anonimizado,sello_sha256"
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de accesos denegados: la llena el PROXY DE PROTECCIÓN
        # (proxies.py) cada vez que bloquea una operación por falta de permisos.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bitacora_denegaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT,                 -- quién lo intentó (None si no había sesión)
                rol TEXT,                     -- rol que tenía en ese momento
                operacion TEXT NOT NULL,      -- operación de la fachada, ej. "registrar_paciente"
                motivo TEXT,                  -- por qué se negó
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de pacientes / historias clínicas: el dato principal que el
        # sistema va a exportar (con el patrón Factory Method) en PDF, TXT o CSV.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pacientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre_completo TEXT NOT NULL,
                documento TEXT UNIQUE NOT NULL,        -- cédula / documento de identidad
                fecha_nacimiento TEXT,                  -- formato AAAA-MM-DD
                motivo_consulta TEXT,
                diagnostico TEXT,
                tratamiento TEXT,
                notas TEXT,
                tipo_atencion TEXT NOT NULL DEFAULT 'consulta_general',  -- usado por el Abstract Factory (fabricas.py)
                prioridad TEXT,                         -- solo aplica si tipo_atencion = 'urgencias'
                fecha_proximo_control TEXT,             -- solo aplica si tipo_atencion = 'control'
                registrado_por TEXT,                    -- usuario que creó el registro (auditoría)
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Signos vitales (Objetivo 2): los registra el personal o un dispositivo IoT.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS signos_vitales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                paciente_id INTEGER NOT NULL REFERENCES pacientes(id),
                frecuencia_cardiaca INTEGER, presion_sistolica INTEGER, presion_diastolica INTEGER,
                temperatura REAL, saturacion_o2 INTEGER, glucosa INTEGER,
                origen TEXT NOT NULL DEFAULT 'manual',   -- 'manual' o 'dispositivo'
                dispositivo TEXT,                        -- identificador del equipo, si vino de uno
                registrado_por TEXT,
                medido_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Citas médicas (Objetivo 1).
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS citas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                paciente_id INTEGER NOT NULL REFERENCES pacientes(id),
                fecha TEXT NOT NULL,                     -- AAAA-MM-DD
                hora TEXT NOT NULL,                      -- HH:MM
                medico TEXT NOT NULL,                    -- usuario del médico que atiende
                motivo TEXT,
                estado TEXT NOT NULL DEFAULT 'programada',  -- programada | cumplida | cancelada
                creado_por TEXT,
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Auditoría de eliminaciones: queda constancia de QUIÉN borró QUÉ historia y cuándo.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bitacora_eliminaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL, paciente_id INTEGER NOT NULL, documento TEXT,
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Guardamos los cambios en el archivo .db
        self._connection.commit()

        # Migración suave: si vienes de una versión anterior del proyecto
        # (una base de datos .db creada antes de que existiera el Abstract
        # Factory), la tabla "pacientes" ya existe pero SIN estas 3 columnas
        # nuevas. CREATE TABLE IF NOT EXISTS no las agrega solo, así que las
        # añadimos a mano si hacen falta, para no romper bases de datos viejas.
        self._migrar_columnas_pacientes()

    def _migrar_columnas_pacientes(self):
        """Agrega columnas nuevas a 'pacientes' si vienen de una versión anterior del proyecto."""
        cursor = self._connection.cursor()
        cursor.execute("PRAGMA table_info(pacientes)")
        columnas_existentes = {fila["name"] for fila in cursor.fetchall()}

        columnas_nuevas = {
            "tipo_atencion": "TEXT NOT NULL DEFAULT 'consulta_general'",
            "prioridad": "TEXT",
            "fecha_proximo_control": "TEXT",
            # Patrón State: en qué punto del ciclo de vida está la historia. Las ya existentes quedan "registrada".
            "estado_atencion": "TEXT NOT NULL DEFAULT 'registrada'",
        }
        for columna, definicion in columnas_nuevas.items():
            if columna not in columnas_existentes:
                cursor.execute(f"ALTER TABLE pacientes ADD COLUMN {columna} {definicion}")
        self._connection.commit()

    def _sembrar_usuarios_iniciales(self):
        """
        Crea un par de usuarios de ejemplo la primera vez que se levanta
        la base de datos local, para que puedas probar el login sin tener
        que registrarte primero.
        """
        cursor = self._connection.cursor()
        cursor.execute("SELECT COUNT(*) AS total FROM usuarios")

        # Solo sembramos si la tabla está completamente vacía, así no se
        # duplican estos usuarios cada vez que reinicias el servidor.
        if cursor.fetchone()["total"] == 0:
            self.crear_usuario(
                nombre_completo="Administrador General",
                usuario="admin",
                password="Admin123",
                rol="administrador",
            )
            self.crear_usuario(
                nombre_completo="Brayan",
                usuario="brayan",
                password="Medico123",
                rol="medico",
            )

        # Sembramos un par de pacientes de ejemplo, así puedes probar la
        # exportación (PDF/TXT/CSV) sin tener que crear uno a mano primero.
        # Los armamos con el patrón BUILDER (constructor_historia.py), para
        # mostrar sus dos formas de uso: paso a paso, y con el Director.
        cursor.execute("SELECT COUNT(*) AS total FROM pacientes")
        if cursor.fetchone()["total"] == 0:
            # -------- Uso manual del Builder, paso a paso --------
            datos_maria = (
                ConstructorHistoriaClinica()
                .con_datos_personales("María Fernanda López", "1098765432", "1990-04-12")
                .con_motivo_consulta("Dolor abdominal recurrente")
                .con_diagnostico("Gastritis crónica")
                .con_tratamiento("Omeprazol 20mg cada 24h por 4 semanas")
                .con_notas("Paciente refiere mejoría parcial con dieta blanda.")
                .con_tipo_atencion("consulta_general")
                .construir()
            )
            self.crear_paciente(**datos_maria, registrado_por="admin")

            # -------- Uso del Builder A TRAVÉS del Director --------
            # El Director ya conoce la "receta" de un control de seguimiento
            # (nombre + documento + motivo + fecha del próximo control), y
            # aquí solo completamos con .update() los campos clínicos
            # propios de este caso (diagnóstico, tratamiento, notas).
            datos_carlos = DirectorHistoriaClinica.construir_control_seguimiento(
                nombre_completo="Carlos Andrés Pérez", documento="1012345678",
                motivo="Control post-quirúrgico", fecha_proximo_control="2026-10-05",
            )
            datos_carlos.update({
                "fecha_nacimiento": "1985-11-02",
                "diagnostico": "Recuperación favorable de apendicectomía",
                "tratamiento": "Analgésico según necesidad, retiro de puntos en 7 días",
                "notas": "Sin signos de infección en la herida.",
            })
            self.crear_paciente(**datos_carlos, registrado_por="brayan")

            # Igual, pero con la receta de "urgencia básica" del Director.
            datos_sofia = DirectorHistoriaClinica.construir_urgencia_basica(
                nombre_completo="Sofía Ramírez", documento="1055667788",
                motivo="Dificultad respiratoria súbita", prioridad="alta",
            )
            datos_sofia.update({
                "fecha_nacimiento": "1998-02-20",
                "diagnostico": "Crisis asmática moderada",
                "tratamiento": "Nebulización con salbutamol, observación 4 horas",
                "notas": "Ingresa por urgencias, saturación 92% al llegar.",
            })
            self.crear_paciente(**datos_sofia, registrado_por="brayan")

    # ---------------------------------------------------------------
    # Operaciones de usuarios
    # ---------------------------------------------------------------
    def crear_usuario(self, nombre_completo, usuario, password, rol="medico"):
        """
        Crea un nuevo usuario en la base de datos (usado tanto para los
        usuarios de ejemplo como para el formulario de registro público).

        Devuelve True si se creó, False si el nombre de usuario ya existía.
        """
        cursor = self._connection.cursor()

        # Convertimos la contraseña en un hash seguro (irreversible).
        # Nunca guardamos "password" tal cual en la base de datos.
        password_hash = generate_password_hash(password)

        try:
            cursor.execute(
                """INSERT INTO usuarios (nombre_completo, usuario, password_hash, rol)
                   VALUES (?, ?, ?, ?)""",
                (nombre_completo, usuario, password_hash, rol),
            )
            self._connection.commit()
            return True
        except sqlite3.IntegrityError:
            # Salta aquí si "usuario" ya existía (por la restricción UNIQUE).
            return False

    def validar_credenciales(self, usuario, password):
        """
        Verifica usuario/contraseña para el login y registra el intento
        (exitoso o fallido) en la bitácora de auditoría.
        """
        if self.cuenta_bloqueada(usuario):
            return None      # bloqueo temporal: ni siquiera se comprueba la contraseña
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)
        )
        fila = cursor.fetchone()

        # Comparamos la contraseña ingresada contra el hash guardado.
        # check_password_hash se encarga de aplicar el mismo algoritmo
        # y comparar los resultados de forma segura.
        exito = fila is not None and check_password_hash(fila["password_hash"], password)

        # Se registra SIEMPRE el intento, sea exitoso o no (auditoría).
        self._registrar_acceso(usuario, exito)

        return dict(fila) if exito else None

    def obtener_usuario(self, usuario):
        """Busca un usuario por su nombre de usuario. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = ?", (usuario,))
        fila = cursor.fetchone()
        return dict(fila) if fila else None

    # ---------------------------------------------------------------
    # Operaciones de pacientes / historias clínicas
    # ---------------------------------------------------------------
    def crear_paciente(self, nombre_completo, documento, fecha_nacimiento,
                        motivo_consulta, diagnostico, tratamiento, notas,
                        registrado_por, tipo_atencion="consulta_general",
                        prioridad=None, fecha_proximo_control=None):
        """
        Guarda una nueva historia clínica. Devuelve True si se creó,
        False si ya existía un paciente con ese documento.

        tipo_atencion, prioridad y fecha_proximo_control son los campos
        que usa el patrón Abstract Factory (fabricas.py) para saber qué
        validador y qué formateador aplicarle a este paciente.
        """
        nombre_completo, fecha_nacimiento, motivo_consulta, diagnostico, tratamiento, notas = (
            self._cifrador.cifrar(v) for v in
            (nombre_completo, fecha_nacimiento, motivo_consulta, diagnostico, tratamiento, notas))
        cursor = self._connection.cursor()
        try:
            cursor.execute(
                """INSERT INTO pacientes
                   (nombre_completo, documento, fecha_nacimiento, motivo_consulta,
                    diagnostico, tratamiento, notas, tipo_atencion, prioridad,
                    fecha_proximo_control, registrado_por)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (nombre_completo, documento, fecha_nacimiento, motivo_consulta,
                 diagnostico, tratamiento, notas, tipo_atencion, prioridad,
                 fecha_proximo_control, registrado_por),
            )
            self._connection.commit()
            return True
        except sqlite3.IntegrityError:
            # Salta aquí si "documento" ya existía (restricción UNIQUE).
            return False

    def actualizar_historia_clinica(self, paciente_id, motivo_consulta, diagnostico, tratamiento,
                                    notas, tipo_atencion, prioridad=None, fecha_proximo_control=None):
        """
        Actualiza SOLO los campos clínicos de un paciente (la identidad -nombre,
        documento, fecha de nacimiento- no se modifica). Devuelve True si el
        paciente existía y se actualizó, False si no.
        Lo usa la fachada al editar, deshacer, rehacer o restaurar una versión (Memento).
        """
        motivo_consulta, diagnostico, tratamiento, notas = (
            self._cifrador.cifrar(v) for v in (motivo_consulta, diagnostico, tratamiento, notas))
        cursor = self._connection.cursor()
        cursor.execute(
            """UPDATE pacientes
               SET motivo_consulta = ?, diagnostico = ?, tratamiento = ?, notas = ?,
                   tipo_atencion = ?, prioridad = ?, fecha_proximo_control = ?
               WHERE id = ?""",
            (motivo_consulta, diagnostico, tratamiento, notas, tipo_atencion,
             prioridad, fecha_proximo_control, paciente_id),
        )
        self._connection.commit()
        return cursor.rowcount > 0

    def actualizar_estado_paciente(self, paciente_id, estado):
        """
        Guarda el estado del ciclo de vida de una historia (patrón State: registrada, en_atencion,
        atendida, cerrada). Devuelve True si el paciente existía, False si no.
        """
        cursor = self._connection.cursor()
        cursor.execute("UPDATE pacientes SET estado_atencion = ? WHERE id = ?", (estado, paciente_id))
        self._connection.commit()
        return cursor.rowcount > 0

    def obtener_pacientes(self):
        """Devuelve todos los pacientes, del más reciente al más antiguo."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes ORDER BY creado_en DESC, id DESC")
        return [self._descifrar_paciente(fila) for fila in cursor.fetchall()]

    def obtener_paciente(self, paciente_id):
        """Busca un paciente por su id. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes WHERE id = ?", (paciente_id,))
        fila = cursor.fetchone()
        return self._descifrar_paciente(fila) if fila else None

    def obtener_paciente_por_documento(self, documento):
        """Busca un paciente por su número de documento. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes WHERE documento = ?", (documento,))
        fila = cursor.fetchone()
        return self._descifrar_paciente(fila) if fila else None

    # ---------------------------------------------------------------
    # Cifrado en reposo
    # ---------------------------------------------------------------
    def _descifrar_paciente(self, fila) -> dict:
        """Convierte una fila de `pacientes` en dict con los campos sensibles ya descifrados."""
        paciente = dict(fila)
        for campo in CAMPOS_CIFRADOS:
            paciente[campo] = self._cifrador.descifrar(paciente.get(campo))
        return paciente

    def _cifrar_datos_existentes(self):
        """Cifra las filas que todavía están en texto plano (migración de una BD anterior)."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes")
        for fila in cursor.fetchall():
            cambios = {c: self._cifrador.cifrar(fila[c]) for c in CAMPOS_CIFRADOS
                       if isinstance(fila[c], str) and fila[c] and not fila[c].startswith("enc:v1:")}
            if cambios:
                asignaciones = ", ".join(f"{c} = ?" for c in cambios)
                cursor.execute(f"UPDATE pacientes SET {asignaciones} WHERE id = ?", (*cambios.values(), fila["id"]))
        self._connection.commit()

    # ---------------------------------------------------------------
    # Bloqueo por intentos fallidos
    # ---------------------------------------------------------------
    def cuenta_bloqueada(self, usuario) -> bool:
        """True si el usuario acumula MAX_INTENTOS_FALLIDOS fallos seguidos en los últimos MINUTOS_BLOQUEO minutos."""
        cursor = self._connection.cursor()
        cursor.execute(
            """SELECT COUNT(*) FROM bitacora_accesos
               WHERE usuario = ? AND exito = 0 AND fecha > datetime('now', ?)
                 AND fecha > COALESCE((SELECT MAX(fecha) FROM bitacora_accesos WHERE usuario = ? AND exito = 1), '')""",
            (usuario, f"-{MINUTOS_BLOQUEO} minutes", usuario),
        )
        return cursor.fetchone()[0] >= MAX_INTENTOS_FALLIDOS

    # ---------------------------------------------------------------
    # Signos vitales
    # ---------------------------------------------------------------
    def crear_signos(self, paciente_id, lectura: dict, origen, dispositivo, registrado_por) -> int:
        columnas = ["paciente_id", "origen", "dispositivo", "registrado_por", *lectura]
        cursor = self._connection.cursor()
        cursor.execute(
            f"INSERT INTO signos_vitales ({', '.join(columnas)}) VALUES ({', '.join('?' * len(columnas))})",
            (paciente_id, origen, dispositivo, registrado_por, *lectura.values()),
        )
        self._connection.commit()
        return cursor.lastrowid

    def obtener_signos(self, paciente_id, limite=10) -> list:
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM signos_vitales WHERE paciente_id = ? ORDER BY id DESC LIMIT ?", (paciente_id, limite))
        return [dict(f) for f in cursor.fetchall()]

    # ---------------------------------------------------------------
    # Citas
    # ---------------------------------------------------------------
    def crear_cita(self, paciente_id, fecha, hora, medico, motivo, creado_por) -> int:
        cursor = self._connection.cursor()
        cursor.execute(
            "INSERT INTO citas (paciente_id, fecha, hora, medico, motivo, creado_por) VALUES (?, ?, ?, ?, ?, ?)",
            (paciente_id, fecha, hora, medico, motivo, creado_por),
        )
        self._connection.commit()
        return cursor.lastrowid

    def obtener_citas(self, paciente_id=None, estado=None) -> list:
        consulta, parametros = "SELECT * FROM citas WHERE 1=1", []
        if paciente_id is not None:
            consulta += " AND paciente_id = ?"; parametros.append(paciente_id)
        if estado:
            consulta += " AND estado = ?"; parametros.append(estado)
        cursor = self._connection.cursor()
        cursor.execute(consulta + " ORDER BY fecha, hora", parametros)
        return [dict(f) for f in cursor.fetchall()]

    def obtener_cita(self, cita_id):
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM citas WHERE id = ?", (cita_id,))
        fila = cursor.fetchone()
        return dict(fila) if fila else None

    def existe_cita_programada(self, medico, fecha, hora) -> bool:
        cursor = self._connection.cursor()
        cursor.execute("SELECT 1 FROM citas WHERE medico = ? AND fecha = ? AND hora = ? AND estado = 'programada'",
                       (medico, fecha, hora))
        return cursor.fetchone() is not None

    def actualizar_estado_cita(self, cita_id, estado) -> bool:
        cursor = self._connection.cursor()
        cursor.execute("UPDATE citas SET estado = ? WHERE id = ?", (estado, cita_id))
        self._connection.commit()
        return cursor.rowcount > 0

    def listar_usuarios_por_rol(self, roles) -> list:
        """Usuarios activos con alguno de los roles dados: [{'usuario', 'nombre_completo'}]."""
        roles = list(roles)
        cursor = self._connection.cursor()
        cursor.execute(
            f"SELECT usuario, nombre_completo FROM usuarios WHERE activo = 1 AND rol IN ({', '.join('?' * len(roles))}) "
            "ORDER BY nombre_completo", roles)
        return [dict(f) for f in cursor.fetchall()]

    # ---------------------------------------------------------------
    # Eliminación (con auditoría)
    # ---------------------------------------------------------------
    def eliminar_paciente(self, paciente_id, eliminado_por):
        """
        Borra la historia y TODO lo que depende de ella (citas y signos vitales) en una sola
        transacción, y deja constancia en la bitácora. Devuelve el paciente borrado, o None si no existía.
        """
        paciente = self.obtener_paciente(paciente_id)
        if paciente is None:
            return None
        cursor = self._connection.cursor()
        try:
            cursor.execute("DELETE FROM signos_vitales WHERE paciente_id = ?", (paciente_id,))
            cursor.execute("DELETE FROM citas WHERE paciente_id = ?", (paciente_id,))
            cursor.execute("DELETE FROM pacientes WHERE id = ?", (paciente_id,))
            cursor.execute("INSERT INTO bitacora_eliminaciones (usuario, paciente_id, documento) VALUES (?, ?, ?)",
                           (eliminado_por, paciente_id, paciente["documento"]))
            self._connection.commit()
        except Exception:
            self._connection.rollback()
            raise
        return paciente

    def obtener_eliminaciones(self, limite=6) -> list:
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM bitacora_eliminaciones ORDER BY id DESC LIMIT ?", (limite,))
        return [dict(f) for f in cursor.fetchall()]

    # ---------------------------------------------------------------
    # Auditoría (obligatoria en sistemas de historias clínicas)
    # ---------------------------------------------------------------
    def registrar_exportacion(self, evento: dict):
        """
        Guarda una exportación en la bitácora. Recibe el diccionario que
        arma ExportadorConAuditoria (usuario, paciente_id, documento,
        formato, opciones). Se usa como la función `registrar` del decorador.
        """
        cursor = self._connection.cursor()
        cursor.execute(
            """INSERT INTO bitacora_exportaciones
               (usuario, paciente_id, documento, formato, opciones)
               VALUES (?, ?, ?, ?, ?)""",
            (evento["usuario"], evento.get("paciente_id"), evento.get("documento"),
             evento["formato"], evento.get("opciones", "")),
        )
        self._connection.commit()

    def obtener_exportaciones(self, limite=6):
        """Devuelve las últimas exportaciones, de la más reciente a la más antigua."""
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM bitacora_exportaciones ORDER BY id DESC LIMIT ?", (limite,)
        )
        return [dict(fila) for fila in cursor.fetchall()]

    def registrar_denegacion(self, evento: dict):
        """
        Guarda un acceso denegado en la bitácora. Recibe el diccionario que
        arma el proxy de protección (usuario, rol, operacion, motivo).
        """
        cursor = self._connection.cursor()
        cursor.execute(
            """INSERT INTO bitacora_denegaciones (usuario, rol, operacion, motivo)
               VALUES (?, ?, ?, ?)""",
            (evento.get("usuario"), evento.get("rol"), evento["operacion"], evento.get("motivo", "")),
        )
        self._connection.commit()

    def obtener_denegaciones(self, limite=6):
        """Devuelve los últimos accesos denegados, del más reciente al más antiguo."""
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM bitacora_denegaciones ORDER BY id DESC LIMIT ?", (limite,)
        )
        return [dict(fila) for fila in cursor.fetchall()]

    def _registrar_acceso(self, usuario, exito):
        """Guarda un renglón en la bitácora cada vez que alguien intenta iniciar sesión."""
        cursor = self._connection.cursor()
        cursor.execute(
            "INSERT INTO bitacora_accesos (usuario, exito) VALUES (?, ?)",
            (usuario, int(exito)),
        )
        self._connection.commit()

    def obtener_bitacora(self, limite=8):
        """Devuelve los últimos `limite` eventos de acceso, del más reciente al más antiguo."""
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM bitacora_accesos ORDER BY fecha DESC LIMIT ?", (limite,)
        )
        return [dict(fila) for fila in cursor.fetchall()]


# Este bloque SOLO se ejecuta si corres directamente "python3 singleton.py"
# (no se ejecuta cuando app.py hace `from singleton import DatabaseManager`).
# Sirve para comprobar rápidamente que el patrón Singleton funciona.
if __name__ == "__main__":
    db1 = DatabaseManager()   # primera llamada -> crea la instancia real
    db2 = DatabaseManager()   # segunda llamada -> devuelve la MISMA instancia
    print("¿db1 es exactamente db2? ->", db1 is db2)
    print("Usuario admin creado con éxito:", db1.obtener_usuario("admin") is not None)

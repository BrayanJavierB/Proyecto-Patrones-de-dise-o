"""
fachada.py
----------
Implementación del patrón de diseño FACADE (estructural): una interfaz
ÚNICA y simplificada hacia un conjunto de subsistemas que, por separado,
son más complejos de usar.

¿Por qué Facade aquí?
---------------------
Antes de este módulo, cada ruta de Flask (app.py) tenía que conocer y
orquestar a mano los subsistemas que ya existían. Por ejemplo, registrar
un paciente desde el formulario exigía, en este orden:

  1. Builder           -> armar el diccionario de la historia clínica.
  2. Singleton         -> comprobar que el documento no existe ya.
  3. Abstract Factory  -> pedir el validador del tipo de atención y validar.
  4. Singleton         -> guardar el paciente.
  5. Bridge            -> notificar si es Urgencias o Control.

Y la importación desde el sistema externo repetía casi la misma secuencia
cambiando solo el primer paso (Adapter en lugar de Builder). Esa
coreografía estaba copiada en varias rutas: si cambiaba una regla (p. ej.
"notificar también las consultas generales"), había que acordarse de
tocarlas todas.

Con Facade, esa coreografía vive en UN solo lugar. La ruta de Flask pasa
a ser:

    resultado = fachada.registrar_paciente(request.form, usuario)

y no necesita saber que existen un Builder, una fábrica abstracta, un
Singleton ni un puente de notificaciones.

Estructura del patrón en este archivo:
  Fachada     -> FachadaSHCE
  Subsistemas -> DatabaseManager (Singleton), ConstructorHistoriaClinica (Builder),
                 obtener_fabrica (Abstract Factory), HistoriaClinicaPrototype (Prototype),
                 AdaptadorSistemaExterno (Adapter), construir_notificacion (Bridge),
                 construir_arbol (Composite), obtener_creador (Factory Method),
                 decoradores_para (Decorator), PESOS_LIGEROS (Flyweight),
                 ProxySistemaExterno (Proxy),
                 IteradorRegistrosExternos y los recorridos del árbol (Iterator),
                 MediadorClinico y sus colegas (Mediator),
                 HistoriaClinicaEditable / HistorialVersiones (Memento),
                 ServicioSeguimiento (Observer), CicloVidaHistoria (State),
                 los visitantes de reportes (Visitor),
                 los criterios de orden (Strategy), los comandos de estado (Command),
                 los procesos de alta (Template Method)
  Cliente     -> las rutas de app.py

Qué SÍ y qué NO hace una fachada:
  - SÍ simplifica: ofrece pocas operaciones, con nombres del negocio
    ("registrar_paciente", "exportar_nodo") en lugar de pasos técnicos.
  - SÍ desacopla: app.py ya no importa ninguno de los 10 módulos de patrones.
  - NO reemplaza a los subsistemas: siguen siendo independientes y
    utilizables por sí solos (cada módulo conserva su `python3 modulo.py`).
    La fachada solo es un atajo cómodo; no es una barrera.
  - NO contiene lógica propia de ningún patrón: solo decide QUÉ subsistema
    llamar y en QUÉ orden.

Decisiones de diseño:
  - La fachada NO conoce Flask. No lee `request`, no toca `session` y no
    llama a `flash`: recibe datos simples (el formulario como mapeo, el
    nombre de usuario como texto) y devuelve datos simples. Por eso se
    puede probar y reutilizar sin levantar el servidor (ver el bloque
    `__main__` al final del archivo).
  - Los errores "esperables" (paciente inexistente, formato no soportado...)
    se lanzan como subclases de `ErrorFachada`, cuyo mensaje ya es el
    texto que se le muestra al usuario. La ruta solo hace `flash(str(error))`.
  - Los errores de VALIDACIÓN (campos faltantes, documento repetido) no son
    excepciones sino un `ResultadoOperacion` con la lista de errores: son un
    resultado normal del flujo, y la ruta debe mostrarlos todos juntos.
  - La fachada guarda el historial de notificaciones en memoria (antes vivía
    como variable global en app.py): es estado del negocio, no de la web.
"""

import io
import re
import zipfile
import datetime
from dataclasses import dataclass, field

# Los once subsistemas que esta fachada unifica.
from singleton import DatabaseManager                                      # Singleton
from exportadores import obtener_creador, calcular_edad                    # Factory Method
from fabricas import obtener_fabrica, TIPOS_ATENCION                       # Abstract Factory
from constructor_historia import ConstructorHistoriaClinica                # Builder
from prototipos import HistoriaClinicaPrototype                            # Prototype
from adaptadores import SistemaExternoHistorias, AdaptadorSistemaExterno   # Adapter
from notificaciones import (                                               # Bridge
    construir_notificacion,
    TIPOS_NOTIFICACION_OPCIONES,
    CANALES_ENVIO_OPCIONES,
)
from estructura_clinica import construir_arbol, AGRUPACIONES_OPCIONES      # Composite
from decoradores import decoradores_para, opciones_validas, OPCIONES_EXPORTACION  # Decorator
from peso_ligero import PESOS_LIGEROS                                      # Flyweight
from iteradores import IteradorRegistrosExternos                           # Iterator
from mediador import (                                                     # Mediator
    MediadorClinico, Evento, HistorialNotificaciones,
    NotificadorAutomatico, AuditoriaDenegaciones,
)
from memento import HistoriaClinicaEditable, HistorialVersiones, CAMPOS_CLINICOS  # Memento
from observador import ServicioSeguimiento, CambioHistoria                        # Observer
from estados import CicloVidaHistoria, TransicionInvalida, ESTADOS                  # State
from estrategias import (                                                          # Strategy
    OrdenadorPacientes, obtener_estrategia, ORDENES_OPCIONES, ORDEN_POR_DEFECTO, ESTRATEGIAS,
)
from comandos import (                                                              # Command
    ComandoCambiarEstado, ComandoMacro, HistorialComandos, ErrorComando, ComandoPacienteNoEncontrado,
)
from visitantes import VisitanteEstadisticas, VisitanteCompletitud, VisitanteControles   # Visitor
from proxies import ProxySistemaExterno                                    # Proxy (caché)
from procesos_alta import AltaManual, AltaImportada                      # Template Method
from interacciones import buscar_interacciones                           # Objetivo 3
from signos_vitales import validar_lectura, evaluar_alertas, CAMPOS as CAMPOS_SIGNOS   # Objetivo 2

# Nombres legibles de las familias de pesos ligeros, para el panel.
_NOMBRES_PESOS_LIGEROS = {
    "fabrica_atencion": "Fábricas de atención",
    "validador_atencion": "Validadores de atención",
    "formateador_atencion": "Formateadores de etiqueta",
    "canal_envio": "Canales de envío",
    "estilos_pdf": "Estilos de PDF",
}


# =====================================================================
# ERRORES DE LA FACHADA
# =====================================================================
class ErrorFachada(Exception):
    """
    Base de los errores esperables de la fachada. `str(error)` es un
    mensaje listo para mostrarle al usuario, así que la capa web solo
    tiene que hacer `flash(str(error))`.
    """


class PacienteNoEncontrado(ErrorFachada):
    """No existe el paciente pedido (o el identificador recibido no es válido)."""


class FormatoNoSoportado(ErrorFachada):
    """El formato de exportación pedido no existe (solo hay pdf, txt y csv)."""


class RegistroExternoNoEncontrado(ErrorFachada):
    """El sistema externo no tiene el código de historia pedido."""


class NodoNoEncontrado(ErrorFachada):
    """La carpeta (o historia) pedida no existe en el árbol actual."""


class CarpetaVacia(ErrorFachada):
    """La carpeta elegida existe pero no contiene ninguna historia."""


class SinVersiones(ErrorFachada):
    """No hay ediciones que deshacer o rehacer en esta historia."""


class VersionNoEncontrada(ErrorFachada):
    """La versión pedida ya no está en el historial de la historia."""


class HistoriaNoEditable(ErrorFachada):
    """El estado actual de la historia (Atendida o Cerrada) no admite modificaciones."""


class TransicionNoPermitida(ErrorFachada):
    """La acción pedida no está disponible en el estado actual de la historia."""


# =====================================================================
# RESULTADOS: datos simples que la fachada le entrega a la capa web
# =====================================================================
#: Roles que una persona puede elegir al registrarse. El de administrador NO está: quien se registra por sí mismo
#: no puede darse privilegios (los administradores los crea quien ya administra el sistema).
ROLES_AUTOREGISTRO = ("medico", "enfermeria")


@dataclass
class ResultadoOperacion:
    """
    Resultado de una operación que puede fallar por VALIDACIÓN.
      errores -> lista de mensajes (vacía si todo salió bien).
      datos   -> los datos con los que se trabajó (sirve para volver a
                 pintar el formulario sin que el usuario pierda lo escrito).
    """
    errores: list = field(default_factory=list)
    datos: dict = field(default_factory=dict)

    @property
    def exitoso(self) -> bool:
        return not self.errores


@dataclass
class ArchivoExportado:
    """Un archivo listo para descargar: sus bytes, su tipo MIME y su nombre."""
    contenido: bytes
    mimetype: str
    nombre: str


# =====================================================================
# LA FACHADA
# =====================================================================
class FachadaSHCE:
    """
    Punto de entrada único al núcleo del SHCE. Agrupa las operaciones en
    seis áreas: cuentas, panel, pacientes, importación externa,
    notificaciones y estructura (árbol de carpetas).
    """

    # Catálogos que las plantillas necesitan para pintar <select> y casillas.
    # Se exponen aquí para que la capa web no tenga que importar los módulos
    # de patrones solo para leer una lista de opciones.
    tipos_atencion = TIPOS_ATENCION
    tipos_notificacion = TIPOS_NOTIFICACION_OPCIONES
    canales_envio = CANALES_ENVIO_OPCIONES
    agrupaciones = AGRUPACIONES_OPCIONES
    opciones_exportacion = OPCIONES_EXPORTACION
    ordenes_disponibles = ORDENES_OPCIONES        # Strategy: criterios para ordenar el listado
    # Command: todas las acciones del ciclo de vida que existen, como (acción, texto del botón).
    acciones_estado = list({a: t for e in ESTADOS.values() for a, t in e.acciones.items()}.items())

    # Nombres legibles de los campos clínicos, para describir qué cambió en un aviso (Observer).
    _ETIQUETAS_CAMPOS = {
        "motivo_consulta": "Motivo de consulta", "diagnostico": "Diagnóstico", "tratamiento": "Tratamiento",
        "notas": "Notas", "tipo_atencion": "Tipo de atención", "prioridad": "Prioridad",
        "fecha_proximo_control": "Próximo control",
    }

    def __init__(self, db=None, sistema_externo=None):
        """
        Ambos parámetros son opcionales y existen para poder sustituir los
        subsistemas (p. ej. en una prueba). Por defecto:
          - db              -> la ÚNICA instancia de DatabaseManager (Singleton).
          - sistema_externo -> el simulador del Sistema Externo de Historias
                               (no es Singleton: representa software de terceros).
        Sea cual sea el sistema externo, la fachada lo usa a través de un
        ProxySistemaExterno (Proxy): las consultas repetidas se responden
        desde su caché y no vuelven a molestar al tercero.
        """
        self._db = db if db is not None else DatabaseManager()
        externo_real = sistema_externo if sistema_externo is not None else SistemaExternoHistorias()
        self._externo = ProxySistemaExterno(externo_real)
        # Mediator: aquí se arma la red de colegas. Ninguno conoce a los demás; todos
        # hablan solo con el mediador, y es AQUÍ (y en ningún otro sitio) donde se decide
        # quién reacciona a qué. El historial vive en memoria: se reinicia con el servidor.
        self._mediador = MediadorClinico()
        self._historial = self._mediador.registrar(HistorialNotificaciones(), Evento.NOTIFICACION_ENVIADA)
        self._mediador.registrar(NotificadorAutomatico(), Evento.PACIENTE_REGISTRADO)
        self._mediador.registrar(AuditoriaDenegaciones(self._db), Evento.ACCESO_DENEGADO)
        # Memento: el cuidador de las instantáneas de las historias editadas (en memoria, como el historial).
        self._versiones = HistorialVersiones()
        # Observer: suscripciones de los usuarios a las historias y sus bandejas de avisos (en memoria).
        self._seguimiento = ServicioSeguimiento()
        # Command: el historial (invocador) de acciones de ciclo de vida de cada usuario (en memoria).
        self._comandos = HistorialComandos()

    # -----------------------------------------------------------------
    # 1) CUENTAS
    # -----------------------------------------------------------------
    def iniciar_sesion(self, usuario: str, password: str):
        """
        Devuelve el registro del usuario si las credenciales son válidas,
        o None si no lo son. (El Singleton deja el intento en la bitácora.)
        """
        return self._db.validar_credenciales(usuario, password)

    def registrar_usuario(self, nombre_completo, usuario, password,
                          confirmar_password, rol="medico") -> ResultadoOperacion:
        """Valida los datos de registro y, si todo está bien, crea la cuenta."""
        errores = []

        if not nombre_completo or not usuario or not password:
            errores.append("Todos los campos son obligatorios.")
        if len(password) < 8 or password.isalpha() or password.isdigit():
            errores.append("La contraseña debe tener al menos 8 caracteres e incluir letras y números.")
        if rol not in ROLES_AUTOREGISTRO:
            # Seguridad: el registro público NO permite elegirse administrador (solo médico o enfermería).
            errores.append("Rol no permitido en el registro público.")
        if password != confirmar_password:
            errores.append("Las contraseñas no coinciden.")
        if self._db.obtener_usuario(usuario) is not None:
            errores.append("Ese nombre de usuario ya existe, elige otro.")

        if not errores and not self._db.crear_usuario(nombre_completo, usuario, password, rol):
            # Red de seguridad: dos registros simultáneos con el mismo usuario.
            errores.append("Ese nombre de usuario ya existe, elige otro.")
        return ResultadoOperacion(errores=errores)

    # -----------------------------------------------------------------
    # 2) PANEL
    # -----------------------------------------------------------------
    def resumen_panel(self) -> dict:
        """Todo lo que muestra el panel principal, en una sola llamada."""
        return {
            "bitacora": self._db.obtener_bitacora(limite=8),
            "total_pacientes": len(self._db.obtener_pacientes()),
            "exportaciones": self._db.obtener_exportaciones(limite=6),
            "pesos_ligeros": self._resumen_pesos_ligeros(),
            "proxy_externo": self._externo.estadisticas(),                 # Proxy de caché
            "denegaciones": self._db.obtener_denegaciones(limite=6),       # Proxy de protección
            # id(db) permite comprobar visualmente que siempre es la misma instancia Singleton.
            "instancia_id": id(self._db),
        }

    def registrar_denegacion(self, evento: dict) -> None:
        """
        Deja en la bitácora un acceso denegado. Lo usa el proxy de protección
        (proxies.py) como callback; no es una operación para las rutas.
        """
        self._mediador.notificar(self, Evento.ACCESO_DENEGADO, intento=evento)

    def _resumen_pesos_ligeros(self) -> dict:
        """
        Flyweight: cuántos objetos se pidieron frente a cuántos hubo que crear
        de verdad desde que arrancó el servidor, por familia. Es solo lectura
        de las estadísticas del pool; la fachada no comparte ni crea nada aquí.
        """
        resumen = PESOS_LIGEROS.estadisticas()
        for fila in resumen["categorias"]:
            fila["nombre"] = _NOMBRES_PESOS_LIGEROS.get(fila["categoria"], fila["categoria"])
        return resumen

    # -----------------------------------------------------------------
    # 3) PACIENTES
    # -----------------------------------------------------------------
    def listar_pacientes(self) -> list:
        """Los pacientes tal como están en la base de datos (más reciente primero)."""
        return self._db.obtener_pacientes()

    def normalizar_orden(self, orden: str) -> str:
        """Strategy: devuelve el criterio pedido, o el de por defecto si no existe."""
        return orden if orden in ESTRATEGIAS else ORDEN_POR_DEFECTO

    def listar_pacientes_enriquecidos(self, orden: str = ORDEN_POR_DEFECTO) -> list:
        """
        Los pacientes listos para pintar en la tabla: cada uno con su edad
        ya calculada y su etiqueta/color de tipo de atención (Abstract
        Factory: formateador de la fábrica que corresponde a su tipo).
        """
        pacientes = self._db.obtener_pacientes()
        for paciente in pacientes:
            paciente["edad"] = calcular_edad(paciente.get("fecha_nacimiento"))
            formateador = obtener_fabrica(paciente.get("tipo_atencion")).crear_formateador()
            paciente["etiqueta_atencion"] = formateador.etiqueta(paciente)
            paciente["color_atencion"] = formateador.color_css
            paciente.update(self._info_estado(paciente))   # State: estado, ¿editable? y acciones
            paciente["alertas_interaccion"] = buscar_interacciones(paciente.get("tratamiento"))   # Objetivo 3
        # Strategy: el criterio de orden es un objeto intercambiable; la fachada no tiene ningún `if orden == ...`.
        return OrdenadorPacientes(obtener_estrategia(orden)).ordenar(pacientes)

    def plantilla_desde_paciente(self, paciente_id: int):
        """
        Prototype: clona la historia de un paciente existente como punto de
        partida de una consulta nueva (sin documento ni notas).
        Devuelve (plantilla, nombre_del_paciente_origen).
        """
        original = self._db.obtener_paciente(paciente_id)
        if original is None:
            raise PacienteNoEncontrado("Paciente no encontrado.")
        plantilla = HistoriaClinicaPrototype(original).como_plantilla_nueva()
        return plantilla, original["nombre_completo"]

    def registrar_paciente(self, datos_formulario, registrado_por: str) -> ResultadoOperacion:
        """
        Registra una historia clínica a partir de los datos de un formulario
        (cualquier mapeo con `.get`, como `request.form`).

        Template Method: `AltaManual` (procesos_alta.py) arma los datos con el Builder y la
        secuencia común (documento único -> validación por tipo -> guardar -> avisar) la fija
        la clase base. Si falla la validación NO se guarda nada y `resultado.datos` trae lo
        que escribió el usuario para volver a pintar el formulario.
        """
        return self._dar_de_alta(AltaManual(self._db, datos_formulario, self._avisar_alta), registrado_por)

    # -----------------------------------------------------------------
    # 4) IMPORTACIÓN DESDE EL SISTEMA EXTERNO (Adapter)
    # -----------------------------------------------------------------
    def listar_registros_externos(self) -> list:
        """Las historias disponibles en el sistema externo, en SU formato crudo."""
        # Iterator: recorre el sistema externo (a través del Proxy) pidiendo un registro por vez.
        return list(IteradorRegistrosExternos(self._externo))

    def previsualizar_importacion(self, codigo_externo: str):
        """
        Devuelve (crudo, adaptado): el dato como lo entrega el sistema
        externo y ya traducido al formato estándar de SHCE (Adapter).
        """
        try:
            crudo = self._externo.consultar_registro(codigo_externo)
        except ValueError:
            raise RegistroExternoNoEncontrado("Ese registro ya no existe en el sistema externo.") from None
        adaptado = AdaptadorSistemaExterno(self._externo, codigo_externo).obtener_historia_estandar()
        return crudo, adaptado

    def importar_desde_externo(self, codigo_externo: str, registrado_por: str) -> ResultadoOperacion:
        """
        Importa una historia del sistema externo. Template Method: `AltaImportada` obtiene los
        datos con el Adapter y reutiliza EXACTAMENTE la misma secuencia de alta que el formulario
        manual (la define la clase base `ProcesoAlta`): no importa de dónde venga el paciente.
        """
        proceso = AltaImportada(
            self._db, lambda: self.previsualizar_importacion(codigo_externo)[1], self._avisar_alta
        )
        return self._dar_de_alta(proceso, registrado_por)

    # -----------------------------------------------------------------
    # 5) EXPORTACIÓN DE UNA HISTORIA (Factory Method + Decorator)
    # -----------------------------------------------------------------
    def exportar_paciente(self, paciente_id: int, formato: str, opciones=(), usuario: str = None) -> ArchivoExportado:
        """
        Genera el archivo de la historia de un paciente.
          formato  -> "pdf", "txt" o "csv".
          opciones -> casillas marcadas ("anonimizar", "sello"); lo desconocido se ignora.
          usuario  -> quien exporta, para la bitácora (la auditoría se aplica SIEMPRE).
        """
        paciente = self._db.obtener_paciente(paciente_id)
        if paciente is None:
            raise PacienteNoEncontrado("Paciente no encontrado.")

        creador = self._creador(formato)                       # Factory Method
        envolturas = self._envolturas(opciones, usuario)       # Decorator
        contenido, mimetype, nombre = creador.exportar_historia(paciente, envolturas)
        return ArchivoExportado(contenido, mimetype, nombre)

    # -----------------------------------------------------------------
    # 6) NOTIFICACIONES (Bridge)
    # -----------------------------------------------------------------
    def notificar_paciente(self, paciente_id, tipo: str, canal: str) -> dict:
        """Envía una notificación (tipo x canal) a un paciente y la guarda en el historial."""
        texto = str(paciente_id)
        paciente = self._db.obtener_paciente(int(texto)) if texto.isdigit() else None
        if paciente is None:
            raise PacienteNoEncontrado("Selecciona un paciente válido.")

        resultado = construir_notificacion(tipo, canal).enviar_para(paciente)
        resultado["paciente_nombre"] = paciente["nombre_completo"]
        self._mediador.notificar(self, Evento.NOTIFICACION_ENVIADA, resultado=resultado)
        return resultado

    def historial_notificaciones(self, limite: int = 10, tipo_notificacion: str = None,
                                 canal: str = None, paciente: str = None) -> list:
        """
        Las últimas notificaciones enviadas (manuales y automáticas), la más
        reciente primero. Los filtros son opcionales y se combinan con "y":
        buscan el texto dado dentro del tipo, el canal o el nombre del paciente,
        sin distinguir mayúsculas. Iterator: IteradorHistorial.
        """
        return self._historial.ultimos(limite, tipo_notificacion, canal, paciente)

    # -----------------------------------------------------------------
    # 7) ESTRUCTURA: ÁRBOL DE CARPETAS (Composite)
    # -----------------------------------------------------------------
    def normalizar_agrupacion(self, agrupacion: str) -> str:
        """Devuelve la agrupación pedida, o la primera disponible si no existe."""
        claves_validas = [clave for clave, _ in AGRUPACIONES_OPCIONES]
        return agrupacion if agrupacion in claves_validas else claves_validas[0]

    def consultar_estructura(self, agrupacion: str) -> dict:
        """
        Todo lo que necesita la página del árbol: la agrupación efectiva,
        el árbol como diccionario y las carpetas para el <select> de
        "notificar grupo" (con sangría según su profundidad).
        """
        agrupacion, raiz = self._arbol(agrupacion)
        return {"agrupacion": agrupacion, "arbol": raiz.a_diccionario(), "grupos": self._carpetas_para_selector(raiz)}

    def resumen_por_niveles(self, agrupacion: str) -> dict:
        """
        Cuántas carpetas y cuántas historias hay en cada piso del árbol.
        Iterator: el recorrido en ANCHURA entrega los pisos en orden, de modo
        que basta ir contando sin ordenar nada después.
        Devuelve {"agrupacion": ..., "niveles": [{"nivel", "carpetas", "historias"}, ...]}.
        """
        agrupacion, raiz = self._arbol(agrupacion)
        niveles = {}
        for nivel, nodo in raiz.crear_iterador("anchura"):
            fila = niveles.setdefault(nivel, {"nivel": nivel, "carpetas": 0, "historias": 0})
            fila["carpetas" if nodo.es_grupo else "historias"] += 1
        return {"agrupacion": agrupacion, "niveles": list(niveles.values())}

    def exportar_nodo(self, formato: str, nodo_clave, agrupacion: str,
                      opciones=(), usuario: str = None) -> ArchivoExportado:
        """
        Exporta, en un .zip, la historia de CADA paciente del nodo elegido
        (una carpeta, la raíz o una historia suelta). Si `nodo_clave` es
        None se exporta todo el árbol. Las mismas opciones (anonimizar,
        sello) se aplican a cada historia contenida.
        """
        agrupacion, raiz = self._arbol(agrupacion)
        self._creador(formato)    # valida el formato aunque el grupo esté vacío

        nodo = raiz.buscar(raiz.clave if nodo_clave is None else nodo_clave)
        if nodo is None:
            raise NodoNoEncontrado("Esa carpeta ya no existe en la estructura actual.")

        # Composite + Factory Method + Decorator: el nodo (hoja o grupo) exporta
        # sin que la fachada sepa cuál de los dos es.
        archivos = nodo.exportar(formato, self._envolturas(opciones, usuario))
        if not archivos:
            raise CarpetaVacia("Esa carpeta no tiene historias para exportar.")

        memoria = io.BytesIO()
        with zipfile.ZipFile(memoria, "w", zipfile.ZIP_DEFLATED) as paquete:
            for nombre_archivo, contenido in archivos:
                paquete.writestr(nombre_archivo, contenido)

        sufijo = re.sub(r"[^A-Za-z0-9_-]+", "_", nodo.clave).strip("_")
        marca_anonimo = "_anonimizado" if "anonimizar" in opciones_validas(opciones) else ""
        return ArchivoExportado(
            contenido=memoria.getvalue(),
            mimetype="application/zip",
            nombre=f"historias_{sufijo}_{formato}{marca_anonimo}.zip",
        )

    def notificar_nodo(self, nodo_clave: str, agrupacion: str, tipo: str, canal: str):
        """
        Notifica a TODAS las historias del nodo elegido con una sola llamada
        (`nodo.notificar`). Devuelve (nombre_del_nodo, cantidad_enviada).
        """
        _agrupacion, raiz = self._arbol(agrupacion)
        nodo = raiz.buscar(nodo_clave or "")
        if nodo is None:
            raise NodoNoEncontrado("Selecciona una carpeta válida.")

        resultados = nodo.notificar(tipo, canal)
        for resultado in resultados:
            self._mediador.notificar(self, Evento.NOTIFICACION_ENVIADA, resultado=resultado)
        return nodo.nombre, len(resultados)

    def generar_reporte(self, agrupacion: str, nodo_clave: str = None, hoy=None) -> dict:
        """
        Reportes sobre el árbol de carpetas, opcionalmente limitados a UNA carpeta
        (`nodo_clave`; None = todo el árbol). Visitor: tres visitantes distintos
        recorren el mismo nodo y cada uno averigua algo diferente, sin que hojas
        ni carpetas tengan un método para ninguno de esos reportes:

          - VisitanteEstadisticas -> historias por tipo, estado, médico y prioridad.
          - VisitanteCompletitud  -> historias con datos clínicos sin completar.
          - VisitanteControles    -> controles vencidos, próximos y programados.

        `hoy` (un `date`) permite fijar la fecha para los controles; por defecto
        se usa la del servidor. Lanza NodoNoEncontrado si la carpeta ya no existe.
        Devuelve {"agrupacion", "nodo_clave", "nodo_nombre", "carpetas",
                  "estadisticas", "completitud", "controles"}.
        """
        agrupacion, raiz = self._arbol(agrupacion)
        nodo = raiz.buscar(nodo_clave) if nodo_clave else raiz
        if nodo is None:
            raise NodoNoEncontrado("Esa carpeta ya no existe en la estructura actual.")

        # Un visitante NUEVO por recorrido: guardan estado y no se reutilizan.
        return {
            "agrupacion": agrupacion,
            "nodo_clave": nodo.clave,
            "nodo_nombre": nodo.nombre,
            "carpetas": self._carpetas_para_selector(raiz),
            "estadisticas": nodo.aceptar(VisitanteEstadisticas()).resultado(),
            "completitud": nodo.aceptar(VisitanteCompletitud()).resultado(),
            "controles": nodo.aceptar(VisitanteControles(hoy=hoy)).resultado(),
        }

    # -----------------------------------------------------------------
    # 8) EDICIÓN CON HISTORIAL DE VERSIONES (Memento)
    # -----------------------------------------------------------------
    def datos_edicion(self, paciente_id: int) -> dict:
        """Los datos con que se pinta el formulario de edición (identidad + campos clínicos actuales)."""
        historia = HistoriaClinicaEditable(self._paciente_editable(paciente_id))
        return self._para_formulario(historia.identidad, paciente_id, historia.datos_clinicos)

    def editar_paciente(self, paciente_id: int, datos_formulario, editado_por: str) -> ResultadoOperacion:
        """
        Edita los campos clínicos de una historia. La identidad (nombre, documento,
        fecha de nacimiento) NO se toma del formulario aunque venga en él.

        Orquesta: Builder (mismas reglas de armado que el alta) -> validador del tipo de
        atención (Abstract Factory) -> instantánea del estado anterior (Memento) -> guardado
        (Singleton). La instantánea solo se guarda si el cambio se aplicó.
        Si algo falla NO se cambia nada y `resultado.datos` trae lo escrito para repintar el formulario.
        """
        paciente = self._paciente_editable(paciente_id)    # State: Atendida y Cerrada no admiten ediciones
        historia = HistoriaClinicaEditable(paciente)

        nuevos = (
            ConstructorHistoriaClinica()
            .con_datos_personales(paciente["nombre_completo"], paciente["documento"], paciente.get("fecha_nacimiento") or "")
            .con_motivo_consulta(datos_formulario.get("motivo_consulta", "").strip())
            .con_diagnostico(datos_formulario.get("diagnostico", "").strip())
            .con_tratamiento(datos_formulario.get("tratamiento", "").strip())
            .con_notas(datos_formulario.get("notas", "").strip())
            .con_tipo_atencion(
                datos_formulario.get("tipo_atencion", "consulta_general"),
                prioridad=datos_formulario.get("prioridad", "").strip() or None,
                fecha_proximo_control=datos_formulario.get("fecha_proximo_control", "").strip() or None,
            )
            .construir()
        )
        clinicos = {campo: nuevos[campo] for campo in CAMPOS_CLINICOS}

        errores = list(obtener_fabrica(clinicos["tipo_atencion"]).crear_validador().validar(datos_formulario))
        # None y "" cuentan como lo mismo: no es un cambio real.
        vacio = lambda datos: {k: (v or "") for k, v in datos.items()}
        if not errores and vacio(clinicos) == vacio(historia.datos_clinicos):
            errores.append("No hay cambios para guardar.")
        if errores:
            return ResultadoOperacion(errores=errores, datos=self._para_formulario(historia.identidad, paciente_id, clinicos))

        instantanea = historia.crear_memento(editado_por, "Antes de la edición")   # Memento: foto del estado ANTERIOR
        anterior = historia.datos_clinicos
        historia.establecer(clinicos)
        self._persistir(paciente_id, historia)
        self._versiones.guardar(paciente_id, instantanea)
        cambiados = [self._ETIQUETAS_CAMPOS[c] for c in CAMPOS_CLINICOS if vacio(anterior)[c] != vacio(clinicos)[c]]
        self._publicar(paciente_id, paciente["nombre_completo"], "edicion",
                       "Campos modificados: " + ", ".join(cambiados), editado_por)
        return ResultadoOperacion(datos=self._para_formulario(historia.identidad, paciente_id, clinicos))

    def deshacer_edicion(self, paciente_id: int, usuario: str) -> None:
        """Devuelve la historia al estado anterior a su última edición."""
        historia = HistoriaClinicaEditable(self._paciente_editable(paciente_id))
        previo = self._versiones.deshacer(paciente_id, historia.crear_memento(usuario, "Antes de deshacer"))
        if previo is None:
            raise SinVersiones("No hay ediciones que deshacer en esta historia.")
        historia.restaurar(previo)
        self._persistir(paciente_id, historia)
        self._publicar(paciente_id, historia.identidad["nombre_completo"], "deshacer", "Se deshizo la última edición", usuario)

    def rehacer_edicion(self, paciente_id: int, usuario: str) -> None:
        """Vuelve a aplicar la edición que se acaba de deshacer."""
        historia = HistoriaClinicaEditable(self._paciente_editable(paciente_id))
        siguiente = self._versiones.rehacer(paciente_id, historia.crear_memento(usuario, "Antes de rehacer"))
        if siguiente is None:
            raise SinVersiones("No hay ediciones que rehacer en esta historia.")
        historia.restaurar(siguiente)
        self._persistir(paciente_id, historia)
        self._publicar(paciente_id, historia.identidad["nombre_completo"], "rehacer", "Se rehizo la edición que estaba deshecha", usuario)

    def restaurar_version(self, paciente_id: int, version: int, usuario: str) -> None:
        """
        Lleva la historia al estado de una versión anterior. No borra nada: antes de volver
        toma una instantánea del estado actual, así que la propia restauración se puede deshacer.
        """
        historia = HistoriaClinicaEditable(self._paciente_editable(paciente_id))
        memento = self._versiones.buscar(paciente_id, version)
        if memento is None:
            raise VersionNoEncontrada("Esa versión ya no existe en el historial.")
        actual = historia.crear_memento(usuario, f"Antes de restaurar la versión {version}")
        historia.restaurar(memento)
        self._persistir(paciente_id, historia)
        self._versiones.guardar(paciente_id, actual)
        self._publicar(paciente_id, historia.identidad["nombre_completo"], "restauracion", f"Se restauró la versión {version}", usuario)

    def versiones_paciente(self, paciente_id: int) -> dict:
        """El historial de versiones de una historia (solo metadatos) y qué acciones están disponibles."""
        paciente = self._paciente_o_error(paciente_id)
        return {
            "paciente_id": paciente_id,
            "nombre_paciente": paciente["nombre_completo"],
            "documento": paciente["documento"],
            "versiones": self._versiones.versiones(paciente_id),
            "puede_deshacer": self._versiones.puede_deshacer(paciente_id),
            "puede_rehacer": self._versiones.puede_rehacer(paciente_id),
            **self._info_estado(paciente),     # State: estado actual y si la historia admite cambios
        }

    # -----------------------------------------------------------------
    # 9) CICLO DE VIDA DE LA HISTORIA (State)
    # -----------------------------------------------------------------
    def cambiar_estado(self, paciente_id: int, accion: str, usuario: str) -> str:
        """
        Ejecuta una acción del ciclo de vida (iniciar_atencion, dar_alta, cerrar, reabrir).
        El estado ACTUAL de la historia decide si la acción existe y a qué estado pasa (State).
        La acción se ejecuta como un COMANDO (Command): queda en el historial del usuario y
        se puede deshacer. Los seguidores de la historia reciben un aviso (Observer).
        Devuelve el nombre del estado nuevo.
        """
        comando = ComandoCambiarEstado(self._db, paciente_id, accion)
        self._invocar(usuario, "ejecutar", comando)
        return comando.estado_nuevo

    def cambiar_estado_nodo(self, nodo_clave: str, agrupacion: str, accion: str, usuario: str):
        """
        Aplica una acción del ciclo de vida a TODAS las historias de una carpeta, como UN solo
        comando macro (Command + Composite): se deshace de una vez y es atómico (si una historia
        falla, ninguna cambia). Las historias cuyo estado actual no ofrece la acción se omiten.
        Devuelve (nombre_de_la_carpeta, aplicadas, omitidas).
        """
        _agrupacion, raiz = self._arbol(agrupacion)
        nodo = raiz.buscar(nodo_clave or "")
        if nodo is None:
            raise NodoNoEncontrado("Selecciona una carpeta válida.")

        aplicables, omitidas = [], 0
        for paciente in nodo.obtener_historias():
            ciclo = CicloVidaHistoria(paciente.get("estado_atencion"))
            if accion in dict(ciclo.acciones_disponibles()):
                aplicables.append(ComandoCambiarEstado(self._db, paciente["id"], accion))
            else:
                omitidas += 1
        if not aplicables:
            raise TransicionNoPermitida("Ninguna historia de esa carpeta admite esa acción en su estado actual.")

        texto = dict(self.acciones_estado).get(accion, accion)
        macro = ComandoMacro(aplicables, f"«{texto}» en la carpeta «{nodo.nombre}» ({len(aplicables)} historias)")
        self._invocar(usuario, "ejecutar", macro)
        return nodo.nombre, len(aplicables), omitidas

    def deshacer_comando(self, usuario: str) -> str:
        """Deshace la última acción de ciclo de vida de ESTE usuario (Command). Devuelve su descripción."""
        return self._invocar(usuario, "deshacer").descripcion

    def rehacer_comando(self, usuario: str) -> str:
        """Rehace la última acción deshecha por ESTE usuario (Command). Devuelve su descripción."""
        return self._invocar(usuario, "rehacer").descripcion

    def comandos_recientes(self, usuario: str) -> dict:
        """Historial de acciones del usuario y qué puede deshacer o rehacer (Command)."""
        return self._comandos.resumen(usuario)

    def _invocar(self, usuario: str, operacion: str, comando=None):
        """
        Command: pasa la operación por el historial (invocador), traduce los errores del comando
        a errores de la fachada y avisa a los seguidores (Observer) de cada historia afectada.
        """
        try:
            if operacion == "ejecutar":
                comando = self._comandos.ejecutar(usuario, comando)
            else:
                comando = getattr(self._comandos, operacion)(usuario)
        except ComandoPacienteNoEncontrado as error:
            raise PacienteNoEncontrado(str(error)) from None
        except ErrorComando as error:
            raise TransicionNoPermitida(str(error)) from None
        for paciente_id, nombre, detalle in comando.cambios:
            self._publicar(paciente_id, nombre, "estado", detalle, usuario)
        return comando

    # -----------------------------------------------------------------
    # 10) SEGUIMIENTO DE HISTORIAS Y AVISOS (Observer)
    # -----------------------------------------------------------------
    def seguir_paciente(self, paciente_id: int, usuario: str) -> bool:
        """Suscribe al usuario a los cambios de la historia. False si ya la seguía."""
        self._paciente_o_error(paciente_id)
        return self._seguimiento.seguir(usuario, paciente_id)

    def dejar_de_seguir(self, paciente_id: int, usuario: str) -> bool:
        """Cancela la suscripción (los avisos ya recibidos se conservan). False si no la seguía."""
        self._paciente_o_error(paciente_id)
        return self._seguimiento.dejar_de_seguir(usuario, paciente_id)

    def pacientes_seguidos(self, usuario: str) -> set:
        """Los ids de las historias que el usuario sigue."""
        return self._seguimiento.pacientes_seguidos(usuario)

    def avisos_de(self, usuario: str, limite: int = 50) -> list:
        """La bandeja de avisos del usuario, el más reciente primero."""
        return self._seguimiento.bandeja(usuario).avisos(limite)

    def avisos_sin_leer(self, usuario: str) -> int:
        return self._seguimiento.bandeja(usuario).sin_leer()

    def marcar_avisos_leidos(self, usuario: str) -> int:
        """Marca todos los avisos como leídos. Devuelve cuántos estaban sin leer."""
        return self._seguimiento.bandeja(usuario).marcar_leidos()

    # -----------------------------------------------------------------
    # Pasos internos compartidos (la "coreografía" que antes se repetía)
    # -----------------------------------------------------------------
    @staticmethod
    def _dar_de_alta(proceso, registrado_por: str) -> ResultadoOperacion:
        """Template Method: ejecuta el proceso de alta y traduce su resultado al de la fachada."""
        resultado = proceso.ejecutar(registrado_por)
        return ResultadoOperacion(errores=resultado.errores, datos=resultado.datos)

    def _avisar_alta(self, datos: dict) -> None:
        """
        Mediator: la fachada solo AVISA del alta; quién reacciona (la notificación automática,
        el historial...) lo decide el mediador, no este método. Es el callback del proceso de alta.
        """
        self._mediador.notificar(self, Evento.PACIENTE_REGISTRADO, paciente=datos)

    def _paciente_o_error(self, paciente_id: int) -> dict:
        paciente = self._db.obtener_paciente(paciente_id)
        if paciente is None:
            raise PacienteNoEncontrado("Paciente no encontrado.")
        return paciente

    def _paciente_editable(self, paciente_id: int) -> dict:
        """State: el paciente, o HistoriaNoEditable si su estado actual (Atendida/Cerrada) no admite cambios."""
        paciente = self._paciente_o_error(paciente_id)
        ciclo = CicloVidaHistoria(paciente.get("estado_atencion"))
        if not ciclo.puede_editar():
            raise HistoriaNoEditable(ciclo.estado.motivo_bloqueo())
        return paciente

    @staticmethod
    def _info_estado(paciente: dict) -> dict:
        """State: lo que las pantallas necesitan saber del estado de una historia."""
        ciclo = CicloVidaHistoria(paciente.get("estado_atencion"))
        return {"estado_etiqueta": ciclo.estado.etiqueta, "estado_clase": ciclo.estado.clase_css,
                "puede_editar": ciclo.puede_editar(), "acciones_estado": ciclo.acciones_disponibles()}

    # -----------------------------------------------------------------
    # OBJETIVOS DEL PROYECTO: citas, eliminación, signos vitales, interacciones
    # -----------------------------------------------------------------
    def medicos_disponibles(self) -> list:
        """Usuarios que pueden atender citas (médicos y administradores): [{'usuario', 'nombre_completo'}]."""
        return self._db.listar_usuarios_por_rol(("medico", "administrador"))

    def programar_cita(self, paciente_id: int, datos, usuario: str) -> ResultadoOperacion:
        """
        Programa una cita médica. Valida: paciente existente, fecha real y no pasada, hora HH:MM,
        médico válido y que ese médico no tenga ya otra cita programada a esa misma fecha y hora.
        Devuelve ResultadoOperacion; en `datos` queda lo que escribió el usuario.
        """
        paciente = self._paciente_o_error(paciente_id)
        fecha, hora = (datos.get("fecha") or "").strip(), (datos.get("hora") or "").strip()
        medico, motivo = (datos.get("medico") or "").strip(), (datos.get("motivo") or "").strip()
        errores = []
        try:
            if datetime.date.fromisoformat(fecha) < datetime.date.today():
                errores.append("La fecha de la cita no puede estar en el pasado.")
        except ValueError:
            errores.append("La fecha de la cita no es válida (usa AAAA-MM-DD).")
        try:
            datetime.datetime.strptime(hora, "%H:%M")
        except ValueError:
            errores.append("La hora de la cita no es válida (usa HH:MM).")
        if medico not in {m["usuario"] for m in self.medicos_disponibles()}:
            errores.append("Selecciona un médico válido.")
        if not errores and self._db.existe_cita_programada(medico, fecha, hora):
            errores.append("Ese médico ya tiene una cita programada a esa fecha y hora.")
        if errores:
            return ResultadoOperacion(errores=errores, datos={"fecha": fecha, "hora": hora, "medico": medico, "motivo": motivo})
        cita_id = self._db.crear_cita(paciente["id"], fecha, hora, medico, motivo, usuario)
        return ResultadoOperacion(datos={"cita_id": cita_id, "nombre_paciente": paciente["nombre_completo"]})

    def listar_citas(self, paciente_id: int = None, estado: str = None) -> list:
        """Citas (más próximas primero) con el nombre del paciente y del médico ya resueltos."""
        nombres_medicos = {m["usuario"]: m["nombre_completo"] for m in self.medicos_disponibles()}
        pacientes = {}
        citas = self._db.obtener_citas(paciente_id, estado)
        for cita in citas:
            if cita["paciente_id"] not in pacientes:
                p = self._db.obtener_paciente(cita["paciente_id"])
                pacientes[cita["paciente_id"]] = p["nombre_completo"] if p else "(paciente eliminado)"
            cita["nombre_paciente"] = pacientes[cita["paciente_id"]]
            cita["nombre_medico"] = nombres_medicos.get(cita["medico"], cita["medico"])
        return citas

    def cambiar_estado_cita(self, cita_id: int, nuevo_estado: str, usuario: str) -> str:
        """Marca una cita programada como cumplida o cancelada. Solo se puede cambiar una cita programada."""
        cita = self._db.obtener_cita(cita_id)
        if cita is None:
            raise PacienteNoEncontrado("Cita no encontrada.")
        if nuevo_estado not in ("cumplida", "cancelada"):
            raise TransicionNoPermitida("Estado de cita no válido.")
        if cita["estado"] != "programada":
            raise TransicionNoPermitida(f"La cita ya está {cita['estado']}: no se puede cambiar.")
        self._db.actualizar_estado_cita(cita_id, nuevo_estado)
        return nuevo_estado

    def eliminar_paciente(self, paciente_id: int, usuario: str) -> str:
        """
        Elimina la historia clínica y sus citas y signos vitales (solo administradores, ver PERMISOS).
        Queda constancia en la bitácora de eliminaciones. Devuelve el nombre del paciente eliminado.
        """
        paciente = self._db.eliminar_paciente(paciente_id, usuario)
        if paciente is None:
            raise PacienteNoEncontrado("Paciente no encontrado.")
        return paciente["nombre_completo"]

    def registrar_signos(self, paciente_id: int, datos, usuario: str,
                         origen: str = "manual", dispositivo: str = None) -> ResultadoOperacion:
        """
        Registra una lectura de signos vitales en la historia del paciente (formulario o dispositivo).
        Valida rangos; si hay valores fuera de rango, `resultado.datos["alertas"]` los lista y se avisa
        a quienes siguen la historia (Observer). En `datos` también va el id de la lectura.
        """
        paciente = self._paciente_o_error(paciente_id)
        lectura, errores = validar_lectura(datos)
        if errores:
            return ResultadoOperacion(errores=errores, datos=dict(datos))
        lectura_id = self._db.crear_signos(paciente["id"], lectura, origen, dispositivo, usuario)
        alertas = evaluar_alertas(lectura)
        if alertas:
            self._publicar(paciente["id"], paciente["nombre_completo"], "signos",
                           "Signos vitales fuera de rango: " + " ".join(t for _, t in alertas), usuario)
        return ResultadoOperacion(datos={"lectura_id": lectura_id, "alertas": alertas, "lectura": lectura})

    def registrar_signos_dispositivo(self, documento: str, datos, dispositivo: str) -> ResultadoOperacion:
        """
        Entrada de los dispositivos IoT: identifica al paciente por documento y guarda la lectura con
        origen 'dispositivo'. NO pasa por el Proxy de protección porque no hay un usuario con rol: la
        ruta /api/signos la autentica con la clave de API.
        """
        paciente = self._db.obtener_paciente_por_documento((documento or "").strip())
        if paciente is None:
            raise PacienteNoEncontrado("No hay un paciente con ese documento.")
        return self.registrar_signos(paciente["id"], datos, f"dispositivo:{dispositivo or 'desconocido'}",
                                     origen="dispositivo", dispositivo=dispositivo)

    def signos_de(self, paciente_id: int, limite: int = 10) -> list:
        """Últimas lecturas del paciente, cada una con sus alertas ya evaluadas."""
        lecturas = self._db.obtener_signos(paciente_id, limite)
        for lectura in lecturas:
            lectura["alertas"] = evaluar_alertas({k: v for k, v in lectura.items() if k in CAMPOS_SIGNOS and v is not None})
        return lecturas

    def interacciones_de(self, paciente_id: int) -> list:
        """Interacciones medicamentosas detectadas en el tratamiento del paciente (más graves primero)."""
        return buscar_interacciones(self._paciente_o_error(paciente_id).get("tratamiento"))

    def detalle_paciente(self, paciente_id: int) -> dict:
        """Todo lo de UN paciente para su página: historia, signos vitales, citas e interacciones."""
        self._paciente_o_error(paciente_id)
        paciente = next(p for p in self.listar_pacientes_enriquecidos() if p["id"] == paciente_id)
        return {
            "paciente": paciente,
            "signos": self.signos_de(paciente_id),
            "citas": self.listar_citas(paciente_id),
            "interacciones": paciente["alertas_interaccion"],
            "medicos": self.medicos_disponibles(),
        }

    def cuenta_bloqueada(self, usuario: str) -> bool:
        """¿Esta cuenta está bloqueada temporalmente por demasiados intentos fallidos?"""
        return self._db.cuenta_bloqueada(usuario)

    def _publicar(self, paciente_id: int, nombre: str, tipo: str, detalle: str, autor: str) -> None:
        """Observer: avisa del cambio a quienes siguen la historia (un observador roto no afecta la operación)."""
        self._seguimiento.publicar(CambioHistoria(paciente_id, nombre, tipo, detalle, autor))

    def _persistir(self, paciente_id: int, historia: HistoriaClinicaEditable) -> None:
        """Guarda en la base de datos el estado clínico actual del originador."""
        if not self._db.actualizar_historia_clinica(paciente_id, **historia.datos_clinicos):
            raise PacienteNoEncontrado("Paciente no encontrado.")

    @staticmethod
    def _para_formulario(identidad: dict, paciente_id: int, clinicos: dict) -> dict:
        """Datos listos para la plantilla de edición: sin None (que se pintaría como 'None')."""
        datos = {"paciente_id": paciente_id, "nombre_paciente": identidad["nombre_completo"],
                 "documento": identidad["documento"], "fecha_nacimiento": identidad["fecha_nacimiento"], **clinicos}
        return {k: ("" if v is None else v) for k, v in datos.items()}

    def _creador(self, formato: str):
        """Factory Method: el creador concreto del formato, o FormatoNoSoportado."""
        try:
            return obtener_creador(formato)
        except ValueError:
            raise FormatoNoSoportado("Formato de exportación no soportado.") from None

    def _envolturas(self, opciones, usuario: str) -> list:
        """
        Decorator: traduce las casillas marcadas a la lista de envolturas
        (anonimizar -> sellar -> auditar). La auditoría se agrega SIEMPRE,
        con la bitácora del Singleton.
        """
        return decoradores_para(
            opciones_validas(opciones),
            usuario=usuario,
            registrar=self._db.registrar_exportacion,
        )

    @staticmethod
    def _carpetas_para_selector(raiz) -> list:
        """Composite + Iterator: las carpetas del árbol como (texto con sangría, clave), para un <select>."""
        return [
            ("\u00a0\u00a0\u00a0" * nivel + nodo.nombre, nodo.clave)
            for nivel, nodo in raiz.recorrer() if nodo.es_grupo
        ]

    def _arbol(self, agrupacion: str):
        """
        Composite: construye el árbol con los pacientes actuales. Se
        reconstruye en cada llamada para reflejar altas e importaciones recientes.
        Devuelve (agrupacion_efectiva, raiz).
        """
        agrupacion = self.normalizar_agrupacion(agrupacion)
        return agrupacion, construir_arbol(self._db.obtener_pacientes(), agrupacion)


if __name__ == "__main__":
    # Demostración sin Flask y sin tocar tu base de datos real: usa una BD
    # temporal. Fíjate en que TODO el recorrido usa un único objeto (`fachada`)
    # y ningún otro módulo de patrones.
    import os
    import tempfile

    carpeta = tempfile.mkdtemp()
    # La primera llamada al Singleton fija la ruta; la fachada reutilizará esa instancia.
    DatabaseManager(db_path=os.path.join(carpeta, "demo_fachada.db"))
    fachada = FachadaSHCE()

    print("1) Login:", "OK" if fachada.iniciar_sesion("admin", "Admin123") else "FALLÓ")

    formulario = {
        "nombre_completo": "Ana Ruiz", "documento": "5550001", "fecha_nacimiento": "1990-01-01",
        "motivo_consulta": "Dificultad respiratoria", "tipo_atencion": "urgencias", "prioridad": "alta",
    }
    resultado = fachada.registrar_paciente(formulario, registrado_por="admin")
    print("2) Registrar urgencia:", "creada" if resultado.exitoso else resultado.errores)
    print("   Repetirla:", fachada.registrar_paciente(formulario, registrado_por="admin").errores)

    resultado = fachada.importar_desde_externo("EXT-001", registrado_por="admin")
    print("3) Importar EXT-001:", "importada" if resultado.exitoso else resultado.errores)

    for paciente in fachada.listar_pacientes_enriquecidos()[:3]:
        print(f"4) {paciente['nombre_completo']:<24} {paciente['edad']} años  [{paciente['etiqueta_atencion']}]")

    paciente_id = fachada.listar_pacientes()[0]["id"]
    archivo = fachada.exportar_paciente(paciente_id, "txt", ["anonimizar", "sello"], usuario="admin")
    print(f"5) Exportación anonimizada y sellada: {archivo.nombre} ({archivo.mimetype}, {len(archivo.contenido)} bytes)")

    estructura = fachada.consultar_estructura("tipo")
    print("6) Carpetas:", [nombre.strip() for nombre, _ in estructura["grupos"]])
    zip_carpeta = fachada.exportar_nodo("csv", None, "tipo", usuario="admin")
    print(f"   Exportar todo el árbol: {zip_carpeta.nombre}")
    print("   Notificar la raíz:", fachada.notificar_nodo("raiz", "tipo", "informativa", "consola"))

    print("7) Historial de notificaciones:", len(fachada.historial_notificaciones(limite=50)))

    try:
        fachada.exportar_paciente(paciente_id, "docx")
    except ErrorFachada as error:
        print("8) Error esperable ->", type(error).__name__ + ":", error)

"""
signos_vitales.py
-----------------
Validación y evaluación de SIGNOS VITALES (Objetivo 2). Sirve igual para lo que
llega por el formulario manual que para lo que envía un dispositivo (real o el
simulador `simulador_iot.py`):

  - `validar_lectura`  -> convierte el texto/JSON recibido en números y rechaza los
                          valores imposibles (un dato corrupto no entra a la historia).
  - `evaluar_alertas`  -> compara con rangos clínicos de referencia y devuelve avisos
                          («atención» o «crítica»). Son rangos orientativos para adultos.
"""

#: campo -> (tipo, mínimo plausible, máximo plausible, etiqueta, unidad)
CAMPOS = {
    "frecuencia_cardiaca": (int, 20, 250, "La frecuencia cardiaca", "lpm"),
    "presion_sistolica": (int, 50, 260, "La presión sistólica", "mmHg"),
    "presion_diastolica": (int, 30, 160, "La presión diastólica", "mmHg"),
    "temperatura": (float, 30.0, 45.0, "La temperatura", "°C"),
    "saturacion_o2": (int, 50, 100, "La saturación de oxígeno", "%"),
    "glucosa": (int, 20, 800, "La glucosa", "mg/dL"),
}


def validar_lectura(datos) -> tuple:
    """
    `datos`: cualquier mapeo con `.get` (formulario o JSON). Devuelve (lectura, errores):
    `lectura` solo trae los campos presentes y válidos, ya convertidos a número.
    """
    lectura, errores = {}, []
    for campo, (tipo, minimo, maximo, etiqueta, unidad) in CAMPOS.items():
        crudo = datos.get(campo)
        if crudo is None or str(crudo).strip() == "":
            continue
        try:
            valor = tipo(str(crudo).strip().replace(",", "."))
        except ValueError:
            errores.append(f"{etiqueta} debe ser un número.")
            continue
        if not (minimo <= valor <= maximo):
            errores.append(f"{etiqueta} debe estar entre {minimo} y {maximo} {unidad}.")
            continue
        lectura[campo] = valor

    sistolica, diastolica = lectura.get("presion_sistolica"), lectura.get("presion_diastolica")
    if (sistolica is None) != (diastolica is None) and not errores:
        errores.append("La presión arterial necesita la sistólica y la diastólica.")
    elif sistolica is not None and diastolica is not None and sistolica <= diastolica:
        errores.append("La presión sistólica debe ser mayor que la diastólica.")
    if not lectura and not errores:
        errores.append("Indica al menos un signo vital.")
    return lectura, errores


def evaluar_alertas(lectura: dict) -> list:
    """Lista de (nivel, texto) con nivel 'critica' o 'atencion'; vacía si todo está en rango."""
    alertas = []

    def agregar(nivel, texto):
        alertas.append((nivel, texto))

    fc = lectura.get("frecuencia_cardiaca")
    if fc is not None:
        if fc < 40 or fc > 140:
            agregar("critica", f"Frecuencia cardiaca {fc} lpm: fuera de rango crítico.")
        elif fc < 50 or fc > 120:
            agregar("atencion", f"Frecuencia cardiaca {fc} lpm: fuera del rango normal.")

    spo2 = lectura.get("saturacion_o2")
    if spo2 is not None:
        if spo2 < 88:
            agregar("critica", f"Saturación de oxígeno {spo2} %: hipoxemia grave.")
        elif spo2 < 92:
            agregar("atencion", f"Saturación de oxígeno {spo2} %: baja.")

    temp = lectura.get("temperatura")
    if temp is not None:
        if temp >= 39.5:
            agregar("critica", f"Temperatura {temp} °C: fiebre alta.")
        elif temp >= 38:
            agregar("atencion", f"Temperatura {temp} °C: fiebre.")
        elif temp < 35.5:
            agregar("atencion", f"Temperatura {temp} °C: baja.")

    pas, pad = lectura.get("presion_sistolica"), lectura.get("presion_diastolica")
    if pas is not None and pad is not None:
        if pas >= 180 or pad >= 120:
            agregar("critica", f"Presión arterial {pas}/{pad} mmHg: crisis hipertensiva.")
        elif pas >= 140 or pad >= 90:
            agregar("atencion", f"Presión arterial {pas}/{pad} mmHg: elevada.")
        elif pas < 90:
            agregar("atencion", f"Presión arterial {pas}/{pad} mmHg: baja.")

    glucosa = lectura.get("glucosa")
    if glucosa is not None:
        if glucosa < 54 or glucosa > 300:
            agregar("critica", f"Glucosa {glucosa} mg/dL: fuera de rango crítico.")
        elif glucosa < 70 or glucosa > 180:
            agregar("atencion", f"Glucosa {glucosa} mg/dL: fuera del rango normal.")
    return alertas


if __name__ == "__main__":
    for crudo in ({"frecuencia_cardiaca": "72", "temperatura": "36,8", "saturacion_o2": "98"},
                  {"frecuencia_cardiaca": "150", "saturacion_o2": "85", "presion_sistolica": "190", "presion_diastolica": "125"},
                  {"frecuencia_cardiaca": "abc"}, {"temperatura": "80"}, {}):
        lectura, errores = validar_lectura(crudo)
        print(crudo, "->", errores or lectura, [t for _, t in evaluar_alertas(lectura)])

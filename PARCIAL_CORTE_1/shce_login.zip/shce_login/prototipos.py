"""
prototipos.py
--------------
Implementación del patrón de diseño PROTOTYPE, aplicado a clonar una
historia clínica EXISTENTE para usarla como punto de partida de una
consulta nueva del mismo paciente (ej. un control de seguimiento que
repite casi todo: mismo diagnóstico base, mismo tratamiento, mismo tipo
de atención, y solo cambian un par de cosas puntuales).

¿Por qué Prototype aquí?
En una consulta de seguimiento, el médico casi siempre parte de la
historia anterior del paciente en vez de escribir todo desde cero. En
vez de que la ruta de Flask copie campo por campo (y se le pueda olvidar
alguno, o copie por error algo que NO debería repetirse, como el
documento), el propio objeto "sabe clonarse a sí mismo" y sabe qué
campos tienen sentido conservar y cuáles no.

Esto es justo la idea de Prototype: en vez de reconstruir un objeto
complejo desde cero, se copia uno existente (más barato y menos
propenso a errores) y se ajustan solo los detalles que cambian.

Estructura del patrón en este archivo:
  Prototipo -> HistoriaClinicaPrototype, con su método clonar()
"""

import copy


class HistoriaClinicaPrototype(object):
    """
    Envuelve el diccionario de una historia clínica (tal como lo
    devuelve DatabaseManager.obtener_paciente) y sabe clonarse a sí
    misma, en vez de que el código cliente tenga que copiar campo por
    campo.
    """

    #: Campos que tiene sentido heredar de una historia clínica anterior
    #: al usarla como plantilla para una consulta nueva.
    CAMPOS_PLANTILLA = [
        "nombre_completo", "documento", "fecha_nacimiento", "motivo_consulta",
        "diagnostico", "tratamiento", "notas", "tipo_atencion",
        "prioridad", "fecha_proximo_control",
    ]

    def __init__(self, datos: dict):
        self.datos = datos

    def clonar(self) -> "HistoriaClinicaPrototype":
        """
        EL MÉTODO DEL PATRÓN: devuelve una copia INDEPENDIENTE y
        profunda de esta historia clínica. copy.deepcopy() asegura que,
        si "datos" tuviera listas o diccionarios anidados, también se
        copien de verdad (y no queden compartidos por referencia con el
        original: modificar el clon jamás debe tocar el original).
        """
        return HistoriaClinicaPrototype(copy.deepcopy(self.datos))

    def como_plantilla_nueva(self) -> dict:
        """
        Clona esta historia y la deja lista para usarse como plantilla
        de una consulta NUEVA del mismo paciente (por ejemplo, un
        control de seguimiento):

          - Conserva: nombre, diagnóstico, tratamiento, tipo de atención...
            (lo que normalmente se repite entre una cita y la siguiente).
          - Limpia el documento: es UNIQUE en la base de datos, así que
            jamás debe copiarse tal cual; el usuario debe confirmarlo o
            escribir uno nuevo.
          - Limpia las notas: son específicas de la cita anterior, no
            tiene sentido heredarlas para la consulta nueva.
        """
        clon = self.clonar()

        # Nos quedamos solo con los campos relevantes para el formulario
        # de "nueva historia clínica" (el paciente original trae además
        # id, registrado_por, creado_en, edad... que aquí no aplican).
        plantilla = {
            campo: (clon.datos.get(campo) or "")
            for campo in self.CAMPOS_PLANTILLA
        }

        plantilla["documento"] = ""  # nunca se copia: es único por paciente
        plantilla["notas"] = ""      # las notas de la cita anterior no se heredan

        return plantilla


if __name__ == "__main__":
    # Demostración: clonar una historia y comprobar que el clon es
    # independiente del original (modificar uno no afecta al otro).
    historia_original = {
        "id": 1,
        "nombre_completo": "Carlos Andrés Pérez",
        "documento": "1012345678",
        "fecha_nacimiento": "1985-11-02",
        "motivo_consulta": "Control post-quirúrgico",
        "diagnostico": "Recuperación favorable de apendicectomía",
        "tratamiento": "Analgésico según necesidad",
        "notas": "Sin signos de infección en la herida.",
        "tipo_atencion": "control",
        "prioridad": None,
        "fecha_proximo_control": "2026-10-05",
        "registrado_por": "brayan",
        "creado_en": "2026-09-01 10:00:00",
    }

    prototipo = HistoriaClinicaPrototype(historia_original)
    plantilla = prototipo.como_plantilla_nueva()

    print("Original  :", historia_original["documento"], "|", historia_original["diagnostico"])
    print("Plantilla :", repr(plantilla["documento"]), "|", plantilla["diagnostico"])

    # Comprobamos que modificar el clon NO afecta al original (independencia real).
    plantilla["diagnostico"] = "Diagnóstico distinto en el clon"
    print("Original tras modificar el clon:", historia_original["diagnostico"])
    assert historia_original["diagnostico"] != plantilla["diagnostico"]
    print("Clonación independiente confirmada (deepcopy funcionando).")

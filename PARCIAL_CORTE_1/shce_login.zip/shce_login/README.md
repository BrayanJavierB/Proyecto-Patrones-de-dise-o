# SHCE — Sistema de Historias Clínicas Electrónicas (prototipo local)

Prototipo local (Flask + SQLite) del SHCE: login, registro de usuarios,
y un módulo de pacientes que permite registrar historias clínicas por
tipo de atención, clonarlas como plantilla para una consulta nueva, y
exportarlas en PDF, TXT o CSV.

Implementa cinco patrones de diseño: **Singleton**, **Factory Method**,
**Abstract Factory**, **Builder** y **Prototype** (explicados más abajo).

## Cómo ejecutarlo

```bash
cd shce_login
python3 -m venv venv && source venv/bin/activate   # opcional pero recomendado
pip install -r requirements.txt
python3 app.py
```

Abre **http://127.0.0.1:5000** en tu navegador.

Usuarios de prueba (se crean automáticamente la primera vez):

| Usuario | Contraseña   | Rol            |
|---------|--------------|----------------|
| admin   | Admin123     | administrador  |
| brayan  | Medico123    | medico         |

También puedes crear tu propia cuenta desde **"¿No tienes cuenta? Regístrate aquí"**
en la pantalla de login, o entrando directo a `/registro`.

La base de datos local `shce_local.db` (SQLite) se crea sola en la primera
ejecución, con **3 pacientes de ejemplo** ya cargados (uno de cada tipo de
atención: consulta general, control y urgencias) para que puedas probar
la exportación sin crear uno a mano.

## Estructura

```
shce_login/
├── app.py                  # rutas Flask: login, registro, dashboard, pacientes, exportar, duplicar
├── singleton.py             # DatabaseManager (patrón Singleton): usuarios + pacientes
├── exportadores.py          # patrón Factory Method: exportar historias en PDF/TXT/CSV
├── fabricas.py               # patrón Abstract Factory: familias validador+formateador por tipo de atención
├── constructor_historia.py   # patrón Builder: arma paso a paso los datos de una historia clínica
├── prototipos.py              # patrón Prototype: clona una historia clínica como plantilla
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── _macros.html         # macro reutilizable del campo de contraseña
│   ├── _topbar.html         # barra de navegación compartida (Panel / Pacientes)
│   ├── login.html
│   ├── registro.html
│   ├── dashboard.html
│   ├── pacientes.html       # listado + badge de tipo de atención + exportar + "usar como plantilla"
│   └── paciente_nuevo.html  # formulario (también recibe plantillas del Prototype)
└── static/
    ├── css/style.css
    └── js/main.js            # icono de ojo + mostrar/ocultar campos condicionales del formulario
```

## ¿Dónde está el patrón Singleton?

En `singleton.py`, la clase `SingletonMeta` es una **metaclase** que
intercepta la creación de instancias. Cualquier clase que la use
(`class DatabaseManager(metaclass=SingletonMeta)`) queda garantizada a tener
**una sola instancia viva** durante toda la ejecución del programa,
sin importar cuántas veces se escriba `DatabaseManager()`.

Por qué tiene sentido en un SHCE:
- Solo debe existir **una** conexión activa a la base de datos (usuarios y pacientes).
- Toda validación de credenciales y toda auditoría de accesos (tabla
  `bitacora_accesos`) pasa por el mismo punto central.
- Es thread-safe (usa `Lock`), pensado para cuando Flask maneje varias
  peticiones al mismo tiempo.

## ¿Dónde está el patrón Factory Method?

En `exportadores.py`. Cuando alguien pide exportar una historia clínica
en PDF, TXT o CSV, la ruta `/pacientes/<id>/exportar/<formato>` de
`app.py` no sabe (ni le importa) cómo se construye cada tipo de archivo.

- `CreadorExportador` es el **creador abstracto**: define el flujo general
  (`exportar_historia`) sin conocer el formato concreto.
- `CreadorPDF`, `CreadorTXT`, `CreadorCSV` son los **creadores concretos**:
  cada uno sobrescribe el **método fábrica** `crear_exportador()` para
  devolver el objeto exportador que le corresponde
  (`ExportadorPDF`, `ExportadorTXT`, `ExportadorCSV`).
- `obtener_creador("pdf")` es solo un diccionario de búsqueda que traduce
  el string del formulario al Creador concreto correcto — eso NO es el
  patrón en sí, es el punto de entrada cómodo.

Ventaja práctica: agregar un formato nuevo (ej. Word) solo exige crear
`ExportadorWord` + `CreadorWord`, sin tocar el código de PDF/TXT/CSV.

## ¿Dónde está el patrón Abstract Factory?

En `fabricas.py`. La diferencia clave con Factory Method: aquí cada
"tipo de atención" (Consulta General, Urgencias, Control) no necesita
UN solo objeto, sino una **familia de dos objetos relacionados que deben
coincidir entre sí**:

1. Un **`ValidadorAtencion`** — sabe qué campos extra exige ese tipo
   (Urgencias exige `prioridad`, Control exige `fecha_proximo_control`).
2. Un **`FormateadorAtencion`** — sabe construir la etiqueta corta que se
   ve en el listado y en las exportaciones (ej. `"Urgencia · Prioridad alta"`),
   junto con su color de badge.

La jerarquía:
- `FabricaAtencion` es la **fábrica abstracta**: declara `crear_validador()`
  y `crear_formateador()`, sin saber a qué tipo de atención pertenecen.
- `FabricaConsultaGeneral`, `FabricaUrgencias`, `FabricaControl` son las
  **fábricas concretas**: cada una construye la pareja validador+formateador
  que le corresponde a SU tipo, garantizando que nunca queden mezclados
  (ej. nunca se valida como "Urgencias" pero se muestra la etiqueta de "Control").
- `obtener_fabrica("urgencias")` es, igual que en Factory Method, solo el
  punto de entrada cómodo — el patrón está en la jerarquía de clases.

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_nuevo()`: pide el **validador** de la fábrica
  para exigir los campos correctos según el tipo de atención elegido.
- `app.py` → ruta `pacientes()`: pide el **formateador** de la fábrica
  para mostrar el badge (texto + color) de cada paciente en el listado.
- `exportadores.py` → reutiliza la misma fábrica para incluir la etiqueta
  de tipo de atención dentro del PDF/TXT/CSV exportado, así los tres
  patrones (Singleton, Factory Method, Abstract Factory) trabajan juntos
  sin pisarse.

Ventaja práctica: agregar un tipo de atención nuevo (ej. "Hospitalización")
solo exige crear su `ValidadorHospitalizacion` + `FormateadorHospitalizacion`
+ `FabricaHospitalizacion`, sin tocar el código de los tipos existentes.

## ¿Dónde está el patrón Builder?

En `constructor_historia.py`. Una historia clínica tiene muchos campos
(11 en total). En vez de pasar todos de golpe como parámetros sueltos
(fácil de desordenar y difícil de leer), `ConstructorHistoriaClinica`
los arma **paso a paso**, encadenando métodos:

```python
ConstructorHistoriaClinica()
    .con_datos_personales("Ana Ruiz", "123", "1990-01-01")
    .con_motivo_consulta("Chequeo anual")
    .con_tipo_atencion("consulta_general")
    .construir()
```

Cada `con_xxx(...)` configura una parte y devuelve `self` (para poder
encadenar); `construir()` es el único método que entrega el diccionario
final ya completo.

`DirectorHistoriaClinica` va un paso más allá: conoce "recetas" para los
casos más comunes (`construir_urgencia_basica`, `construir_control_seguimiento`)
y arma toda la secuencia de pasos por dentro, para que el código que solo
necesita un caso típico no tenga que repetirla.

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_nuevo()`: arma los datos del formulario con
  el Builder en vez de un diccionario literal.
- `singleton.py` → `_sembrar_usuarios_iniciales()`: arma los 3 pacientes
  de ejemplo, mostrando las dos formas de uso (manual, y con el Director).

## ¿Dónde está el patrón Prototype?

En `prototipos.py`. Pensado para el caso típico de "el paciente vuelve
por lo mismo": en una consulta de seguimiento, casi todo se repite
(diagnóstico base, tratamiento, tipo de atención) y solo cambian un par
de detalles. En vez de que el código copie campo por campo (arriesgándose
a copiar por error algo que NO debería repetirse, como el documento),
`HistoriaClinicaPrototype` sabe **clonarse a sí misma**:

- `clonar()` — devuelve una copia profunda e independiente
  (`copy.deepcopy`) de la historia clínica. Modificar el clon nunca
  afecta al original.
- `como_plantilla_nueva()` — clona y además limpia los campos que nunca
  deben heredarse tal cual: el `documento` (es único en la base de
  datos) y las `notas` (son específicas de la cita anterior).

**Dónde se usa en el código:**
- `app.py` → ruta `paciente_duplicar()` (`/pacientes/<id>/duplicar`):
  toma un paciente existente, lo envuelve en el prototipo, pide la
  plantilla, y precarga con ella el formulario de "nueva historia clínica".
- `pacientes.html` → el enlace **"↻ Usar como plantilla para nueva consulta"**
  en cada fila dispara esa ruta.

## Cómo colaboran los cinco patrones

Un flujo completo, de principio a fin, usando los cinco:

1. **Singleton** (`singleton.py`) garantiza que solo hay una conexión a la base de datos.
2. **Builder** (`constructor_historia.py`) arma los datos de una historia clínica nueva, paso a paso.
3. **Abstract Factory** (`fabricas.py`) valida esos datos según el tipo de atención, y luego calcula la etiqueta/color con la que se muestran.
4. **Prototype** (`prototipos.py`) permite clonar esa historia como punto de partida de la siguiente consulta del mismo paciente.
5. **Factory Method** (`exportadores.py`) genera el PDF/TXT/CSV cuando el usuario quiere descargar cualquiera de esas historias.

## Siguientes pasos sugeridos

- Migrar `shce_local.db` a Postgres/MySQL cuando pase de prototipo local a producción.
- Agregar expiración de sesión y bloqueo tras N intentos fallidos.
- Añadir roles/permisos reales (médico, enfermería, administración) que
  restrinjan qué módulos ve cada usuario tras el login.
- Permitir editar o dar de baja (no borrar, por trazabilidad) una historia clínica.
- Servir la app con HTTPS y una `SECRET_KEY` real (variable de entorno) antes de exponerla fuera de tu máquina.

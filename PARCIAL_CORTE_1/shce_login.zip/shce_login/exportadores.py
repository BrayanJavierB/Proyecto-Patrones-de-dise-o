"""
exportadores.py
----------------
Implementación del patrón de diseño FACTORY METHOD para exportar la
historia clínica de un paciente en distintos formatos (PDF, TXT, CSV).

¿Por qué Factory Method aquí?
Cuando el usuario elige "Exportar en PDF" o "Exportar en CSV" en la
interfaz, el código que arma la exportación NO debería tener que saber
cómo se construye cada tipo de archivo (eso violaría el principio de
responsabilidad única y ensuciaría las rutas de Flask con ifs interminables).

En cambio, con Factory Method:
  - Hay una clase "Creador" (CreadorExportador) que define el flujo general
    de exportar (exportar_historia), sin conocer el formato concreto.
  - Cada formato tiene su propia subclase "Creador concreto"
    (CreadorPDF, CreadorTXT, CreadorCSV) que solo decide QUÉ objeto
    exportador construir, sobrescribiendo el "método fábrica"
    (crear_exportador).
  - Agregar un formato nuevo (por ejemplo Word o JSON) en el futuro
    significa crear una clase nueva, sin tocar el código que ya funciona.

Estructura del patrón en este archivo:
  Producto abstracto   -> ExportadorHistoriaClinica
  Productos concretos  -> ExportadorPDF, ExportadorTXT, ExportadorCSV
  Creador abstracto    -> CreadorExportador
  Creadores concretos  -> CreadorPDF, CreadorTXT, CreadorCSV
"""

# ABC / abstractmethod: nos permiten definir clases "abstractas" en Python,
# es decir, clases que no se pueden instanciar directamente y que OBLIGAN
# a sus subclases a implementar ciertos métodos.
from abc import ABC, abstractmethod

# io: para construir los archivos directamente en memoria (BytesIO/StringIO)
# en vez de escribirlos a disco. Así el archivo se genera y se envía al
# navegador para descargar, sin dejar basura en el servidor.
import io
import csv
from datetime import datetime, date

# reportlab: librería para generar PDFs con buen formato (tablas, estilos,
# tipografía), en vez de escribir el PDF a mano byte por byte.
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)

# El patrón Abstract Factory (fabricas.py): lo reutilizamos aquí para que
# el PDF/TXT/CSV muestren la MISMA etiqueta de tipo de atención
# ("Consulta general", "Urgencia · Prioridad alta", etc.) que ya se
# calcula con este patrón en el listado de pacientes de app.py. Así los
# dos patrones (Factory Method para el formato, Abstract Factory para el
# tipo de atención) colaboran sin pisarse.
from fabricas import obtener_fabrica


def _etiqueta_tipo_atencion(paciente: dict) -> str:
    """Pide, vía Abstract Factory, la etiqueta correcta para este paciente."""
    fabrica = obtener_fabrica(paciente.get("tipo_atencion"))
    formateador = fabrica.crear_formateador()
    return formateador.etiqueta(paciente)


def calcular_edad(fecha_nacimiento_str):
    """Función auxiliar: convierte 'AAAA-MM-DD' en una edad en años (o None)."""
    if not fecha_nacimiento_str:
        return None
    try:
        nacimiento = datetime.strptime(fecha_nacimiento_str, "%Y-%m-%d").date()
    except ValueError:
        return None
    hoy = date.today()
    return hoy.year - nacimiento.year - (
        (hoy.month, hoy.day) < (nacimiento.month, nacimiento.day)
    )


# =====================================================================
# PRODUCTO ABSTRACTO
# =====================================================================
class ExportadorHistoriaClinica(ABC):
    """
    Interfaz común que deben cumplir todos los exportadores concretos.
    Cualquier código que reciba un ExportadorHistoriaClinica (sin saber
    si es PDF, TXT o CSV) puede confiar en que tiene un método `generar`
    y los atributos `extension` / `mimetype`.
    """

    #: extensión del archivo generado, ej: "pdf", "txt", "csv"
    extension: str = ""

    #: tipo MIME usado por Flask para que el navegador sepa cómo abrir el archivo
    mimetype: str = "application/octet-stream"

    @abstractmethod
    def generar(self, paciente: dict) -> bytes:
        """
        Recibe el diccionario del paciente (tal como lo devuelve
        DatabaseManager.obtener_paciente) y devuelve el contenido del
        archivo ya generado, en bytes, listo para enviar como descarga.
        """
        raise NotImplementedError


# =====================================================================
# PRODUCTOS CONCRETOS
# =====================================================================
class ExportadorPDF(ExportadorHistoriaClinica):
    """Genera la historia clínica como un PDF con formato tipo ficha médica."""

    extension = "pdf"
    mimetype = "application/pdf"

    def generar(self, paciente: dict) -> bytes:
        buffer = io.BytesIO()

        documento_pdf = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            topMargin=2.2 * cm,
            bottomMargin=2 * cm,
            leftMargin=2 * cm,
            rightMargin=2 * cm,
            title=f"Historia clínica - {paciente['nombre_completo']}",
        )

        estilos = getSampleStyleSheet()

        estilo_titulo = ParagraphStyle(
            "TituloSHCE", parent=estilos["Heading1"],
            fontSize=20, textColor=colors.HexColor("#0E2A2E"),
            spaceAfter=2,
        )
        estilo_eyebrow = ParagraphStyle(
            "EyebrowSHCE", parent=estilos["Normal"],
            fontSize=9, textColor=colors.HexColor("#1C6E71"),
            fontName="Helvetica-Bold", spaceAfter=14,
        )
        estilo_etiqueta_seccion = ParagraphStyle(
            "SeccionSHCE", parent=estilos["Heading3"],
            fontSize=11, textColor=colors.HexColor("#1C6E71"),
            spaceBefore=16, spaceAfter=6,
        )
        estilo_cuerpo = ParagraphStyle(
            "CuerpoSHCE", parent=estilos["Normal"],
            fontSize=10.5, leading=15, textColor=colors.HexColor("#16262A"),
        )

        elementos = []

        # ---------- Encabezado ----------
        elementos.append(Paragraph("SHCE - SISTEMA DE HISTORIAS CLÍNICAS ELECTRÓNICAS", estilo_eyebrow))
        elementos.append(Paragraph("Historia clínica del paciente", estilo_titulo))
        elementos.append(HRFlowable(width="100%", thickness=1.2, color=colors.HexColor("#2FE6A0")))
        elementos.append(Spacer(1, 14))

        # ---------- Datos generales en tabla ----------
        edad = calcular_edad(paciente.get("fecha_nacimiento"))
        datos_generales = [
            ["Nombre completo", paciente.get("nombre_completo", "")],
            ["Documento", paciente.get("documento", "")],
            ["Fecha de nacimiento", paciente.get("fecha_nacimiento") or "No registrada"],
            ["Edad", f"{edad} años" if edad is not None else "No calculable"],
            ["Tipo de atención", _etiqueta_tipo_atencion(paciente)],
            ["Registrado por", paciente.get("registrado_por", "")],
            ["Fecha de registro", str(paciente.get("creado_en", ""))],
        ]
        tabla_generales = Table(datos_generales, colWidths=[5.2 * cm, 9.3 * cm])
        tabla_generales.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9.5),
            ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#6B7A76")),
            ("TEXTCOLOR", (1, 0), (1, -1), colors.HexColor("#16262A")),
            ("LINEBELOW", (0, 0), (-1, -1), 0.6, colors.HexColor("#E3DECF")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        elementos.append(tabla_generales)

        # ---------- Secciones clinicas ----------
        secciones = [
            ("Motivo de consulta", paciente.get("motivo_consulta")),
            ("Diagnóstico", paciente.get("diagnostico")),
            ("Tratamiento", paciente.get("tratamiento")),
            ("Notas adicionales", paciente.get("notas")),
        ]
        for titulo_seccion, contenido in secciones:
            elementos.append(Paragraph(titulo_seccion.upper(), estilo_etiqueta_seccion))
            elementos.append(Paragraph(contenido or "Sin información registrada.", estilo_cuerpo))

        elementos.append(Spacer(1, 24))
        elementos.append(HRFlowable(width="100%", thickness=0.6, color=colors.HexColor("#E3DECF")))
        elementos.append(Spacer(1, 6))
        elementos.append(Paragraph(
            f"Documento generado localmente por SHCE el "
            f"{datetime.now().strftime('%Y-%m-%d %H:%M')}.",
            ParagraphStyle("Pie", parent=estilos["Normal"], fontSize=8,
                           textColor=colors.HexColor("#6B7A76")),
        ))

        documento_pdf.build(elementos)
        return buffer.getvalue()


class ExportadorTXT(ExportadorHistoriaClinica):
    """Genera la historia clínica como un archivo de texto plano, simple y portable."""

    extension = "txt"
    mimetype = "text/plain; charset=utf-8"

    def generar(self, paciente: dict) -> bytes:
        edad = calcular_edad(paciente.get("fecha_nacimiento"))
        lineas = [
            "=" * 60,
            "SHCE - HISTORIA CLÍNICA DEL PACIENTE",
            "=" * 60,
            f"Nombre completo   : {paciente.get('nombre_completo', '')}",
            f"Documento         : {paciente.get('documento', '')}",
            f"Fecha nacimiento  : {paciente.get('fecha_nacimiento') or 'No registrada'}",
            f"Edad              : {f'{edad} años' if edad is not None else 'No calculable'}",
            f"Tipo de atención  : {_etiqueta_tipo_atencion(paciente)}",
            f"Registrado por    : {paciente.get('registrado_por', '')}",
            f"Fecha de registro : {paciente.get('creado_en', '')}",
            "-" * 60,
            "MOTIVO DE CONSULTA",
            paciente.get("motivo_consulta") or "Sin información registrada.",
            "",
            "DIAGNÓSTICO",
            paciente.get("diagnostico") or "Sin información registrada.",
            "",
            "TRATAMIENTO",
            paciente.get("tratamiento") or "Sin información registrada.",
            "",
            "NOTAS ADICIONALES",
            paciente.get("notas") or "Sin información registrada.",
            "-" * 60,
            f"Generado localmente por SHCE el {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        ]
        texto = "\n".join(lineas)
        return texto.encode("utf-8")


class ExportadorCSV(ExportadorHistoriaClinica):
    """Genera la historia clínica como CSV (campo, valor), útil para abrir en Excel."""

    extension = "csv"
    mimetype = "text/csv; charset=utf-8"

    def generar(self, paciente: dict) -> bytes:
        buffer = io.StringIO()
        escritor = csv.writer(buffer)
        escritor.writerow(["Campo", "Valor"])

        edad = calcular_edad(paciente.get("fecha_nacimiento"))
        filas = [
            ("Nombre completo", paciente.get("nombre_completo", "")),
            ("Documento", paciente.get("documento", "")),
            ("Fecha de nacimiento", paciente.get("fecha_nacimiento") or ""),
            ("Edad", edad if edad is not None else ""),
            ("Tipo de atención", _etiqueta_tipo_atencion(paciente)),
            ("Motivo de consulta", paciente.get("motivo_consulta") or ""),
            ("Diagnóstico", paciente.get("diagnostico") or ""),
            ("Tratamiento", paciente.get("tratamiento") or ""),
            ("Notas adicionales", paciente.get("notas") or ""),
            ("Registrado por", paciente.get("registrado_por", "")),
            ("Fecha de registro", paciente.get("creado_en", "")),
        ]
        escritor.writerows(filas)

        # utf-8-sig agrega un BOM al inicio del archivo: sin esto, Excel
        # suele mostrar mal los acentos y la "ñ" al abrir el CSV.
        return buffer.getvalue().encode("utf-8-sig")


# =====================================================================
# CREADOR ABSTRACTO  (aquí vive el "método fábrica" en sí)
# =====================================================================
class CreadorExportador(ABC):
    """
    Clase base de la jerarquía de creadores. Define el flujo general para
    exportar una historia clínica SIN saber a qué formato concreto se
    exporta: eso lo decide cada subclase a través de `crear_exportador`.
    """

    @abstractmethod
    def crear_exportador(self) -> ExportadorHistoriaClinica:
        """
        EL MÉTODO FÁBRICA. Cada subclase concreta lo sobrescribe para
        devolver el producto (exportador) que le corresponde.
        Este método es el punto donde el patrón "decide" qué clase
        concreta instanciar, delegando esa decisión en las subclases.
        """
        raise NotImplementedError

    def exportar_historia(self, paciente: dict):
        """
        Método de plantilla, IGUAL para todos los formatos: pide un
        exportador con crear_exportador() (sin saber cuál es) y lo usa
        para generar el archivo. Gracias a esto, si mañana agregamos un
        nuevo formato (ej. Word), este método no cambia ni una línea.

        Devuelve una tupla (contenido_en_bytes, mimetype, nombre_de_archivo)
        lista para enviarse como descarga desde Flask.
        """
        exportador = self.crear_exportador()
        contenido = exportador.generar(paciente)

        documento = paciente.get("documento", "paciente")
        nombre_archivo = f"historia_clinica_{documento}.{exportador.extension}"

        return contenido, exportador.mimetype, nombre_archivo


# =====================================================================
# CREADORES CONCRETOS
# =====================================================================
class CreadorPDF(CreadorExportador):
    """Sabe construir, específicamente, un ExportadorPDF."""
    def crear_exportador(self) -> ExportadorHistoriaClinica:
        return ExportadorPDF()


class CreadorTXT(CreadorExportador):
    """Sabe construir, específicamente, un ExportadorTXT."""
    def crear_exportador(self) -> ExportadorHistoriaClinica:
        return ExportadorTXT()


class CreadorCSV(CreadorExportador):
    """Sabe construir, específicamente, un ExportadorCSV."""
    def crear_exportador(self) -> ExportadorHistoriaClinica:
        return ExportadorCSV()


# ---------------------------------------------------------------------
# Tabla de búsqueda: traduce el string que llega desde el formulario web
# ("pdf", "txt", "csv") al Creador concreto correspondiente.
#
# IMPORTANTE: esto NO es el patrón Factory Method en sí (es solo un
# diccionario). El patrón está en la jerarquía de clases de arriba
# (CreadorExportador y sus subclases). Esta función es simplemente el
# "punto de entrada" cómodo que usa app.py para no tener que escribir
# if/elif en la ruta de Flask.
# ---------------------------------------------------------------------
_CREADORES_DISPONIBLES = {
    "pdf": CreadorPDF,
    "txt": CreadorTXT,
    "csv": CreadorCSV,
}


def obtener_creador(formato: str) -> CreadorExportador:
    """
    Devuelve una instancia del Creador concreto que corresponde al
    formato pedido. Lanza ValueError si el formato no está soportado.
    """
    clase_creador = _CREADORES_DISPONIBLES.get(formato)
    if clase_creador is None:
        raise ValueError(f"Formato de exportación no soportado: {formato}")
    return clase_creador()


if __name__ == "__main__":
    # Pequeña demostración manual del patrón, sin necesidad de levantar Flask.
    paciente_ejemplo = {
        "nombre_completo": "Paciente de Prueba",
        "documento": "0000000000",
        "fecha_nacimiento": "1995-06-15",
        "motivo_consulta": "Chequeo general",
        "diagnostico": "Sin hallazgos relevantes",
        "tratamiento": "Ninguno",
        "notas": "Paciente de ejemplo generado por exportadores.py",
        "registrado_por": "admin",
        "creado_en": datetime.now().isoformat(),
    }

    for formato in ("pdf", "txt", "csv"):
        creador = obtener_creador(formato)          # elige la subclase correcta
        contenido, mimetype, nombre = creador.exportar_historia(paciente_ejemplo)
        print(f"[{formato.upper()}] {nombre} -> {len(contenido)} bytes ({mimetype})")

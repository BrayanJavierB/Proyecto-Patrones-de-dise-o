/* ==========================================================
   main.js
   ----------------------------------------------------------
   Lógica compartida de la interfaz. Por ahora solo contiene el
   toggle de "mostrar/ocultar contraseña" (el ícono de ojo), pero
   está escrito para funcionar con TODOS los campos de contraseña
   que haya en la página (login tiene uno, registro tiene dos),
   sin necesidad de repetir el código.
   ========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  // Buscamos TODOS los botones de "ojo" que haya en la página actual.
  const botonesToggle = document.querySelectorAll(".toggle-password");

  botonesToggle.forEach((boton) => {
    // Cada botón sabe, por su atributo data-target, a qué <input> controla.
    // Ej: <button data-target="password"> controla <input id="password">
    const inputId = boton.getAttribute("data-target");
    const input = document.getElementById(inputId);
    if (!input) return; // seguridad: si no existe el input, no hacemos nada

    const ojoAbierto = boton.querySelector(".eye-open");
    const ojoCerrado = boton.querySelector(".eye-closed");

    boton.addEventListener("click", () => {
      // Si el input está oculto (type="password"), al hacer click pasa a
      // texto visible, y viceversa.
      const seVaAMostrar = input.type === "password";
      input.type = seVaAMostrar ? "text" : "password";

      // Contraseña visible -> mostramos el ícono de ojo ABIERTO.
      // Contraseña oculta  -> mostramos el ícono de ojo CERRADO.
      ojoAbierto.hidden = !seVaAMostrar;
      ojoCerrado.hidden = seVaAMostrar;

      // Actualizamos los atributos de accesibilidad para lectores de pantalla.
      boton.setAttribute("aria-pressed", String(seVaAMostrar));
      boton.setAttribute(
        "aria-label",
        seVaAMostrar ? "Ocultar contraseña" : "Mostrar contraseña"
      );
    });
  });

  // --------------------------------------------------------------
  // Campos condicionales del formulario de historia clínica.
  // ------------------------------------------------------------
  // Cada .campo-condicional trae un atributo data-requiere-tipo (ej:
  // "urgencias" o "control"). Lo mostramos solo si el <select
  // id="tipo_atencion"> tiene ese mismo valor seleccionado; en caso
  // contrario lo ocultamos. Esto es solo una ayuda visual: la
  // validación real de qué campo es obligatorio para cada tipo la hace
  // el Abstract Factory en el servidor (fabricas.py), no este script.
  const selectorTipoAtencion = document.getElementById("tipo_atencion");
  const camposCondicionales = document.querySelectorAll(".campo-condicional");

  if (selectorTipoAtencion && camposCondicionales.length > 0) {
    const actualizarCamposVisibles = () => {
      const tipoElegido = selectorTipoAtencion.value;
      camposCondicionales.forEach((campo) => {
        const tipoRequerido = campo.getAttribute("data-requiere-tipo");
        campo.classList.toggle("campo-condicional--visible", tipoRequerido === tipoElegido);
      });
    };

    actualizarCamposVisibles(); // estado inicial al cargar la página
    selectorTipoAtencion.addEventListener("change", actualizarCamposVisibles);
  }
});

"""
constructor_historia.py
------------------------
Implementación del patrón de diseño BUILDER para armar, paso a paso, el
diccionario de datos de una historia clínica antes de guardarlo con
DatabaseManager.crear_paciente().

¿Por qué Builder aquí?
Una historia clínica tiene MUCHOS campos (11 en total: datos personales,
motivo, diagnóstico, tratamiento, notas, tipo de atención y sus campos
extra...). Pasar los 11 de golpe como parámetros posicionales es frágil
(fácil confundir el orden) y difícil de leer. Con Builder:

  - Cada método "con_xxx" configura UNA parte de la historia clínica y
    devuelve el propio constructor (`return self`), para poder encadenar
    llamadas de forma legible ("fluent interface"):

        ConstructorHistoriaClinica()
            .con_datos_personales("Ana Ruiz", "123", "1990-01-01")
            .con_motivo_consulta("Chequeo anual")
            .construir()

  - `construir()` es el único método que realmente "entrega" el producto
    final (el diccionario completo), separando el PROCESO de armar los
    datos del RESULTADO final.

  - `DirectorHistoriaClinica` conoce "recetas" comunes (una urgencia
    típica, un control de seguimiento típico) y las arma usando el
    Builder por dentro, para que el código que solo necesita un caso
    común no tenga que repetir la secuencia completa de pasos.

Nota honesta sobre esta implementación: la versión clásica de Builder
(GoF) suele tener una interfaz Builder abstracta con varios Builders
concretos que producen representaciones distintas del mismo producto.
Aquí usamos un único Builder concreto (porque solo hay UNA
representación posible: el diccionario de datos del paciente), que es
la forma más común de aplicar este patrón en proyectos reales cuando lo
que se busca es domar la construcción de un objeto complejo, no variar
su representación.
"""


class ConstructorHistoriaClinica:
    """
    Builder: arma paso a paso el diccionario de datos de una historia
    clínica. Se usa encadenando los métodos "con_xxx" y terminando
    siempre con construir().
    """

    def __init__(self):
        # Estructura con los valores por defecto. Empieza "vacía" y cada
        # método con_xxx va rellenando una parte.
        self._datos = {
            "nombre_completo": "",
            "documento": "",
            "fecha_nacimiento": "",
            "motivo_consulta": "",
            "diagnostico": "",
            "tratamiento": "",
            "notas": "",
            "tipo_atencion": "consulta_general",
            "prioridad": None,
            "fecha_proximo_control": None,
        }

    def con_datos_personales(self, nombre_completo, documento, fecha_nacimiento=""):
        """Configura la identificación del paciente. Devuelve self para encadenar."""
        self._datos["nombre_completo"] = nombre_completo
        self._datos["documento"] = documento
        self._datos["fecha_nacimiento"] = fecha_nacimiento
        return self

    def con_motivo_consulta(self, motivo_consulta):
        self._datos["motivo_consulta"] = motivo_consulta
        return self

    def con_diagnostico(self, diagnostico):
        self._datos["diagnostico"] = diagnostico
        return self

    def con_tratamiento(self, tratamiento):
        self._datos["tratamiento"] = tratamiento
        return self

    def con_notas(self, notas):
        self._datos["notas"] = notas
        return self

    def con_tipo_atencion(self, tipo_atencion, prioridad=None, fecha_proximo_control=None):
        """
        Configura el tipo de atención y sus campos asociados. Estos son
        justo los datos que luego usará el Abstract Factory (fabricas.py)
        para elegir el validador/formateador correcto.
        """
        self._datos["tipo_atencion"] = tipo_atencion
        self._datos["prioridad"] = prioridad
        self._datos["fecha_proximo_control"] = fecha_proximo_control
        return self

    def construir(self) -> dict:
        """
        Entrega el producto final: una COPIA del diccionario armado
        (para que, si se sigue usando el mismo constructor después,
        no se termine modificando por accidente el resultado ya entregado).
        """
        return dict(self._datos)


class DirectorHistoriaClinica:
    """
    Director: conoce "recetas" de construcción completas para los casos
    más comunes, usando ConstructorHistoriaClinica por dentro. El código
    que llama al Director no necesita saber el orden de los pasos, solo
    pide el resultado ya armado.
    """

    @staticmethod
    def construir_urgencia_basica(nombre_completo, documento, motivo, prioridad) -> dict:
        """Receta para el caso típico: paciente que ingresa por urgencias."""
        return (
            ConstructorHistoriaClinica()
            .con_datos_personales(nombre_completo, documento)
            .con_motivo_consulta(motivo)
            .con_tipo_atencion("urgencias", prioridad=prioridad)
            .construir()
        )

    @staticmethod
    def construir_control_seguimiento(nombre_completo, documento, motivo, fecha_proximo_control) -> dict:
        """Receta para el caso típico: cita de control con fecha de seguimiento ya definida."""
        return (
            ConstructorHistoriaClinica()
            .con_datos_personales(nombre_completo, documento)
            .con_motivo_consulta(motivo)
            .con_tipo_atencion("control", fecha_proximo_control=fecha_proximo_control)
            .construir()
        )


if __name__ == "__main__":
    # Demostración: dos formas de usar el Builder.

    # 1) Uso manual, paso a paso (para un caso que no encaja en ninguna receta).
    datos_manual = (
        ConstructorHistoriaClinica()
        .con_datos_personales("Paciente de Prueba", "0000000000", "1995-06-15")
        .con_motivo_consulta("Chequeo general")
        .con_diagnostico("Sin hallazgos relevantes")
        .con_tratamiento("Ninguno")
        .con_notas("Historia armada manualmente con el Builder.")
        .con_tipo_atencion("consulta_general")
        .construir()
    )
    print("[Builder manual]", datos_manual)

    # 2) Uso con el Director, usando una receta ya lista.
    datos_urgencia = DirectorHistoriaClinica.construir_urgencia_basica(
        nombre_completo="Otro Paciente", documento="1111111111",
        motivo="Dolor torácico", prioridad="alta",
    )
    print("[Director: urgencia básica]", datos_urgencia)

"""
fabricas.py
------------
Implementación del patrón de diseño ABSTRACT FACTORY, aplicado a los
distintos "tipos de atención" que puede tener una historia clínica en el
SHCE: Consulta General, Urgencias y Control.

¿Por qué Abstract Factory aquí (y en qué se diferencia de Factory Method)?
---------------------------------------------------------------------
En exportadores.py ya usamos FACTORY METHOD: ahí, cada formato (pdf/txt/csv)
solo necesita crear UN objeto (un exportador).

Pero cada "tipo de atención" en una historia clínica necesita, en realidad,
DOS objetos relacionados que deben coincidir entre sí:

  1. Un VALIDADOR -> sabe qué campos extra son obligatorios para ese tipo
     de atención (ej: Urgencias exige "prioridad", Control exige
     "fecha_proximo_control").
  2. Un FORMATEADOR -> sabe cómo mostrar esa historia clínica como una
     etiqueta corta (ej: "Urgencia · Prioridad alta"), con su propio
     color/estilo visual.

Si mezcláramos, por error, el validador de "Urgencias" con el formateador
de "Control", el sistema pediría el campo equivocado y mostraría una
etiqueta que no corresponde. Abstract Factory existe precisamente para
evitar eso: agrupa la creación de FAMILIAS de objetos relacionados
(validador + formateador) en una sola fábrica por tipo de atención, así
es imposible construir una combinación inconsistente.

Estructura del patrón en este archivo:
  Producto abstracto A  -> ValidadorAtencion
  Productos concretos A -> ValidadorConsultaGeneral, ValidadorUrgencias, ValidadorControl
  Producto abstracto B  -> FormateadorAtencion
  Productos concretos B -> FormateadorConsultaGeneral, FormateadorUrgencias, FormateadorControl
  Fábrica abstracta     -> FabricaAtencion
  Fábricas concretas    -> FabricaConsultaGeneral, FabricaUrgencias, FabricaControl
"""

from abc import ABC, abstractmethod


# =====================================================================
# FAMILIA DE PRODUCTOS 1: Validadores
# =====================================================================
class ValidadorAtencion(ABC):
    """
    Producto abstracto A. Cada tipo de atención sabe validar sus propios
    campos extra (los que no son comunes a todas las historias clínicas).
    """

    @abstractmethod
    def validar(self, datos_formulario) -> list:
        """
        Recibe los datos crudos del formulario (request.form de Flask) y
        devuelve una lista de strings con los errores encontrados.
        Lista vacía = todo válido.
        """
        raise NotImplementedError


class ValidadorConsultaGeneral(ValidadorAtencion):
    """Una consulta general no exige ningún campo adicional."""

    def validar(self, datos_formulario) -> list:
        return []


class ValidadorUrgencias(ValidadorAtencion):
    """Una urgencia SIEMPRE debe traer un nivel de prioridad."""

    def validar(self, datos_formulario) -> list:
        prioridad = (datos_formulario.get("prioridad") or "").strip()
        if not prioridad:
            return ["Para 'Urgencias' debes indicar la prioridad (alta, media o baja)."]
        return []


class ValidadorControl(ValidadorAtencion):
    """Un control debe traer programada la fecha del próximo control."""

    def validar(self, datos_formulario) -> list:
        fecha = (datos_formulario.get("fecha_proximo_control") or "").strip()
        if not fecha:
            return ["Para 'Control' debes indicar la fecha del próximo control."]
        return []


# =====================================================================
# FAMILIA DE PRODUCTOS 2: Formateadores
# =====================================================================
class FormateadorAtencion(ABC):
    """
    Producto abstracto B. Cada tipo de atención sabe construir su propia
    etiqueta corta (para el listado de pacientes y para las exportaciones)
    y sabe qué clase CSS de color le corresponde a esa etiqueta.
    """

    #: clase CSS del badge de color (definida en style.css)
    color_css: str = "badge-atencion--general"

    @abstractmethod
    def etiqueta(self, paciente: dict) -> str:
        """Devuelve el texto corto que resume el tipo de atención."""
        raise NotImplementedError


class FormateadorConsultaGeneral(FormateadorAtencion):
    color_css = "badge-atencion--general"

    def etiqueta(self, paciente: dict) -> str:
        return "Consulta general"


class FormateadorUrgencias(FormateadorAtencion):
    color_css = "badge-atencion--urgente"

    def etiqueta(self, paciente: dict) -> str:
        prioridad = paciente.get("prioridad") or "sin definir"
        return f"Urgencia · Prioridad {prioridad}"


class FormateadorControl(FormateadorAtencion):
    color_css = "badge-atencion--control"

    def etiqueta(self, paciente: dict) -> str:
        fecha = paciente.get("fecha_proximo_control") or "sin programar"
        return f"Control · Próxima cita {fecha}"


# =====================================================================
# FÁBRICA ABSTRACTA
# =====================================================================
class FabricaAtencion(ABC):
    """
    Declara los métodos para crear CADA producto de la familia
    (validador y formateador). Ninguna parte del código que use esta
    fábrica necesita saber si está trabajando con Consulta General,
    Urgencias o Control: solo pide "el validador" y "el formateador",
    y la fábrica concreta garantiza que ambos pertenecen a la misma familia.
    """

    @abstractmethod
    def crear_validador(self) -> ValidadorAtencion:
        raise NotImplementedError

    @abstractmethod
    def crear_formateador(self) -> FormateadorAtencion:
        raise NotImplementedError


class FabricaConsultaGeneral(FabricaAtencion):
    """Fábrica concreta: familia completa para 'Consulta General'."""
    def crear_validador(self) -> ValidadorAtencion:
        return ValidadorConsultaGeneral()

    def crear_formateador(self) -> FormateadorAtencion:
        return FormateadorConsultaGeneral()


class FabricaUrgencias(FabricaAtencion):
    """Fábrica concreta: familia completa para 'Urgencias'."""
    def crear_validador(self) -> ValidadorAtencion:
        return ValidadorUrgencias()

    def crear_formateador(self) -> FormateadorAtencion:
        return FormateadorUrgencias()


class FabricaControl(FabricaAtencion):
    """Fábrica concreta: familia completa para 'Control'."""
    def crear_validador(self) -> ValidadorAtencion:
        return ValidadorControl()

    def crear_formateador(self) -> FormateadorAtencion:
        return FormateadorControl()


# ---------------------------------------------------------------------
# Tabla de búsqueda: traduce el string que llega del <select> del
# formulario web ("consulta_general", "urgencias", "control") a la
# fábrica concreta correspondiente.
#
# IMPORTANTE (igual que en exportadores.py): esto NO es el patrón en sí,
# es solo el punto de entrada cómodo para que app.py no tenga que hacer
# if/elif. El patrón Abstract Factory está en la jerarquía de clases de
# arriba: FabricaAtencion y sus tres fábricas concretas.
# ---------------------------------------------------------------------
_FABRICAS_DISPONIBLES = {
    "consulta_general": FabricaConsultaGeneral,
    "urgencias": FabricaUrgencias,
    "control": FabricaControl,
}

#: Opciones para poblar el <select> del formulario, en el orden en que deben mostrarse.
TIPOS_ATENCION = [
    ("consulta_general", "Consulta general"),
    ("urgencias", "Urgencias"),
    ("control", "Control"),
]


def obtener_fabrica(tipo_atencion: str) -> FabricaAtencion:
    """
    Devuelve la fábrica concreta (con su familia completa de validador +
    formateador) que corresponde al tipo de atención pedido.
    Si el tipo no existe, se usa "Consulta general" como valor seguro
    por defecto, en vez de lanzar un error.
    """
    clase_fabrica = _FABRICAS_DISPONIBLES.get(tipo_atencion, FabricaConsultaGeneral)
    return clase_fabrica()


if __name__ == "__main__":
    # Pequeña demostración: pedimos la familia completa para cada tipo
    # y mostramos que validador + formateador siempre coinciden entre sí.
    paciente_urgencia = {"prioridad": "alta"}
    paciente_control = {"fecha_proximo_control": "2026-10-01"}

    for tipo, datos in [
        ("consulta_general", {}),
        ("urgencias", paciente_urgencia),
        ("control", paciente_control),
    ]:
        fabrica = obtener_fabrica(tipo)               # UNA fábrica -> UNA familia completa
        validador = fabrica.crear_validador()
        formateador = fabrica.crear_formateador()
        print(f"[{tipo}] validador={type(validador).__name__} "
              f"formateador={type(formateador).__name__} "
              f"-> etiqueta: {formateador.etiqueta(datos)!r} "
              f"(errores si viene vacío: {validador.validar({})})")

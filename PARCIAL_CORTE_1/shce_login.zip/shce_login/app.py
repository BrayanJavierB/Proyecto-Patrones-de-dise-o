"""
app.py
------
Aplicación web local (Flask) que expone el login y el registro del
Sistema de Historias Clínicas Electrónicas (SHCE).

Toda la persistencia y validación de credenciales pasa por la
ÚNICA instancia de DatabaseManager (patrón Singleton) definida en singleton.py.
"""

# Flask: micro-framework web. Con esto servimos páginas HTML y procesamos formularios.
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file

# functools.wraps: para que el decorador de login conserve el nombre y
# la documentación de la función original (buena práctica al hacer decoradores).
from functools import wraps

# io: para envolver los bytes que genera el exportador y enviarlos como descarga.
import io

# Nuestra clase Singleton, encargada de toda la base de datos y la autenticación.
from singleton import DatabaseManager

# El patrón Factory Method para exportar historias clínicas (PDF/TXT/CSV).
from exportadores import obtener_creador, calcular_edad

# El patrón Abstract Factory: familias de validador + formateador según
# el tipo de atención de la historia clínica (consulta general / urgencias / control).
from fabricas import obtener_fabrica, TIPOS_ATENCION

# El patrón Builder: arma paso a paso el diccionario de datos de una
# historia clínica antes de guardarla.
from constructor_historia import ConstructorHistoriaClinica

# El patrón Prototype: permite clonar una historia clínica existente
# como plantilla para una consulta nueva del mismo paciente.
from prototipos import HistoriaClinicaPrototype

# Creamos la aplicación Flask. __name__ le dice a Flask dónde buscar las
# carpetas "templates" y "static".
app = Flask(__name__)

# Clave secreta usada por Flask para firmar la cookie de sesión
# (evita que alguien falsifique su sesión). En un entorno real esto
# debería venir de una variable de entorno, no estar escrito en el código.
app.secret_key = "cambia-esta-clave-en-produccion"

# ---------------------------------------------------------------------
# Aquí es donde se "activa" el Singleton: esta es la ÚNICA vez en toda
# la app que se hace DatabaseManager(). A partir de aquí, la variable
# global `db` apunta siempre a esa misma instancia (misma conexión SQLite).
# Cualquier otra parte del código que vuelva a llamar DatabaseManager()
# recibiría exactamente este mismo objeto.
# ---------------------------------------------------------------------
db = DatabaseManager()


def requiere_login(vista):
    """
    Decorador para no repetir en cada ruta protegida el mismo
    `if not session.get("usuario"): return redirect(...)`.
    Se usa poniendo @requiere_login justo encima de la función de la ruta.
    """
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login"))
        return vista(*args, **kwargs)
    return envoltura


@app.route("/")
def index():
    """
    Ruta raíz: si ya hay una sesión activa, manda directo al panel;
    si no, manda al login.
    """
    if session.get("usuario"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    """
    GET  -> muestra el formulario de login.
    POST -> procesa lo que el usuario escribió en el formulario.
    """
    if request.method == "POST":
        # request.form es un diccionario con los datos enviados por el
        # formulario (los "name" de los <input> en login.html).
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")

        # Le preguntamos al Singleton si esas credenciales son válidas.
        # validar_credenciales también registra el intento en la bitácora.
        registro = db.validar_credenciales(usuario, password)

        if registro:
            # Guardamos datos básicos en la sesión del navegador (cookie
            # firmada) para saber, en las siguientes peticiones, quién es
            # el usuario sin pedirle la contraseña de nuevo.
            session["usuario"] = registro["usuario"]
            session["nombre_completo"] = registro["nombre_completo"]
            session["rol"] = registro["rol"]
            return redirect(url_for("dashboard"))

        # Si las credenciales fallaron, mostramos un mensaje de error
        # (flash) y volvemos a renderizar el formulario, conservando lo
        # que el usuario ya había escrito en el campo "usuario".
        flash("Usuario o contraseña incorrectos.")
        return render_template("login.html", usuario_previo=usuario), 401

    # Método GET: primera vez que se entra a la página.
    return render_template("login.html", usuario_previo="")


@app.route("/registro", methods=["GET", "POST"])
def registro():
    """
    GET  -> muestra el formulario para crear una cuenta nueva.
    POST -> valida los datos y crea el usuario usando el Singleton.
    """
    if request.method == "POST":
        # Leemos cada campo del formulario de registro.
        nombre_completo = request.form.get("nombre_completo", "").strip()
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        confirmar_password = request.form.get("confirmar_password", "")
        rol = request.form.get("rol", "medico")

        # ------------------ Validaciones básicas ------------------
        errores = []

        if not nombre_completo or not usuario or not password:
            errores.append("Todos los campos son obligatorios.")

        if len(password) < 6:
            errores.append("La contraseña debe tener al menos 6 caracteres.")

        if password != confirmar_password:
            errores.append("Las contraseñas no coinciden.")

        if db.obtener_usuario(usuario) is not None:
            errores.append("Ese nombre de usuario ya existe, elige otro.")

        if errores:
            # Mostramos todos los errores encontrados y volvemos a
            # renderizar el formulario sin perder lo ya escrito.
            for error in errores:
                flash(error)
            return render_template(
                "registro.html",
                nombre_completo=nombre_completo,
                usuario=usuario,
                rol=rol,
            ), 400

        # ------------------ Todo válido: creamos el usuario ------------------
        # Esto pasa por el mismo Singleton (db) que usa el login, así que
        # el nuevo usuario queda disponible para iniciar sesión de inmediato.
        db.crear_usuario(nombre_completo, usuario, password, rol)

        flash("Cuenta creada correctamente. Ya puedes iniciar sesión.")
        return redirect(url_for("login"))

    # Método GET: mostramos el formulario vacío.
    return render_template("registro.html", nombre_completo="", usuario="", rol="medico")


@app.route("/dashboard")
@requiere_login
def dashboard():
    """Panel principal, solo visible si hay una sesión iniciada."""
    # Traemos los últimos eventos de acceso para mostrarlos como ejemplo.
    bitacora = db.obtener_bitacora(limite=8)
    # Traemos también el total de pacientes registrados, para mostrarlo como dato rápido.
    total_pacientes = len(db.obtener_pacientes())

    return render_template(
        "dashboard.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        bitacora=bitacora,
        total_pacientes=total_pacientes,
        # id(db) es el identificador en memoria del objeto: sirve para
        # comprobar visualmente que siempre es la misma instancia Singleton.
        instancia_id=id(db),
    )


@app.route("/pacientes")
@requiere_login
def pacientes():
    """Lista todas las historias clínicas registradas, con botones para exportarlas."""
    lista_pacientes = db.obtener_pacientes()

    for paciente in lista_pacientes:
        # Le agregamos a cada paciente su edad ya calculada, para no hacer
        # cálculos de fechas dentro del template (eso es responsabilidad de Python).
        paciente["edad"] = calcular_edad(paciente.get("fecha_nacimiento"))

        # -------- Aquí se usa el Abstract Factory --------
        # Pedimos la fábrica que corresponde al tipo_atencion de ESTE
        # paciente ("consulta_general", "urgencias" o "control"). Esa
        # fábrica concreta nos da un FORMATEADOR ya emparejado con el
        # validador correcto para ese mismo tipo (aunque aquí solo
        # necesitemos el formateador, ambos vienen de la misma familia).
        fabrica = obtener_fabrica(paciente.get("tipo_atencion"))
        formateador = fabrica.crear_formateador()
        paciente["etiqueta_atencion"] = formateador.etiqueta(paciente)
        paciente["color_atencion"] = formateador.color_css

    return render_template(
        "pacientes.html",
        nombre_completo=session.get("nombre_completo"),
        rol=session.get("rol"),
        pacientes=lista_pacientes,
    )


@app.route("/pacientes/<int:paciente_id>/duplicar")
@requiere_login
def paciente_duplicar(paciente_id):
    """
    Usa el patrón PROTOTYPE para precargar el formulario de "nueva
    historia clínica" con los datos clínicos de un paciente existente
    (diagnóstico, tratamiento, tipo de atención...), como plantilla para
    una consulta de seguimiento. Pensado para el caso típico de
    "el paciente vuelve por lo mismo": en vez de reescribir todo desde
    cero, se parte de una copia de la historia anterior y solo se
    ajustan los detalles nuevos.
    """
    paciente_original = db.obtener_paciente(paciente_id)
    if paciente_original is None:
        flash("Paciente no encontrado.")
        return redirect(url_for("pacientes"))

    # -------- Aquí se usa el Prototype --------
    # Envolvemos el diccionario del paciente en el prototipo y le
    # pedimos una plantilla: internamente hace una copia profunda
    # (copy.deepcopy) e independiente del original, y limpia los campos
    # que nunca deben copiarse tal cual (documento, notas).
    prototipo = HistoriaClinicaPrototype(paciente_original)
    plantilla = prototipo.como_plantilla_nueva()

    flash(
        f"Formulario precargado a partir de la historia de "
        f"{paciente_original['nombre_completo']}. Revisa los datos y "
        f"asigna un documento nuevo antes de guardar."
    )
    return render_template("paciente_nuevo.html", tipos_atencion=TIPOS_ATENCION, **plantilla)


@app.route("/pacientes/nuevo", methods=["GET", "POST"])
@requiere_login
def paciente_nuevo():
    """
    GET  -> muestra el formulario para crear una nueva historia clínica.
    POST -> valida y guarda el paciente usando el Singleton (db).
    """
    if request.method == "POST":
        # -------- Aquí se usa el Builder --------
        # En vez de armar el diccionario "a mano" (11 claves sueltas,
        # fácil de desordenar), encadenamos los métodos con_xxx del
        # Builder: cada uno configura una parte de la historia clínica
        # y el último paso (construir()) entrega el diccionario final.
        datos = (
            ConstructorHistoriaClinica()
            .con_datos_personales(
                request.form.get("nombre_completo", "").strip(),
                request.form.get("documento", "").strip(),
                request.form.get("fecha_nacimiento", "").strip(),
            )
            .con_motivo_consulta(request.form.get("motivo_consulta", "").strip())
            .con_diagnostico(request.form.get("diagnostico", "").strip())
            .con_tratamiento(request.form.get("tratamiento", "").strip())
            .con_notas(request.form.get("notas", "").strip())
            .con_tipo_atencion(
                request.form.get("tipo_atencion", "consulta_general"),
                prioridad=request.form.get("prioridad", "").strip() or None,
                fecha_proximo_control=request.form.get("fecha_proximo_control", "").strip() or None,
            )
            .construir()
        )

        errores = []
        if not datos["nombre_completo"] or not datos["documento"]:
            errores.append("Nombre completo y documento son obligatorios.")
        if db.obtener_paciente_por_documento(datos["documento"]):
            errores.append("Ya existe un paciente registrado con ese documento.")

        # -------- Aquí se usa el Abstract Factory --------
        # Según el tipo_atencion elegido en el <select>, pedimos SU
        # fábrica concreta y de ahí SU validador. Como el validador viene
        # de la misma familia que el formateador que se usará después en
        # el listado, nunca puede quedar una combinación inconsistente
        # (ej. validar como "Urgencias" pero mostrar la etiqueta de "Control").
        fabrica = obtener_fabrica(datos["tipo_atencion"])
        validador = fabrica.crear_validador()
        errores.extend(validador.validar(request.form))

        if errores:
            for error in errores:
                flash(error)
            return render_template(
                "paciente_nuevo.html", tipos_atencion=TIPOS_ATENCION, **datos
            ), 400

        # Guardamos quién creó el registro (auditoría), tomándolo de la sesión activa.
        db.crear_paciente(
            **datos,
            registrado_por=session.get("usuario"),
        )
        flash("Historia clínica creada correctamente.")
        return redirect(url_for("pacientes"))

    # Método GET: formulario vacío.
    campos_vacios = {
        "nombre_completo": "", "documento": "", "fecha_nacimiento": "",
        "motivo_consulta": "", "diagnostico": "", "tratamiento": "", "notas": "",
        "tipo_atencion": "consulta_general", "prioridad": "", "fecha_proximo_control": "",
    }
    return render_template("paciente_nuevo.html", tipos_atencion=TIPOS_ATENCION, **campos_vacios)


@app.route("/pacientes/<int:paciente_id>/exportar/<formato>")
@requiere_login
def exportar_paciente(paciente_id, formato):
    """
    Genera y descarga la historia clínica de un paciente en el formato
    pedido (pdf, txt o csv), usando el patrón Factory Method definido
    en exportadores.py.
    """
    paciente = db.obtener_paciente(paciente_id)
    if paciente is None:
        flash("Paciente no encontrado.")
        return redirect(url_for("pacientes"))

    try:
        # 1) Pedimos el "creador" concreto según el formato (pdf/txt/csv).
        #    Aquí es donde se usa el patrón: no sabemos ni nos importa
        #    qué clase concreta de exportador se va a usar por dentro.
        creador = obtener_creador(formato)

        # 2) El creador arma el archivo y nos da (bytes, mimetype, nombre).
        contenido, mimetype, nombre_archivo = creador.exportar_historia(paciente)
    except ValueError:
        flash("Formato de exportación no soportado.")
        return redirect(url_for("pacientes"))

    # 3) Enviamos esos bytes como un archivo descargable, directamente
    #    desde memoria (io.BytesIO), sin guardar nada en el disco del servidor.
    return send_file(
        io.BytesIO(contenido),
        mimetype=mimetype,
        as_attachment=True,
        download_name=nombre_archivo,
    )


@app.route("/logout")
def logout():
    """Cierra la sesión actual y vuelve al login."""
    session.clear()
    return redirect(url_for("login"))


# Este bloque solo se ejecuta cuando corres "python3 app.py" directamente
# (no cuando otro archivo importa cosas de app.py).
if __name__ == "__main__":
    print("SHCE corriendo localmente en http://127.0.0.1:5000")
    print("Usuarios de prueba -> admin / Admin123   |   brayan / Medico123")
    # debug=True recarga el servidor solo mientras desarrollas; en
    # producción esto debe quedar en False.
    app.run(debug=True, port=5000)

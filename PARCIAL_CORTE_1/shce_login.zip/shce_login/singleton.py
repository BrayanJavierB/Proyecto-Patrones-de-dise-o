"""
singleton.py
------------
Implementación del patrón de diseño SINGLETON aplicado a la gestión
de la base de datos local del Sistema de Historias Clínicas Electrónicas (SHCE).

¿Por qué Singleton aquí?
En un sistema de historias clínicas, la conexión/gestor de la base de datos
de usuarios y credenciales debe ser ÚNICA en toda la aplicación:
  - Evita abrir múltiples conexiones simultáneas a SQLite.
  - Centraliza la validación de credenciales y el registro de auditoría
    (quién entró, cuándo, si tuvo éxito), algo obligatorio en software clínico.
  - Garantiza que, sin importar desde qué parte del código se pida el
    "administrador de base de datos", siempre se obtenga la misma instancia.
"""

# sqlite3: motor de base de datos embebido (no necesita servidor aparte),
# perfecto para que el proyecto funcione "de manera local" sin instalar nada extra.
import sqlite3

# Lock: nos permite evitar que dos hilos (peticiones simultáneas de Flask)
# creen la instancia del Singleton al mismo tiempo.
from threading import Lock

# Funciones de werkzeug (la misma librería que usa Flask por debajo) para
# convertir una contraseña en un "hash" seguro y luego poder compararla,
# sin guardar NUNCA la contraseña en texto plano en la base de datos.
from werkzeug.security import generate_password_hash, check_password_hash

# El patrón Builder: lo usamos aquí solo para armar los datos de los
# pacientes de EJEMPLO de forma legible (ver _sembrar_usuarios_iniciales).
from constructor_historia import ConstructorHistoriaClinica, DirectorHistoriaClinica


class SingletonMeta(type):
    """
    Metaclase que implementa el patrón Singleton de forma thread-safe.

    Una "metaclase" es la clase que sabe CÓMO construir otras clases.
    Al usar esta metaclase, cualquier clase que la use como
    `metaclass=SingletonMeta` solo podrá tener UNA instancia viva durante
    toda la ejecución del programa, sin importar cuántas veces se escriba
    `MiClase()`.
    """

    # Diccionario "de clase" (compartido por todas las instancias de
    # SingletonMeta) que guarda, para cada clase que use este patrón,
    # cuál es su única instancia ya creada. Ejemplo: {DatabaseManager: <objeto>}
    _instances = {}

    # Candado usado para que, si dos peticiones llegan al mismo tiempo,
    # no se creen dos instancias por una condición de carrera.
    _lock = Lock()

    def __call__(cls, *args, **kwargs):
        """
        Este método se ejecuta automáticamente cada vez que alguien escribe
        `DatabaseManager()` en cualquier parte del código. Aquí es donde
        se decide: ¿creo una instancia nueva o devuelvo la que ya existe?
        """
        # Primer chequeo SIN bloqueo: si la instancia ya existe, esto es
        # rápido y evita entrar al Lock innecesariamente en el caso normal.
        if cls not in cls._instances:
            # Solo entra aquí la primera vez (o si dos hilos llegan a la
            # vez y ambos vieron que "no existía" en el chequeo anterior).
            with cls._lock:
                # Segundo chequeo DENTRO del bloqueo ("double-checked locking"):
                # por si otro hilo ya creó la instancia mientras esperábamos el Lock.
                if cls not in cls._instances:
                    # Aquí sí se construye el objeto de verdad, UNA sola vez.
                    instancia = super().__call__(*args, **kwargs)
                    cls._instances[cls] = instancia
        # A partir de aquí, siempre se devuelve la misma instancia guardada.
        return cls._instances[cls]


class DatabaseManager(metaclass=SingletonMeta):
    """
    Única instancia responsable de gestionar la conexión a la base de datos
    local (SQLite) y toda la lógica de autenticación del SHCE.

    Gracias a `metaclass=SingletonMeta`, sin importar cuántas veces se
    llame `DatabaseManager()` en app.py, en singleton.py o en cualquier
    otro archivo, siempre se obtiene el mismo objeto (misma conexión,
    mismos datos en memoria).
    """

    def __init__(self, db_path="shce_local.db"):
        # Ruta del archivo de base de datos local. Al ser SQLite, es solo
        # un archivo en disco: no requiere instalar un servidor de BD aparte.
        self.db_path = db_path

        # Abrimos la conexión UNA sola vez (porque __init__ solo se ejecuta
        # la primera vez, gracias al Singleton).
        # check_same_thread=False -> permite que Flask use esta misma
        # conexión desde distintos hilos de petición.
        self._connection = sqlite3.connect(self.db_path, check_same_thread=False)

        # row_factory = sqlite3.Row hace que cada fila se pueda leer como
        # diccionario (fila["usuario"]) en vez de por posición (fila[0]).
        self._connection.row_factory = sqlite3.Row

        # Preparamos las tablas si es la primera vez que se corre el proyecto.
        self._crear_tablas()

        # Sembramos usuarios de ejemplo si la tabla de usuarios está vacía.
        self._sembrar_usuarios_iniciales()

        print(f"[DatabaseManager] Instancia única inicializada -> {db_path}")

    # ---------------------------------------------------------------
    # Estructura de datos
    # ---------------------------------------------------------------
    def _crear_tablas(self):
        """Crea las tablas de la base de datos si todavía no existen."""
        cursor = self._connection.cursor()

        # Tabla de usuarios: aquí vive cada persona que puede iniciar sesión.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,   -- identificador único autogenerado
                nombre_completo TEXT NOT NULL,          -- nombre que se muestra en pantalla
                usuario TEXT UNIQUE NOT NULL,            -- nombre de usuario para iniciar sesión (no se repite)
                password_hash TEXT NOT NULL,             -- contraseña YA convertida a hash, nunca en texto plano
                rol TEXT NOT NULL DEFAULT 'medico',      -- rol dentro del sistema (medico, enfermeria, administracion...)
                activo INTEGER NOT NULL DEFAULT 1,       -- 1 = puede iniciar sesión, 0 = cuenta deshabilitada
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de auditoría: registra cada intento de inicio de sesión
        # (exitoso o fallido). Esto suele ser un requisito legal en
        # software de historias clínicas, para poder rastrear accesos.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bitacora_accesos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,
                exito INTEGER NOT NULL,       -- 1 = login correcto, 0 = login fallido
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Tabla de pacientes / historias clínicas: el dato principal que el
        # sistema va a exportar (con el patrón Factory Method) en PDF, TXT o CSV.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pacientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre_completo TEXT NOT NULL,
                documento TEXT UNIQUE NOT NULL,        -- cédula / documento de identidad
                fecha_nacimiento TEXT,                  -- formato AAAA-MM-DD
                motivo_consulta TEXT,
                diagnostico TEXT,
                tratamiento TEXT,
                notas TEXT,
                tipo_atencion TEXT NOT NULL DEFAULT 'consulta_general',  -- usado por el Abstract Factory (fabricas.py)
                prioridad TEXT,                         -- solo aplica si tipo_atencion = 'urgencias'
                fecha_proximo_control TEXT,             -- solo aplica si tipo_atencion = 'control'
                registrado_por TEXT,                    -- usuario que creó el registro (auditoría)
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Guardamos los cambios en el archivo .db
        self._connection.commit()

        # Migración suave: si vienes de una versión anterior del proyecto
        # (una base de datos .db creada antes de que existiera el Abstract
        # Factory), la tabla "pacientes" ya existe pero SIN estas 3 columnas
        # nuevas. CREATE TABLE IF NOT EXISTS no las agrega solo, así que las
        # añadimos a mano si hacen falta, para no romper bases de datos viejas.
        self._migrar_columnas_pacientes()

    def _migrar_columnas_pacientes(self):
        """Agrega columnas nuevas a 'pacientes' si vienen de una versión anterior del proyecto."""
        cursor = self._connection.cursor()
        cursor.execute("PRAGMA table_info(pacientes)")
        columnas_existentes = {fila["name"] for fila in cursor.fetchall()}

        columnas_nuevas = {
            "tipo_atencion": "TEXT NOT NULL DEFAULT 'consulta_general'",
            "prioridad": "TEXT",
            "fecha_proximo_control": "TEXT",
        }
        for columna, definicion in columnas_nuevas.items():
            if columna not in columnas_existentes:
                cursor.execute(f"ALTER TABLE pacientes ADD COLUMN {columna} {definicion}")
        self._connection.commit()

    def _sembrar_usuarios_iniciales(self):
        """
        Crea un par de usuarios de ejemplo la primera vez que se levanta
        la base de datos local, para que puedas probar el login sin tener
        que registrarte primero.
        """
        cursor = self._connection.cursor()
        cursor.execute("SELECT COUNT(*) AS total FROM usuarios")

        # Solo sembramos si la tabla está completamente vacía, así no se
        # duplican estos usuarios cada vez que reinicias el servidor.
        if cursor.fetchone()["total"] == 0:
            self.crear_usuario(
                nombre_completo="Administrador General",
                usuario="admin",
                password="Admin123",
                rol="administrador",
            )
            self.crear_usuario(
                nombre_completo="Brayan",
                usuario="brayan",
                password="Medico123",
                rol="medico",
            )

        # Sembramos un par de pacientes de ejemplo, así puedes probar la
        # exportación (PDF/TXT/CSV) sin tener que crear uno a mano primero.
        # Los armamos con el patrón BUILDER (constructor_historia.py), para
        # mostrar sus dos formas de uso: paso a paso, y con el Director.
        cursor.execute("SELECT COUNT(*) AS total FROM pacientes")
        if cursor.fetchone()["total"] == 0:
            # -------- Uso manual del Builder, paso a paso --------
            datos_maria = (
                ConstructorHistoriaClinica()
                .con_datos_personales("María Fernanda López", "1098765432", "1990-04-12")
                .con_motivo_consulta("Dolor abdominal recurrente")
                .con_diagnostico("Gastritis crónica")
                .con_tratamiento("Omeprazol 20mg cada 24h por 4 semanas")
                .con_notas("Paciente refiere mejoría parcial con dieta blanda.")
                .con_tipo_atencion("consulta_general")
                .construir()
            )
            self.crear_paciente(**datos_maria, registrado_por="admin")

            # -------- Uso del Builder A TRAVÉS del Director --------
            # El Director ya conoce la "receta" de un control de seguimiento
            # (nombre + documento + motivo + fecha del próximo control), y
            # aquí solo completamos con .update() los campos clínicos
            # propios de este caso (diagnóstico, tratamiento, notas).
            datos_carlos = DirectorHistoriaClinica.construir_control_seguimiento(
                nombre_completo="Carlos Andrés Pérez", documento="1012345678",
                motivo="Control post-quirúrgico", fecha_proximo_control="2026-10-05",
            )
            datos_carlos.update({
                "fecha_nacimiento": "1985-11-02",
                "diagnostico": "Recuperación favorable de apendicectomía",
                "tratamiento": "Analgésico según necesidad, retiro de puntos en 7 días",
                "notas": "Sin signos de infección en la herida.",
            })
            self.crear_paciente(**datos_carlos, registrado_por="brayan")

            # Igual, pero con la receta de "urgencia básica" del Director.
            datos_sofia = DirectorHistoriaClinica.construir_urgencia_basica(
                nombre_completo="Sofía Ramírez", documento="1055667788",
                motivo="Dificultad respiratoria súbita", prioridad="alta",
            )
            datos_sofia.update({
                "fecha_nacimiento": "1998-02-20",
                "diagnostico": "Crisis asmática moderada",
                "tratamiento": "Nebulización con salbutamol, observación 4 horas",
                "notas": "Ingresa por urgencias, saturación 92% al llegar.",
            })
            self.crear_paciente(**datos_sofia, registrado_por="brayan")

    # ---------------------------------------------------------------
    # Operaciones de usuarios
    # ---------------------------------------------------------------
    def crear_usuario(self, nombre_completo, usuario, password, rol="medico"):
        """
        Crea un nuevo usuario en la base de datos (usado tanto para los
        usuarios de ejemplo como para el formulario de registro público).

        Devuelve True si se creó, False si el nombre de usuario ya existía.
        """
        cursor = self._connection.cursor()

        # Convertimos la contraseña en un hash seguro (irreversible).
        # Nunca guardamos "password" tal cual en la base de datos.
        password_hash = generate_password_hash(password)

        try:
            cursor.execute(
                """INSERT INTO usuarios (nombre_completo, usuario, password_hash, rol)
                   VALUES (?, ?, ?, ?)""",
                (nombre_completo, usuario, password_hash, rol),
            )
            self._connection.commit()
            return True
        except sqlite3.IntegrityError:
            # Salta aquí si "usuario" ya existía (por la restricción UNIQUE).
            return False

    def validar_credenciales(self, usuario, password):
        """
        Verifica usuario/contraseña para el login y registra el intento
        (exitoso o fallido) en la bitácora de auditoría.
        """
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)
        )
        fila = cursor.fetchone()

        # Comparamos la contraseña ingresada contra el hash guardado.
        # check_password_hash se encarga de aplicar el mismo algoritmo
        # y comparar los resultados de forma segura.
        exito = fila is not None and check_password_hash(fila["password_hash"], password)

        # Se registra SIEMPRE el intento, sea exitoso o no (auditoría).
        self._registrar_acceso(usuario, exito)

        return dict(fila) if exito else None

    def obtener_usuario(self, usuario):
        """Busca un usuario por su nombre de usuario. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = ?", (usuario,))
        fila = cursor.fetchone()
        return dict(fila) if fila else None

    # ---------------------------------------------------------------
    # Operaciones de pacientes / historias clínicas
    # ---------------------------------------------------------------
    def crear_paciente(self, nombre_completo, documento, fecha_nacimiento,
                        motivo_consulta, diagnostico, tratamiento, notas,
                        registrado_por, tipo_atencion="consulta_general",
                        prioridad=None, fecha_proximo_control=None):
        """
        Guarda una nueva historia clínica. Devuelve True si se creó,
        False si ya existía un paciente con ese documento.

        tipo_atencion, prioridad y fecha_proximo_control son los campos
        que usa el patrón Abstract Factory (fabricas.py) para saber qué
        validador y qué formateador aplicarle a este paciente.
        """
        cursor = self._connection.cursor()
        try:
            cursor.execute(
                """INSERT INTO pacientes
                   (nombre_completo, documento, fecha_nacimiento, motivo_consulta,
                    diagnostico, tratamiento, notas, tipo_atencion, prioridad,
                    fecha_proximo_control, registrado_por)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (nombre_completo, documento, fecha_nacimiento, motivo_consulta,
                 diagnostico, tratamiento, notas, tipo_atencion, prioridad,
                 fecha_proximo_control, registrado_por),
            )
            self._connection.commit()
            return True
        except sqlite3.IntegrityError:
            # Salta aquí si "documento" ya existía (restricción UNIQUE).
            return False

    def obtener_pacientes(self):
        """Devuelve todos los pacientes, del más reciente al más antiguo."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes ORDER BY creado_en DESC")
        return [dict(fila) for fila in cursor.fetchall()]

    def obtener_paciente(self, paciente_id):
        """Busca un paciente por su id. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes WHERE id = ?", (paciente_id,))
        fila = cursor.fetchone()
        return dict(fila) if fila else None

    def obtener_paciente_por_documento(self, documento):
        """Busca un paciente por su número de documento. Devuelve None si no existe."""
        cursor = self._connection.cursor()
        cursor.execute("SELECT * FROM pacientes WHERE documento = ?", (documento,))
        fila = cursor.fetchone()
        return dict(fila) if fila else None

    # ---------------------------------------------------------------
    # Auditoría (obligatoria en sistemas de historias clínicas)
    # ---------------------------------------------------------------
    def _registrar_acceso(self, usuario, exito):
        """Guarda un renglón en la bitácora cada vez que alguien intenta iniciar sesión."""
        cursor = self._connection.cursor()
        cursor.execute(
            "INSERT INTO bitacora_accesos (usuario, exito) VALUES (?, ?)",
            (usuario, int(exito)),
        )
        self._connection.commit()

    def obtener_bitacora(self, limite=8):
        """Devuelve los últimos `limite` eventos de acceso, del más reciente al más antiguo."""
        cursor = self._connection.cursor()
        cursor.execute(
            "SELECT * FROM bitacora_accesos ORDER BY fecha DESC LIMIT ?", (limite,)
        )
        return [dict(fila) for fila in cursor.fetchall()]


# Este bloque SOLO se ejecuta si corres directamente "python3 singleton.py"
# (no se ejecuta cuando app.py hace `from singleton import DatabaseManager`).
# Sirve para comprobar rápidamente que el patrón Singleton funciona.
if __name__ == "__main__":
    db1 = DatabaseManager()   # primera llamada -> crea la instancia real
    db2 = DatabaseManager()   # segunda llamada -> devuelve la MISMA instancia
    print("¿db1 es exactamente db2? ->", db1 is db2)
    print("Usuario admin creado con éxito:", db1.obtener_usuario("admin") is not None)
